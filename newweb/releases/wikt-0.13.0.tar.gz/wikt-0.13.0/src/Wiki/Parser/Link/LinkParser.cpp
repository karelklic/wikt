/* This file is part of Wikt.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#include "LinkParser.h"
#include "../TextBlock/TextBlockParser.h"
#include <QStringList>

//===========================================================================
LinkNode *LinkParser::parse(Buffer &buffer)
{
  if (buffer.endOfFile()) return 0;
  if (!buffer.startsWith("[[")) return 0;
  QString line = buffer.nextLine();
  int end = line.indexOf("]]");
  if (end == -1) return 0;
  buffer.skip(end + 2);

  bool forcedLink = line.startsWith("[[:");
  int begin = (forcedLink ? 3 : 2);
  QString insideLink = line.mid(begin, end - begin);
  QStringList parts = insideLink.split('|');

  bool emptyPipeAtEnd = false;
  if (parts.size() > 1 && parts.last().length() == 0)
  {
    parts.removeLast();
    emptyPipeAtEnd = true;
  }

  LinkNode *linkNode = new LinkNode(emptyPipeAtEnd, forcedLink);
  LinkTargetNode *targetNode = new LinkTargetNode(parts[0].trimmed());
  parts.removeFirst();
  linkNode->append(targetNode);

  foreach(const QString &part, parts)
  {
    LinkOptionsNode *optionNode = new LinkOptionsNode();
    TextBlockParser::parse(*optionNode, part.trimmed());
    linkNode->append(optionNode);
  }

  return linkNode;
}

//===========================================================================
LinkNode *LinkParser::parse(const QString &text)
{
  Buffer buf(text);
  return LinkParser::parse(buf);
}
