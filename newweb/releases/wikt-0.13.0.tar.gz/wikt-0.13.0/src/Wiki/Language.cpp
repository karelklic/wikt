/* This file is part of Wikt.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#include "Language.h"
#include "../Debug/Debug.h"
#include <QStringList>

//===========================================================================
const Language &Language::instance()
{
  static Language lang;
  return lang;
}

//===========================================================================
Language::Type Language::fromCode(const QString &code) const
{
  return _interwiki.value(code.toLower(), Unknown);
}

//===========================================================================
Language::Type Language::fromLinkTarget(const QString &linkTarget) const
{
  QStringList list = linkTarget.split(':');
  if (list.size() <= 1) return English;
  list.removeLast(); // remove actual entry
  foreach(QString name, list)
  {
    name = name.toLower();
    if (_interwiki.contains(name))
      return _interwiki.value(name);
  }

  return English;
}

//===========================================================================
QString Language::toLocalizedName(Language::Type lang) const
{
  return _localizedNames.value(lang, "Unknown localized name");
}

//===========================================================================
Language::Language()
{
#define L1(__enum, __shortcut) \
  _interwiki.insert(__shortcut, __enum)
#define L2(__enum, __shortcut, __localizedName) \
  _interwiki.insert(__shortcut, __enum); \
  _localizedNames.insert(__enum, QString::fromWCharArray(__localizedName))
  // Sorted by language name in English.
  // A
  L1(Abkhazian,     "ab");
  L1(Afar,          "aa");
  L2(Afrikaans,     "af",         L"Afrikaans");
  L1(Akan,          "ak");
  L2(Albanian,      "sq",         L"Shqip");
  L2(Amharic,       "am",         L"አማርኛ");
  L2(AngloSaxon,    "ang",        L"Anglo-Saxon");
  L2(Arabic,        "ar",         L"العربية");
  L2(Aragonese,     "an",         L"Aragonés");
  L1(Armenian,      "hy");
  L1(Assamese,      "as");
  L2(Asturian,      "ast",        L"Asturianu");
  L1(Avaric,        "av");
  L1(Avestan,       "ae");
  L1(Aymara,        "ay");
  L2(Azerbaijani,   "az",         L"Azərbaycan");
  // B
  L1(Bambara,       "bm");
  L1(Bashkir,       "ba");
  L1(Basque,        "eu");
  L1(Belarusian,    "be");
  L1(Bengali,       "bn");
  L1(Bihari,        "bh");
  L1(Bislama,       "bi");
  L2(Bosnian,       "bs",         L"Bosanski");
  L2(Breton,        "br",         L"Brezhoneg");
  L2(Bulgarian,     "bg",         L"Български");
  L2(Burmese,       "my",         L"Myanmasa");
  // C
  L2(Catalan,       "ca",         L"Català");
  L1(Chamorro,      "ch");
  L1(Chechen,       "ce");
  L1(Chichewa,      "ny");
  L2(Chinese,       "zh",         L"中文");
  L1(ChurchSlavic,  "cu");
  L1(Chuvash,       "cv");
  L1(Cornish,       "kw");
  L2(Corsican,      "co",         L"Corsu");
  L1(Cree,          "cr");
  L2(Croatian,      "hr",         L"Hrvatski");
  L2(Czech,         "cs",         L"Česky");
  // D
  L2(Danish,        "da",         L"Dansk");
  L1(Divehi,        "dv");
  L2(Dutch,         "nl",         L"Nederlands");
  L1(Dzongkha,      "dz");
  // E
  L2(English,       "en",         L"English");
  L2(Esperanto,     "eo",         L"Esperanto");
  L2(Estonian,      "et",         L"Eesti");
  L1(Ewe,           "ee");
  // F
  L1(Faroese,       "fo");
  L1(Fijian,        "fj");
  L2(Finnish,       "fi",         L"Suomi");
  L2(French,        "fr",         L"Français");
  L1(Fualah,        "ff");
  // G
  L2(Galician,      "gl",         L"Galego");
  L1(Ganda,         "lg");
  L1(Georgian,      "ka");
  L2(German,        "de",         L"Deutsch");
  L2(Greek,         "el",         L"Ελληνικά");
  L1(Guarani,       "gn");
  L1(Gujarati,      "gu");
  // H
  L1(Haitian,       "ht");
  L1(Hausa,         "ha");
  L1(Hebrew,        "he");
  L1(Herero,        "hz");
  L1(Hindi,         "hi");
  L1(HiriMotu,      "ho");
  L2(Hungarian,     "hu",         L"Magyar");
  // I
  L1(Icelandic,     "is");
  L2(Ido,           "io",         L"Ido");
  L1(Igbo,          "ig");
  L2(Indonesian,    "id",         L"Bahasa Indonesia");
  L2(Interlingua,   "ia",         L"Interlingua");
  L2(Interlingue,   "ie",         L"Interlingue");
  L1(Inuktitut,     "iu");
  L1(Inupiaq,       "ik");
  L2(Irish,         "ga",         L"Gaeilge");
  L2(Italian,       "it",         L"Italiano");
  // J
  L2(Japanese,      "ja",         L"日本語");
  L2(Javanese,      "jv",         L"Basa Jawa");
  // K
  L1(Kalaallisut,   "kl");
  L1(Kannada,       "kn");
  L1(Kanuri,        "kr");
  L1(Kashmiri,      "ks");
  L2(Kashubian,     "csb",        L"Kaszëbsczi");
  L2(Kazakh,        "kk",         L"Қазақша");
  L2(Khmer,         "km",         L"ភាសាខ្មែរ");
  L1(Kikuyu,        "ki");
  L1(Kinyarwanda,   "rw");
  L2(Kirghiz,       "ky",         L"Кыргызча");
  L1(Kirundi,       "rn");
  L1(Komi,          "kv");
  L1(Kongo,         "kg");
  L2(Korean,        "ko",         L"한국어");
  L2(Kurdish,       "ku",         L"Kurdî / كوردی");
  L1(Kwanyama,      "kj");
  // L
  L2(Lao,           "lo",         L"ລາວ");
  L2(Latin,         "la",         L"Latina");
  L1(Latvian,       "lv");
  L2(Limburgish,    "li",         L"Limburgs");
  L1(Lingala,       "ln");
  L2(Lithuanian,    "lt",         L"Lietuvių");
  L1(LubaKatanga,   "lu");
  L1(Luxembourgish, "lb");
  // M
  L1(Macedonian,       "mk");
  L1(Malagasy,         "mg");
  L2(Malay,            "ms",         L"Bahasa Melayu");
  L1(Malayalam,        "ml");
  L1(Maltese,          "mt");
  L1(Manx,             "gv");
  L1(Maori,            "mi");
  L1(Marathi,          "mr");
  L1(Marshallese,      "mh");
  L2(MinNan,           "zh-min-nan", L"Bân-lâm-gú");
  L2(Mongolian,        "mn",         L"Монгол");
  // N
  L1(Nauru,            "na");
  L1(Navajo,           "nv");
  L1(Ndonga,           "ng");
  L1(Nepali,           "ne");
  L1(NorthNdebele,     "nd");
  L1(NorthernSami,     "se");
  L2(Norwegian,        "no",         L"Norsk (bokmål)‬");
  L1(NorwegianBokmal,  "nb");
  L1(NorwegianNynorsk, "nn");
  // O
  L2(Occitan,          "oc",         L"Occitan");
  L1(Ojibwa,           "oj");
  L1(Oriya,            "or");
  L2(Oromo,            "om",         L"Oromoo");
  L1(Ossetian,         "os");
  // P
  L1(Pali,             "pi");
  L2(Panjabi,          "pa",         L"ਪੰਜਾਬੀ");
  L1(Pashto,           "ps");
  L2(Persian,          "fa",         L"فارسی");
  L2(Polish,           "pl",         L"Polski");
  L2(Portuguese,       "pt",         L"Português");
  // Q
  L1(Quechua,          "qu");
  // R
  L1(RaetoRomance,     "rm");
  L2(Romanian,         "ro",         L"Română");
  L2(Russian,          "ru",         L"Русский");
  // S
  L1(Samoan,           "sm");
  L1(Sango,            "sg");
  L1(Sanskrit,         "sa");
  L1(Sardinian,        "sc");
  L1(ScottishGaelic,   "gd");
  L1(Serbian,          "sr");
  L1(SerboCroatian,    "sh");
  L1(Shona,            "sn");
  L1(SichuanYi,        "ii");
  L2(Sicilian,         "scn",        L"Sicilianu");
  L2(SimpleEnglish,    "simple",     L"Simple English");
  L1(Sindhi,           "sd");
  L1(Sinhala,          "si");
  L2(Slovak,           "sk",         L"Slovenčina");
  L2(Slovenian,        "sl",         L"Slovenščina");
  L1(Somali,           "so");
  L1(SouthNdebele,     "nr");
  L2(SouthernSotho,    "st",         L"Sesotho");
  L2(Spanish,          "es",         L"Español");
  L1(Sundanese,        "su");
  L2(Swahili,          "sw",         L"Kiswahili");
  L1(Swati,            "ss");
  L2(Swedish,          "sv",         L"Svenska");
  // T
  L2(Tagalog,          "tl",         L"Tagalog");
  L1(Tahitian,         "ty");
  L1(Tajik,            "tg");
  L2(Tamil,            "ta",         L"தமிழ்");
  L2(Tatar,            "tt",         L"Tatarça/Татарча");
  L2(Telugu,           "te",         L"తెలుగు");
  L2(Thai,             "th",         L"ไทย");
  L1(Tibetan,          "bo");
  L1(Tigrinya,         "ti");
  L1(Tonga,            "to");
  L2(Tsonga,           "ts",         L"Xitsonga");
  L2(Tswana,           "tn",         L"Setswana");
  L2(Turkish,          "tr",         L"Türkçe");
  L1(Turkmen,          "tk");
  L1(Twi,              "tw");
  // U
  L1(Uighur,           "ug");
  L2(Ukrainian,        "uk",         L"Українська");
  L2(UpperSorbian,     "hsb",        L"Hornjoserbsce");
  L2(Urdu,             "ur",         L"اردو");
  L1(Uzbek,            "uz");
  // V
  L1(Venda,            "ve");
  L2(Vietnamese,       "vi",         L"Tiếng Việt");
  L2(Volapuk,          "vo",         L"Volapük");
  // W
  L1(Walloon,          "wa");
  L2(Welsh,            "cy",         L"Cymraeg");
  L1(WesternFrisian,   "fy");
  L1(Wolof,            "wo");
  // X
  L1(Xhosa,            "xh");
  // Y
  L1(Yiddish,          "yi");
  L1(Yoruba,           "yo");
  // Z
  L1(Zhuang,           "za");
  L1(Zulu,             "zu");
}
