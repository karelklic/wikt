/* This file is part of Wikt.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#include "LinkNode.h"
#include "LinkTargetNode.h"
#include "LinkOptionsNode.h"

//===========================================================================
LinkNode::LinkNode(bool emptyPipeAtEnd, bool forcedLink)
  : Node(Node::Link), _emptyPipeAtEnd(emptyPipeAtEnd), _forcedLink(forcedLink)
{
}

//===========================================================================
QString LinkNode::toXHtml() const
{
  // Images are not supported yet.
  if (!_forcedLink && namespace_() == Namespace::Image) return "";
  // Category links are not rendered to the XHTML output.
  if (!_forcedLink && namespace_() == Namespace::Category) return "";

  int opts = getOptionCount();
  LinkTargetNode *target = targetLink();
  if (!target) return "";
  if (opts == 1)
  {
    LinkOptionsNode *opt = getOption(0);
    return QString("<a href=\"%1\">%2</a>")
      .arg(target->toXHtmlLink())
      .arg(opt->toXHtml());
  }
  else
  {
    return QString("<a href=\"%1\">%2</a>")
      .arg(target->toXHtmlLink())
      .arg(target->toXHtml());
  }
}

//===========================================================================
QString LinkNode::toXml(int indentLevel) const
{
  QString indent(indentLevel, ' ');
  return indent +
    QString("<link emptyPipeAtEnd=\"%1\" forcedLink=\"%2\">\n")
      .arg(_emptyPipeAtEnd ? "true" : "false")
      .arg(_forcedLink ? "true" : "false") +
    childrenToXml(indentLevel+1) +
    indent + "</link>\n";
}

//===========================================================================
Namespace::Type LinkNode::namespace_() const
{
  LinkTargetNode *target = targetLink();
  if (!target) return Namespace::Unknown;
  return target->namespace_();
}

//===========================================================================
Language::Type LinkNode::language() const
{
  LinkTargetNode *target = targetLink();
  if (!target) return Language::English;
  return target->language();
}

//===========================================================================
Project::Type LinkNode::project() const
{
  LinkTargetNode *target = targetLink();
  if (!target) return Project::Wiktionary;
  return target->project();
}

//===========================================================================
QString LinkNode::xhtmlTitle() const
{
  if (language() != Language::English)
    return Language::instance().toLocalizedName(language());

  int opts = getOptionCount();
  if (opts == 1)
  {
    LinkOptionsNode *opt = getOption(0);
    return opt->toXHtml();
  }
  else
  {
    LinkTargetNode *target = targetLink();
    if (!target) return "";
    return target->toXHtml();
  }
}

//===========================================================================
QString LinkNode::wikiLink() const
{
  return targetLink()->toText();
}

//===========================================================================
LinkTargetNode *LinkNode::targetLink() const
{
  foreach (Node *node, children())
  {
    if (node->type() == Node::LinkTarget)
      return dynamic_cast<LinkTargetNode*>(node);
  }
  return 0;
}

//===========================================================================
int LinkNode::getOptionCount() const
{
  int count = 0;
  foreach (Node *node, children())
  {
    if (node->type() == Node::LinkOption)
      ++count;
  }
  return count;
}

//===========================================================================
LinkOptionsNode *LinkNode::getOption(int pos) const
{
  int count = 0;
  foreach (Node *node, children())
  {
    if (node->type() != Node::LinkOption) continue;
    if (count == pos)
      return dynamic_cast<LinkOptionsNode*>(node);
    ++count;
  }
  return 0;
}
