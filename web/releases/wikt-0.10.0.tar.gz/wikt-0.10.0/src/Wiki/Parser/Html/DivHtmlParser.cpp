/* This file is part of Wikt.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#include "DivHtmlParser.h"
#include "InlineHtmlParser.h"
#include "../Block/BlockParser.h"

//===========================================================================
Node *DivHtmlParser::parse(Buffer &buffer)
{
  if (buffer.endOfFile()) return 0;
  // To make it faster for the most common case.
  if (buffer.nextChar() != '<') return 0;

  // Parse opening tag.
  QRegExp open = openDivExpr(true);
  int pos = open.indexIn(buffer.text(), buffer.pos(), QRegExp::CaretAtOffset);
  if (pos != buffer.pos()) return 0;

  HtmlElementNode *node = new HtmlElementNode("div", open.cap(2), true);

  // find the right closing tag.
  int closingTagLength;
  int closing = InlineHtmlParser::indexOfClosingTag(buffer, "div",
      closingTagLength);
  buffer.skip(open.matchedLength());

  // The case of no closing tag.
  if (closing == -1)
  {
    // TODO: some error message or log something.
    BlockParser::parse(*node, buffer);
    return node;
  }

  // Closing tag present.
  Buffer insideBuffer(buffer.read(closing - buffer.pos()));
  BlockParser::parse(*node, insideBuffer);
  buffer.skip(closingTagLength);
  return node;
}

//===========================================================================
QRegExp DivHtmlParser::openDivExpr(bool fromStartOfLine)
{
  QString openExpr = QString("<div([ ]*| ([^<>]+))>");
  if (fromStartOfLine) openExpr.prepend('^');
  return QRegExp(openExpr, Qt::CaseInsensitive);
}

