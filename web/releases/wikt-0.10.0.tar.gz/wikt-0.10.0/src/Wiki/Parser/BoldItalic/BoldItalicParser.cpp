/* This file is part of Wikt.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#include "BoldItalicParser.h"
#include "../TextBlock/TextBlockParser.h"

//===========================================================================
Node *BoldItalicParser::parse(Buffer &buffer)
{
  if (buffer.endOfFile()) return 0;
  // To make it faster for the most common case.
  if (buffer.nextChar() != '\'') return 0;

  QString line = buffer.nextLine();

  QRegExp aposExp("^(''+)");
  if (aposExp.indexIn(line, 0) != 0)
    return 0;

  int aposCount = aposExp.cap(1).length();

  // If there are more than 5 apostrophes in a row, assume they are all text
  // except for the last 5. Source: mediawiki-1.14.0 Parser.php
  if (aposCount > 5)
    return 0;

  // If there are ever four apostrophes, assume the first is supposed to be
  // text, and the remaining three constitute mark-up for bold text.
  if (aposCount == 4)
    return 0;

  // Two apostrophes -> italics.
  if (aposCount == 2)
  {
    ItalicsNode *node = new ItalicsNode();
    // look for anything except ''' to close our italic text.
    // TODO: there is a bug, see 0x00000A in [[A]].
    int closing = line.indexOf(QRegExp("''|''''"), 2);
    if (closing == -1)
    {
      TextBlockParser::parse(*node, line.mid(2));
      buffer.skip(line.length());
    }
    else
    {
      TextBlockParser::parse(*node, line.mid(2, closing - 2));
      buffer.skip(closing + 2); // 2 == length of "''".
    }
    return node;
  }

  // Three apostrophes -> bold
  if (aposCount == 3)
  {
    BoldNode *node = new BoldNode();
    // look for ''' to close our bold text.
    int closing = line.indexOf("'''", 3);
    if (closing == -1)
    {
      TextBlockParser::parse(*node, line.mid(3));
      buffer.skip(line.length());
    }
    else
    {
      TextBlockParser::parse(*node, line.mid(3, closing - 3));
      buffer.skip(closing + 3); // 3 == length of "'''".
    }
    return node;
  }

  if (aposCount == 5)
  {
    int closing3 = line.indexOf("'''", 5);
    int closing2 = line.indexOf("''", 5);

    // Its bold.
    if (closing3 != -1 && closing3 <= closing2)
    {
      BoldNode *node = new BoldNode();
      TextBlockParser::parse(*node, line.mid(3, closing3 - 3));
      buffer.skip(closing3 + 3);
      return node;
    }

    // Its italic.
    if (closing2 != -1)
    {
      ItalicsNode *node = new ItalicsNode();
      TextBlockParser::parse(*node, line.mid(2, closing2 - 2));
      buffer.skip(closing2 + 2);
      return node;
    }

    // Its nothing.
    return 0;
  }

  CHECK(false);
  return 0;
}

