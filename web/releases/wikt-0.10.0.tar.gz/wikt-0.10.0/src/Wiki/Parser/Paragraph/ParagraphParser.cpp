/* This file is part of Wikt.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#include "ParagraphParser.h"
#include "../TextBlock/TextBlockParser.h"
#include "../Html/DivHtmlParser.h"

//===========================================================================
bool lineBelongsToParagraph(const QString &line)
{
  if (line.trimmed().length() == 0)
    return false;
  return line[0] != ' ' && line[0] != ':' && line[0] != ';' &&
    line[0] != '*' && line[0] != '#' && line[0] != '=';
}

//===========================================================================
ParagraphNode *ParagraphParser::parse(Buffer &buffer)
{
  if (buffer.endOfFile()) return 0;

  QString paragraph;
  QString line = buffer.nextLine();
  int openDivOffs; // for DIVs
  QRegExp openDiv = DivHtmlParser::openDivExpr(false); // DIVs
  while (lineBelongsToParagraph(line))
  {
    // Handle DIVs inside of a paragraph.
    // DIV causes paragraph to end.
    if ((openDivOffs = openDiv.indexIn(line, 0)) != -1)
    {
      paragraph += line.mid(0, openDivOffs);
      buffer.skip(openDivOffs);
      break;
    }

    paragraph += line;
    buffer.skip(line.length() + 1);
    if (buffer.endOfFile()) break;
    line = buffer.nextLine();
  }

  if (paragraph.length() == 0)
    return 0;

  ParagraphNode *parNode = new ParagraphNode();
  // Create our own paragraph buffer, so the embedded nodes (like
  // links, spans etc.) do not leave the paragraph.
  TextBlockParser::parse(*parNode, paragraph);

  buffer.skipEmptyLines();
  return parNode;
}
