/* This file is part of Wikt.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#include "LinkTargetNode.h"
#include "../TextTokenNode.h"
#include "../../../MainWindow/WebView/UrlUtils.h"
#include <QRegExp>

//===========================================================================
QString LinkTargetNode::toXHtmlLink() const
{
  return UrlUtils::toUrl(toText()).toString();
}

//===========================================================================
QString LinkTargetNode::toXml(int indentLevel) const
{
  QString indent(indentLevel, ' ');
  return indent + QString("<link_target>\n") +
    childrenToXml(indentLevel+1) +
    indent + "</link_target>\n";
}

//===========================================================================
bool LinkTargetNode::linksToOtherWiktionary() const
{
  return toText().contains(QRegExp("^[^: \tA-Z]+:.+$"));
}

//===========================================================================
bool LinkTargetNode::linksToImage() const
{
  return toText().startsWith("Image:");
}

//===========================================================================
bool LinkTargetNode::linksToCategory() const
{
  return toText().startsWith("Category:", Qt::CaseInsensitive);
}
