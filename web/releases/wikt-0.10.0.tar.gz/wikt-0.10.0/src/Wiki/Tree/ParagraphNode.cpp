/* This file is part of Wikt.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#include "ParagraphNode.h"
#include "TextTokenNode.h"
#include "Link/LinkNode.h"

//===========================================================================
QString ParagraphNode::toXHtml() const
{
  // Interwiki is not rendered in XHtml.
  if (isInterwikiParagraph()) return "";

  // Empty paragraphs are not rendered in XHtml.
  QString childrenXHtml = childrenToXHtml();
  if (childrenXHtml.trimmed() == "") return "";

  // Standard XHtml output.
  return QString("<p>%1</p>").arg(childrenXHtml);
}

//===========================================================================
QString ParagraphNode::toXml(int indentLevel) const
{
  QString indent(indentLevel, ' ');
  return indent +
    QString("<para isInterwiki=\"%0\">\n")
      .arg(isInterwikiParagraph() ? "yes" : "no") +
    childrenToXml(indentLevel+1) +
    indent + "</para>\n";
}

//===========================================================================
bool ParagraphNode::isInterwikiParagraph() const
{
  if (count() <= 0) return false;
  bool hasLink = false; // paragraph contains at least one link
  foreach (Node *node, children())
  {
    // Skip empty text nodes.
    // If there are any other text nodes, this is not interwiki.
    if (node->type() == Node::TextToken)
    {
      const TextTokenNode *token = static_cast<const TextTokenNode*>(node);
      if (token->toText().trimmed() == "") continue;
      return false;
    }

    // Check link nodes.
    if (node->type() != Node::Link) return false;
    const LinkNode *link = static_cast<const LinkNode*>(node);
    if (!link->linksToOtherWiktionary()) return false;
    hasLink = true;
  }
  return hasLink;
}
