/* This file is part of Wikt.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#include "NamespaceUrlFunctions.h"
#include "../../../MainWindow/WebView/UrlUtils.h"

//===========================================================================
bool NamespaceUrlFunctions::isFunction(const QString &templateText)
{
  QString trimmed = templateText.trimmed();
  return trimmed.startsWith("ns:", Qt::CaseInsensitive) ||
         trimmed.startsWith("fullurl:", Qt::CaseInsensitive) ||
         trimmed.startsWith("fullurle:", Qt::CaseInsensitive) ||
         trimmed.startsWith("urlencode:", Qt::CaseInsensitive);
}

//===========================================================================
/// Gets the magic namespace template name and returns the localized
/// name for the namespace.
/// For example:
/// * functionNs("ns:2") == "User"
/// * functionNs("ns:template") == "Template"
static QString functionNs(const QString &templateText)
{
  int sep = templateText.indexOf(":");
  CHECK_MSG(sep != -1, "Missing separator.");

  // Ignore any parameters. Parameters are separated by '|'.
  QString value = templateText.section('|', 0, 0);
  // Get the value after "ns:" in a normalized form.
  value = value.section(':', 1).trimmed().toUpper();

  if (value == "-2" || value == "MEDIA") return "Media";
  if (value == "-1" || value == "SPECIAL") return "Special";
  if (value == "0"  || value == "MAIN") return "";
  if (value == "1"  || value == "TALK") return "Talk";
  if (value == "2"  || value == "USER") return "User";
  if (value == "3"  || value == "USER_TALK" ||
      value == "USER TALK") return "User talk";
  if (value == "4"  || value == "PROJECT") return "Wiktionary";
  if (value == "5"  || value == "PROJECT_TALK" ||
      value == "PROJECT TALK") return "Wiktionary talk";
  if (value == "6"  || value == "IMAGE") return "Image";
  if (value == "7"  || value == "IMAGE_TALK" ||
      value == "IMAGE TALK") return "Image talk";
  if (value == "8"  || value == "MEDIAWIKI") return "MediaWiki";
  if (value == "9"  || value == "MEDIAWIKI_TALK" ||
      value == "MEDIAWIKI TALK") return "MediaWiki talk";
  if (value == "10" || value == "TEMPLATE") return "Template";
  if (value == "11" || value == "TEMPLATE_TALK" ||
      value == "TEMPLATE TALK") return "Template talk";
  if (value == "12" || value == "HELP") return "Help";
  if (value == "13" || value == "HELP_TALK" ||
      value == "HELP TALK") return "Help talk";
  if (value == "14" || value == "CATEGORY") return "Category";
  if (value == "15" || value == "CATEGORY_TALK" ||
      value == "CATEGORY TALK") return "Category talk";
  MSG("Unknown value: " + value);
  return ""; // Main namespace.
}

//===========================================================================
static QString functionFullUrl(const QString &templateText)
{
  QString pageNameWithPrefix = templateText.section(':', 1);

  QString path = QString::fromAscii(
      QUrl::toPercentEncoding(templateText.section(':', 2))); // can be empty!

  if (pageNameWithPrefix.startsWith("m:", Qt::CaseInsensitive) ||
      pageNameWithPrefix.startsWith("meta:", Qt::CaseInsensitive))
    return "http://meta.wikimedia.org/wiki/" + path;
  else if (pageNameWithPrefix.startsWith("w:", Qt::CaseInsensitive) ||
      pageNameWithPrefix.startsWith("wikipedia:", Qt::CaseInsensitive))
    return "http://en.wikipedia.org/wiki/" + path;
  else if (pageNameWithPrefix.startsWith("s:", Qt::CaseInsensitive) ||
      pageNameWithPrefix.startsWith("wikisource:", Qt::CaseInsensitive))
    return "http://en.wikisource.org/wiki/" + path;
  else if (pageNameWithPrefix.startsWith("q:", Qt::CaseInsensitive) ||
      pageNameWithPrefix.startsWith("wikiquote:", Qt::CaseInsensitive))
    return "http://en.wikiquote.org/wiki/" + path;
  else if (pageNameWithPrefix.startsWith("b:", Qt::CaseInsensitive) ||
      pageNameWithPrefix.startsWith("wikibooks:", Qt::CaseInsensitive))
    return "http://en.wikibooks.org/wiki/" + path;
  else if (pageNameWithPrefix.startsWith("n:", Qt::CaseInsensitive) ||
      pageNameWithPrefix.startsWith("wikinews:", Qt::CaseInsensitive))
    return "http://en.wikinews.org/wiki/" + path;
  else if (pageNameWithPrefix.startsWith("v:", Qt::CaseInsensitive) ||
      pageNameWithPrefix.startsWith("wikiversity:", Qt::CaseInsensitive))
    return "http://en.wikiversity.org/wiki/" + path;
  else if (pageNameWithPrefix.startsWith("commons:", Qt::CaseInsensitive))
    return "http://commons.wikimedia.org/wiki/" + path;
  else if (pageNameWithPrefix.startsWith("species:", Qt::CaseInsensitive) ||
      pageNameWithPrefix.startsWith("wikispecies:", Qt::CaseInsensitive))
    return "http://species.wikimedia.org/wiki/" + path;
  else if (pageNameWithPrefix.startsWith("wikimedia:", Qt::CaseInsensitive))
    return "http://wikimediafoundation.org/wiki/" + path;
  else if (pageNameWithPrefix.startsWith("mw:", Qt::CaseInsensitive))
    return "http://www.mediawiki.org/wiki/" + path;
  else if (pageNameWithPrefix.startsWith("mediazilla:", Qt::CaseInsensitive))
    return "http://bugzilla.wikimedia.org/" + path;

  // It links to wiktionary; return local url instead of external one.
  return UrlUtils::toUrl(pageNameWithPrefix).toString();
}

//===========================================================================
/// Encodes the text to a form suitable for use in a url by converting
/// spaces to + and escaping other characters as required.
static QString functionUrlEncode(const QString &templateText)
{
  QString text = templateText.section(':', 1).trimmed();
  text = QUrl::toPercentEncoding(text, QByteArray(" "), QByteArray("~"));
  return text.replace(" ", "+");
}

//===========================================================================
QString NamespaceUrlFunctions::evaluate(const QString &templateText)
{
  PROFILER;
  QString trimmed = templateText.trimmed();
  if (trimmed.startsWith("ns:", Qt::CaseInsensitive))
    return functionNs(templateText);
  else if (trimmed.startsWith("fullurl:", Qt::CaseInsensitive) ||
      trimmed.startsWith("fullurle:", Qt::CaseInsensitive))
    return functionFullUrl(templateText);
  else if (trimmed.startsWith("urlencode:", Qt::CaseInsensitive))
    return functionUrlEncode(templateText);

  MSG("Unknown namespace url function.");
  return templateText;
}
