/* This file is part of Wikt.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#include "ExternalLinkTransformer.h"
#include "../../../Prerequisites.h"
#include <QRegExp>

//===========================================================================
QString ExternalLinkTransformer::transform(QString text)
{
  PROFILER;
  QRegExp rx("\\[(http://[^ \\n\\]]+) ?([^\\]\\n]*)?\\]");

  int pos = 0;
  int linkCounter = 1;
  while ((pos = rx.indexIn(text, pos)) != -1)
  {
    if (pos > 0 && text[pos - 1] == '[')
    {
      ++pos;
      continue;
    }
    text.remove(pos, rx.matchedLength());
    QString link = rx.cap(1).replace("\"", "%22")
      .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    QString title = rx.cap(2).trimmed();
    if (title == "") title = QString("[%1]").arg(linkCounter++);
    text.insert(pos, QString("<a href=\"%1\">%2</a>").arg(rx.cap(1), title));
  }
  return text;
}

