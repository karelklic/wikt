/* This file is part of Wikt.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#include "NetworkReplyEmbeddedFile.h"
#include "UrlUtils.h"
#include "../MainWindow.h"
#include "../../Wiki/WikiSource.h"
#include "../../Prerequisites.h"
#include <QTimer>
#include <QFile>

//===========================================================================
NetworkReplyEmbeddedFile::NetworkReplyEmbeddedFile(const QNetworkRequest &request,
    QObject *parent) : QNetworkReply(parent)
{
  QString entry = UrlUtils::toEntry(request.url());

  _file.setFileName(":/" + entry);
  CHECK(_file.exists());
  _file.open(QIODevice::ReadOnly);
  CHECK(_file.isOpen() && _file.isReadable());

  QString mimetype;
  if (entry.endsWith(".png", Qt::CaseInsensitive))
    mimetype = "image/png";
  else if (entry.endsWith(".svg", Qt::CaseInsensitive))
    mimetype = "image/svg+xml";
  else if (entry.endsWith(".js", Qt::CaseInsensitive))
    mimetype = "text/javascript";
  else if (entry.endsWith(".gif", Qt::CaseInsensitive))
    mimetype = "image/gif";
  else
    MSG("Unsupported mimetype.");

  setRequest(request);
  setUrl(request.url());
  setOpenMode(QIODevice::ReadOnly);
  setOperation(QNetworkAccessManager::GetOperation);
  setHeader(QNetworkRequest::ContentTypeHeader, mimetype);
  setHeader(QNetworkRequest::ContentLengthHeader, _file.size());

  QTimer::singleShot(0, this, SIGNAL(metaDataChanged()));
  QTimer::singleShot(0, this, SIGNAL(readyRead()));

  connect(&_checkFinishedTimer, SIGNAL(timeout()),
      this, SLOT(checkFinished()));
  _checkFinishedTimer.start(50);
}

//===========================================================================
void NetworkReplyEmbeddedFile::checkFinished()
{
  if (_file.bytesAvailable() + QNetworkReply::bytesAvailable() == 0)
  {
    _checkFinishedTimer.stop();
    QTimer::singleShot(0, this, SIGNAL(finished()));
  }
}

