/* This file is part of Wikt.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#ifndef WIKT_MAIN_MENU_BAR_H
#define WIKT_MAIN_MENU_BAR_H

#include "../Prerequisites.h"
#include <QMenuBar>
QT_BEGIN_NAMESPACE
class QAction;
class QMenu;
QT_END_NAMESPACE
class MainWindow;

/// Handles the application's main menu and some simple and debug actions.
class MenuBar : public QMenuBar
{
  Q_OBJECT
public:
  MenuBar(MainWindow *parent);
  ~MenuBar();

private slots:
  /// Displays an about application box.
  void about();
  /// Shows a floating subwindow with current page's HTML source.
  void pageHtml();
  void wordXml();
  void wordWiki();
  void algorithmWikiProcessing();
  void test();
  /// Shows a window with performance measurement results.
  void profilerResults();
  /// Dictionary format converter.
  void showFormat1ToFormat2Dialog();
  /// Dictionary format converter.
  void showFormat2ToFormat3Dialog();

private:
  MainWindow *_parent;
  QMenu *_fileMenu;
  QMenu *_debugMenu;
  QMenu *_debugWordMenu;
  QMenu *_debugAlgorithmMenu;
  QMenu *_helpMenu;

  QAction *_aboutAct;
  QAction *_quitAct;
  QAction *_showFormat1ToFormat2DialogAct;
  QAction *_showFormat2ToFormat3DialogAct;
  QAction *_pageHtmlAct;
  QAction *_wordXmlAct;
  QAction *_wordWikiAct;
  QAction *_algorithmWikiProcessingAct;
  QAction *_testAct;
  QAction *_profilerAct;
};

#endif
