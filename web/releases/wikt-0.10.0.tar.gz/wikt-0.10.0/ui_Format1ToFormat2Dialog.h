/********************************************************************************
** Form generated from reading ui file 'Format1ToFormat2Dialog.ui'
**
** Created: Sat Apr 18 03:18:57 2009
**      by: Qt User Interface Compiler version 4.4.3
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_FORMAT1TOFORMAT2DIALOG_H
#define UI_FORMAT1TOFORMAT2DIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPlainTextEdit>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Format1ToFormat2DialogClass
{
public:
    QLineEdit *sourceEdit;
    QLabel *sourceLabel;
    QPushButton *browseSourceButton;
    QPushButton *browseDestinationButton;
    QLineEdit *destinationEdit;
    QLabel *destinationLabel;
    QPushButton *startButton;
    QPlainTextEdit *reportEdit;

    void setupUi(QDialog *Format1ToFormat2DialogClass)
    {
    if (Format1ToFormat2DialogClass->objectName().isEmpty())
        Format1ToFormat2DialogClass->setObjectName(QString::fromUtf8("Format1ToFormat2DialogClass"));
    Format1ToFormat2DialogClass->resize(400, 300);
    Format1ToFormat2DialogClass->setMinimumSize(QSize(400, 300));
    Format1ToFormat2DialogClass->setMaximumSize(QSize(400, 300));
    Format1ToFormat2DialogClass->setContextMenuPolicy(Qt::DefaultContextMenu);
    sourceEdit = new QLineEdit(Format1ToFormat2DialogClass);
    sourceEdit->setObjectName(QString::fromUtf8("sourceEdit"));
    sourceEdit->setGeometry(QRect(90, 10, 221, 26));
    sourceLabel = new QLabel(Format1ToFormat2DialogClass);
    sourceLabel->setObjectName(QString::fromUtf8("sourceLabel"));
    sourceLabel->setGeometry(QRect(10, 20, 52, 16));
    browseSourceButton = new QPushButton(Format1ToFormat2DialogClass);
    browseSourceButton->setObjectName(QString::fromUtf8("browseSourceButton"));
    browseSourceButton->setGeometry(QRect(320, 10, 71, 26));
    browseDestinationButton = new QPushButton(Format1ToFormat2DialogClass);
    browseDestinationButton->setObjectName(QString::fromUtf8("browseDestinationButton"));
    browseDestinationButton->setGeometry(QRect(320, 40, 71, 26));
    destinationEdit = new QLineEdit(Format1ToFormat2DialogClass);
    destinationEdit->setObjectName(QString::fromUtf8("destinationEdit"));
    destinationEdit->setGeometry(QRect(90, 40, 221, 26));
    destinationLabel = new QLabel(Format1ToFormat2DialogClass);
    destinationLabel->setObjectName(QString::fromUtf8("destinationLabel"));
    destinationLabel->setGeometry(QRect(10, 50, 71, 16));
    startButton = new QPushButton(Format1ToFormat2DialogClass);
    startButton->setObjectName(QString::fromUtf8("startButton"));
    startButton->setGeometry(QRect(10, 80, 381, 26));
    reportEdit = new QPlainTextEdit(Format1ToFormat2DialogClass);
    reportEdit->setObjectName(QString::fromUtf8("reportEdit"));
    reportEdit->setGeometry(QRect(10, 110, 381, 181));
    reportEdit->setUndoRedoEnabled(false);
    reportEdit->setReadOnly(true);
    reportEdit->setCenterOnScroll(false);

    retranslateUi(Format1ToFormat2DialogClass);
    QObject::connect(browseSourceButton, SIGNAL(clicked()), Format1ToFormat2DialogClass, SLOT(onBrowseSourceButtonClick()));
    QObject::connect(browseDestinationButton, SIGNAL(clicked()), Format1ToFormat2DialogClass, SLOT(onBrowseDestinationButtonClick()));
    QObject::connect(startButton, SIGNAL(clicked()), Format1ToFormat2DialogClass, SLOT(onStartButtonClick()));

    QMetaObject::connectSlotsByName(Format1ToFormat2DialogClass);
    } // setupUi

    void retranslateUi(QDialog *Format1ToFormat2DialogClass)
    {
    Format1ToFormat2DialogClass->setWindowTitle(QApplication::translate("Format1ToFormat2DialogClass", "Format1 to Format2 Converter", 0, QApplication::UnicodeUTF8));
    sourceLabel->setText(QApplication::translate("Format1ToFormat2DialogClass", "Source", 0, QApplication::UnicodeUTF8));
    browseSourceButton->setText(QApplication::translate("Format1ToFormat2DialogClass", "Browse", 0, QApplication::UnicodeUTF8));
    browseDestinationButton->setText(QApplication::translate("Format1ToFormat2DialogClass", "Browse", 0, QApplication::UnicodeUTF8));
    destinationLabel->setText(QApplication::translate("Format1ToFormat2DialogClass", "Destination", 0, QApplication::UnicodeUTF8));
    startButton->setText(QApplication::translate("Format1ToFormat2DialogClass", "Start", 0, QApplication::UnicodeUTF8));
    Q_UNUSED(Format1ToFormat2DialogClass);
    } // retranslateUi

};

namespace Ui {
    class Format1ToFormat2DialogClass: public Ui_Format1ToFormat2DialogClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORMAT1TOFORMAT2DIALOG_H
