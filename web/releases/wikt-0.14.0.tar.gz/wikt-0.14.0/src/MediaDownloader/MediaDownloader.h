/* This file is part of Wikt.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#ifndef MEDIADOWNLOADER_H_
#define MEDIADOWNLOADER_H_

#include <QTimer>
#include <QString>
#include <QNetworkAccessManager>
#include <QByteArray>

class LinkNode;
class Format3Reader;

/// Downloads media used in a dictionary from internet to
/// selected directory.
///
/// http://meta.wikimedia.org/wiki/Wikix
class MediaDownloader : public QObject
{
  Q_OBJECT
public:
  MediaDownloader(const QString& sourceFile,
    const QString& destinationDir);

  void start();
  void stop();

signals:
  void log(const QString &message);
  void finished(bool success);

private slots:
  void processEntry();
  void downloadFinished(QNetworkReply *reply);

private:
  /// Analyzes all links in an entry and checks if they links to images or sounds.
  /// @param name
  ///  Entry name such as "apple".
  /// @param content
  ///  Entry content in wiki format.
  void processContent(const QString &name, const QString &content);
  /// Checks if the link target is worth downloading and starts the download
  /// if it is so.
  void processLink(const LinkNode &node);
  /// Returns a path to file on the local filesystem that represents
  /// certain link.
  QString getMediaFilePath(const LinkNode &node) const;

  QString _sourceFile;
  QString _destinationDir;

  QTimer _timer;

  Format3Reader *_reader;
  int _pageCounter;

  QNetworkAccessManager *_networkAccessManager;
  int _downloadsInProgress;
};

#endif /* MEDIADOWNLOADER_H_ */
