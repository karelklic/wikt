/* This file is part of Wikt.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#include "InterWikiNames.h"
#include <QMap>

namespace InterWikiNames
{
  static bool initialized = false;
  static QMap<QString, QString> iwiki;

  //===========================================================================
  QString get(const QString &code)
  {
    if (!initialized)
    {
      initialized = true;
      iwiki.insert("af", QString::fromWCharArray(L"Afrikaans"));
      iwiki.insert("am", QString::fromWCharArray(L"አማርኛ"));
      iwiki.insert("ar", QString::fromWCharArray(L"العربية"));
      iwiki.insert("an", QString::fromWCharArray(L"Aragonés"));
      iwiki.insert("az", QString::fromWCharArray(L"Azərbaycan"));
      iwiki.insert("zh-min-nan", QString::fromWCharArray(L"Bân-lâm-gú"));
      iwiki.insert("bs", QString::fromWCharArray(L"Bosanski"));
      iwiki.insert("br", QString::fromWCharArray(L"Brezhoneg"));
      iwiki.insert("ca", QString::fromWCharArray(L"Català"));
      iwiki.insert("cs", QString::fromWCharArray(L"Česky"));
      iwiki.insert("co", QString::fromWCharArray(L"Corsu"));
      iwiki.insert("cy", QString::fromWCharArray(L"Cymraeg"));
      iwiki.insert("da", QString::fromWCharArray(L"Dansk"));
      iwiki.insert("de", QString::fromWCharArray(L"Deutsch"));
      iwiki.insert("et", QString::fromWCharArray(L"Eesti"));
      iwiki.insert("el", QString::fromWCharArray(L"Ελληνικά"));
      iwiki.insert("en", QString::fromWCharArray(L"English"));
      iwiki.insert("es", QString::fromWCharArray(L"Español"));
      iwiki.insert("eo", QString::fromWCharArray(L"Esperanto"));
      iwiki.insert("fa", QString::fromWCharArray(L"فارسی"));
      iwiki.insert("fr", QString::fromWCharArray(L"Français"));
      iwiki.insert("ga", QString::fromWCharArray(L"Gaeilge"));
      iwiki.insert("gl", QString::fromWCharArray(L"Galego"));
      iwiki.insert("ko", QString::fromWCharArray(L"한국어"));
      iwiki.insert("ky", QString::fromWCharArray(L"Кыргызча"));
      iwiki.insert("hsb", QString::fromWCharArray(L"Hornjoserbsce"));
      iwiki.insert("hr", QString::fromWCharArray(L"Hrvatski"));
      iwiki.insert("io", QString::fromWCharArray(L"Ido"));
      iwiki.insert("id", QString::fromWCharArray(L"Bahasa Indonesia"));
      iwiki.insert("ia", QString::fromWCharArray(L"Interlingua"));
      iwiki.insert("ie", QString::fromWCharArray(L"Interlingue"));
      iwiki.insert("it", QString::fromWCharArray(L"Italiano"));
      iwiki.insert("kk", QString::fromWCharArray(L"Қазақша"));
      iwiki.insert("jv", QString::fromWCharArray(L"Basa Jawa"));
      iwiki.insert("csb", QString::fromWCharArray(L"Kaszëbsczi"));
      iwiki.insert("sw", QString::fromWCharArray(L"Kiswahili"));
      iwiki.insert("ku", QString::fromWCharArray(L"Kurdî / كوردی"));
      iwiki.insert("la", QString::fromWCharArray(L"Latina"));
      iwiki.insert("lo", QString::fromWCharArray(L"ລາວ"));
      iwiki.insert("lt", QString::fromWCharArray(L"Lietuvių"));
      iwiki.insert("li", QString::fromWCharArray(L"Limburgs"));
      iwiki.insert("hu", QString::fromWCharArray(L"Magyar"));
      iwiki.insert("my", QString::fromWCharArray(L"Myanmasa"));
      iwiki.insert("ms", QString::fromWCharArray(L"Bahasa Melayu"));
      iwiki.insert("mn", QString::fromWCharArray(L"Монгол"));
      iwiki.insert("nl", QString::fromWCharArray(L"Nederlands"));
      iwiki.insert("om", QString::fromWCharArray(L"Oromoo"));
      iwiki.insert("km", QString::fromWCharArray(L"ភាសាខ្មែរ"));
      iwiki.insert("ja", QString::fromWCharArray(L"日本語"));
      iwiki.insert("no", QString::fromWCharArray(L"Norsk (bokmål)‬"));
      iwiki.insert("oc", QString::fromWCharArray(L"Occitan"));
      iwiki.insert("pl", QString::fromWCharArray(L"Polski"));
      iwiki.insert("pt", QString::fromWCharArray(L"Português"));
      iwiki.insert("ro", QString::fromWCharArray(L"Română"));
      iwiki.insert("ru", QString::fromWCharArray(L"Русский"));
      iwiki.insert("st", QString::fromWCharArray(L"Sesotho"));
      iwiki.insert("tn", QString::fromWCharArray(L"Setswana"));
      iwiki.insert("sq", QString::fromWCharArray(L"Shqip"));
      iwiki.insert("scn", QString::fromWCharArray(L"Sicilianu"));
      iwiki.insert("simple", QString::fromWCharArray(L"Simple English"));
      iwiki.insert("sk", QString::fromWCharArray(L"Slovenčina"));
      iwiki.insert("sl", QString::fromWCharArray(L"Slovenščina"));
      iwiki.insert("fi", QString::fromWCharArray(L"Suomi"));
      iwiki.insert("sv", QString::fromWCharArray(L"Svenska"));
      iwiki.insert("tl", QString::fromWCharArray(L"Tagalog"));
      iwiki.insert("ta", QString::fromWCharArray(L"தமிழ்"));
      iwiki.insert("tt", QString::fromWCharArray(L"Tatarça/Татарча"));
      iwiki.insert("te", QString::fromWCharArray(L"తెలుగు"));
      iwiki.insert("th", QString::fromWCharArray(L"ไทย"));
      iwiki.insert("vi", QString::fromWCharArray(L"Tiếng Việt"));
      iwiki.insert("tr", QString::fromWCharArray(L"Türkçe"));
      iwiki.insert("uk", QString::fromWCharArray(L"Українська"));
      iwiki.insert("ur", QString::fromWCharArray(L"اردو"));
      iwiki.insert("vo", QString::fromWCharArray(L"Volapük"));
      iwiki.insert("ts", QString::fromWCharArray(L"Xitsonga"));
      iwiki.insert("zh", QString::fromWCharArray(L"中文"));
    }
    return iwiki.value(code, code);
  }
}
