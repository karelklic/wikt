/* This file is part of Wikt.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#include "ExternalLinkTransformerTest.h"
#include "ExternalLinkTransformer.h"
#include <QTest>

//===========================================================================
void ExternalLinkTransformerTest::transform_data()
{
  QTest::addColumn<QString>("input");
  QTest::addColumn<QString>("output");
  QTest::newRow("0")
    << "[http://books.google.com/books?id=sfYOAAAAYAAJ A System of Aeronautics]"
    << "<a href=\"http://books.google.com/books?id=sfYOAAAAYAAJ\">A System of Aeronautics</a>";
  QTest::newRow("1")  << "[[kun|umi]]"   << "[[kun|umi]]";
  QTest::newRow("2")  << "[kun|umi]]"    << "[kun|umi]]";
  QTest::newRow("3")  << "[a a]"         << "[a a]";
  QTest::newRow("4")  << "[http://a a]"  << "<a href=\"http://a\">a</a>";
  QTest::newRow("5")  << "[http://a a ]" << "<a href=\"http://a\">a</a>";
  QTest::newRow("6")  << "[http://a a ]" << "<a href=\"http://a\">a</a>";
  QTest::newRow("7")  << "[http://a\na]" << "[http://a\na]";
  QTest::newRow("8")  << "[http://a]"    << "<a href=\"http://a\">[1]</a>";
  QTest::newRow("9")  << "[http://a][http://a]"
    << "<a href=\"http://a\">[1]</a><a href=\"http://a\">[2]</a>";
  QTest::newRow("10")  << "[http://a|]" << "<a href=\"http://a|\">[1]</a>";
}

//===========================================================================
void ExternalLinkTransformerTest::transform()
{
  QFETCH(QString, input);
  QFETCH(QString, output);
  QCOMPARE(ExternalLinkTransformer::transform(input), output);
}
