/* This file is part of Wikt.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#include "MenuBar.h"
#include "MainWindow.h"
#include "Coordinator.h"
#include "WebView/WebView.h"
#include "../Debug/HtmlSourceView.h"
#include "../Debug/WikiProcessingView.h"
#include "../Debug/WikiSourceView.h"
#include "../Debug/XmlSourceView.h"
#include "../Debug/UnitTest/UnitTestDialog.h"
#include "../Version.h"
#include "../DictionaryFile/Format1ToFormat2/Format1ToFormat2Dialog.h"
#include "../DictionaryFile/Format2ToFormat3/Format2ToFormat3Dialog.h"
#include <QMessageBox>

//===========================================================================
MenuBar::MenuBar(MainWindow *parent) : QMenuBar(parent)
{
  this->_parent = parent;

  _quitAct = new QAction(tr("&Quit"), this);
  _quitAct->setShortcut(tr("Ctrl+Q"));
  _quitAct->setStatusTip(tr("Quit the application"));
  connect(_quitAct, SIGNAL(triggered()), parent, SLOT(close()));

  _aboutAct = new QAction(tr("&About"), this);
  _aboutAct->setStatusTip(tr("Show the application's About box"));
  connect(_aboutAct, SIGNAL(triggered()), this, SLOT(about()));

  _pageHtmlAct = new QAction(tr("&Page HTML"), this);
  _pageHtmlAct->setStatusTip(tr("Show the HTML code of the currently displayed page."));
  connect(_pageHtmlAct, SIGNAL(triggered()), this, SLOT(pageHtml()));

  _wordXmlAct = new QAction(tr("&XML Source"), this);
  _wordXmlAct->setStatusTip(tr("Show the XML code"));
  connect(_wordXmlAct, SIGNAL(triggered()), this, SLOT(wordXml()));

  _wordWikiAct = new QAction(tr("&Wiki Source"), this);
  _wordWikiAct->setStatusTip(tr("Show the Wiki code"));
  connect(_wordWikiAct, SIGNAL(triggered()), this, SLOT(wordWiki()));

  _algorithmWikiProcessingAct = new QAction(tr("&Wiki Processing"), this);
  _algorithmWikiProcessingAct->setStatusTip(tr("Show the Wiki debug"));
  connect(_algorithmWikiProcessingAct, SIGNAL(triggered()), this, SLOT(algorithmWikiProcessing()));

  _testAct = new QAction(tr("Self-Test"), this);
  connect(_testAct, SIGNAL(triggered()), this, SLOT(test()));

  _profilerAct = new QAction(tr("Profiler results"), this);
#ifndef PROFILER_ENABLED
  _profilerAct->setEnabled(false);
#endif
  connect(_profilerAct, SIGNAL(triggered()), this, SLOT(profilerResults()));

  _showFormat1ToFormat2DialogAct = new QAction(tr("Format1 to Format2 Converter..."), this);
  connect(_showFormat1ToFormat2DialogAct, SIGNAL(triggered()), this, SLOT(showFormat1ToFormat2Dialog()));

  _showFormat2ToFormat3DialogAct = new QAction(tr("Format2 to Format3 Converter..."), this);
  connect(_showFormat2ToFormat3DialogAct, SIGNAL(triggered()), this, SLOT(showFormat2ToFormat3Dialog()));

  _fileMenu = addMenu(tr("&File"));
  _fileMenu->addAction(_quitAct);

  _debugMenu = addMenu(tr("&Development"));
  _debugMenu->addAction(_showFormat1ToFormat2DialogAct);
  _debugMenu->addAction(_showFormat2ToFormat3DialogAct);
  _debugMenu->addAction(_pageHtmlAct);
  _debugMenu->addSeparator();
  _debugWordMenu = _debugMenu->addMenu("Word");
  _debugWordMenu->addAction(_wordXmlAct);
  _debugWordMenu->addAction(_wordWikiAct);
  _debugAlgorithmMenu = _debugMenu->addMenu("Algorithm");
  _debugAlgorithmMenu->addAction(_algorithmWikiProcessingAct);
  _debugMenu->addSeparator();
  _debugMenu->addAction(_testAct);
  _debugMenu->addAction(_profilerAct);

  _helpMenu = addMenu(tr("&Help"));
  _helpMenu->addAction(_aboutAct);
}

//===========================================================================
MenuBar::~MenuBar()
{
}

//===========================================================================
void MenuBar::about()
{
 QMessageBox::about(parentWidget(), tr("About Wikt"),
   tr("Wikt version " WIKT_VERSION ".\n"
       "A computer interactive dictionary.\n"
       "Created by Karel Klic <karelklic@gmail.com>.\n"
       "Distributed under GNU General Public License 3.\n"
       "Uses data from Wiktionary project."));
}

//===========================================================================
void MenuBar::pageHtml()
{
  QString contents = _parent->webView()->toHtml();
  HtmlSourceView *w = new HtmlSourceView(contents);
  w->show();
}

//===========================================================================
void MenuBar::wordXml()
{
  XmlSourceView *w = new XmlSourceView();
  w->setWord(_parent->coordinator()->text());
  w->show();
}

//===========================================================================
void MenuBar::wordWiki()
{
  WikiSourceView *w = new WikiSourceView();
  w->setWord(_parent->coordinator()->text());
  w->show();
}

//===========================================================================
void MenuBar::algorithmWikiProcessing()
{
  WikiProcessingView *w = new WikiProcessingView();
  w->show();
}

//===========================================================================
void MenuBar::test()
{
  UnitTestDialog dialog;
  dialog.show();
}

//===========================================================================
void MenuBar::profilerResults()
{
  PROFILER_RESULTS;
}

//===========================================================================
void MenuBar::showFormat1ToFormat2Dialog()
{
  Format1ToFormat2Dialog generator;
  generator.exec();
}

//===========================================================================
void MenuBar::showFormat2ToFormat3Dialog()
{
  Format2ToFormat3Dialog generator;
  generator.exec();
}
