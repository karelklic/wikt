/* This file is part of Wikt.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#include "WikiSource.h"
#include "Parser/ArticleParser.h"
#include "Tree/Node.h"
#include "../DictionaryFile/Format3Reader.h"

//===========================================================================
WikiSource::WikiSource()
{
  _reader = new Format3Reader("data/enwiktionary-20090203-pages-articles.ei3");
}

//===========================================================================
WikiSource::~WikiSource()
{
  qDeleteAll(_cache.values());
  delete _reader;
}

//===========================================================================
bool WikiSource::exist(const QString &entryName)
{
  if (_cache.contains(entryName))
    return _cache[entryName]->_source != "";

  CacheItem *item = new CacheItem();
  item->_source = _reader->source(entryName);
  _cache.insert(entryName, item);
  return item->_source != "";
}

//===========================================================================
QString WikiSource::source(const QString &entryName)
{
  if (_cache.contains(entryName))
    return _cache[entryName]->_source;

  CacheItem *item = new CacheItem();
  item->_source = _reader->source(entryName);
  _cache.insert(entryName, item);
  return item->_source;
}

//===========================================================================
Node *WikiSource::tree(const QString &entryName)
{
  if (_cache.contains(entryName))
  {
    CacheItem *item = _cache[entryName];
    if (item->_source == "") return 0;
    if (item->_node) return item->_node;

    item->_node = ArticleParser::parse(entryName, item->_source);
    return item->_node;
  }

  CacheItem *item = new CacheItem();
  item->_source = _reader->source(entryName);
  _cache.insert(entryName, item);
  if (item->_source == "") return 0;
  item->_node = ArticleParser::parse(entryName, item->_source);
  return item->_node;
}

//===========================================================================
QString WikiSource::xhtml(const QString &entryName)
{
  if (_cache.contains(entryName))
  {
    CacheItem *item = _cache[entryName];
    if (item->_source == "") return "";
    if (item->_xhtml != "") return item->_xhtml;
    if (item->_node)
    {
      item->_xhtml = item->_node->toXHtml();
      return item->_xhtml;
    }

    item->_node = ArticleParser::parse(entryName, item->_source);
    item->_xhtml = item->_node->toXHtml();
    return item->_xhtml;
  }

  CacheItem *item = new CacheItem();
  item->_source = _reader->source(entryName);
  _cache.insert(entryName, item);
  if (item->_source == "") return 0;
  item->_node = ArticleParser::parse(entryName, item->_source);
  item->_xhtml = item->_node->toXHtml();
  return item->_xhtml;
}

//===========================================================================
WikiSource::CacheItem::~CacheItem()
{
  if (_node)
    delete(_node);
}
