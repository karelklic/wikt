/* This file is part of Wikt.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#ifndef LIBWIKT_DOM_LINK_NODE_H
#define LIBWIKT_DOM_LINK_NODE_H

#include "../Node.h"

class LinkTargetNode;
class LinkOptionsNode;

class LinkNode : public Node
{
public:
  LinkNode(bool emptyPipeAtEnd, bool forcedLink);
  virtual QString toXHtml() const;
  virtual QString toXml(int indentLevel = 0) const;

  /// Checks if the link is "interwiki" style, pointing to other language
  /// variant of the wiktionary. Example: [[cs:myslet]].
  bool linksToOtherWiktionary() const;
  bool linksToImage() const;
  bool linksToCategory() const;

  /// Forced link is the one that begins with colon,
  /// such as [[:Category:Czech nouns]].
  bool forcedLink() const { return _forcedLink; }
  bool emptyPipeAtEnd() const { return _emptyPipeAtEnd; }

  /// Returns the title of link. This is supposed to be read by users.
  QString xhtmlTitle() const;
  QString wikiLink() const;

  LinkTargetNode *targetLink() const;
  int getOptionCount() const;
  LinkOptionsNode *getOption(int pos) const;

protected:
  bool _emptyPipeAtEnd, _forcedLink;
};

#endif
