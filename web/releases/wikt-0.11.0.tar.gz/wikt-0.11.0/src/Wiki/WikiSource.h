/* This file is part of Wikt.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#ifndef WIKI_H_
#define WIKI_H_

#include <QString>
#include <QMap>
class Format3Reader;
class Node;

/// Caches the entry source text, parsed tree, XHTML representation.
class WikiSource
{
public:
  WikiSource();
  ~WikiSource();
  bool exist(const QString &entryName);
  QString source(const QString &entryName);
  /// Do not delete it.
  Node *tree(const QString &entryName);
  QString xhtml(const QString &entryName);

private:
  struct CacheItem {
    CacheItem() : _node(0) {}
    ~CacheItem();
    QString _source;
    Node *_node;
    QString _xhtml;
  };
  QMap<QString, CacheItem*> _cache;
  Format3Reader *_reader;
};

#endif /* WIKI_H_ */
