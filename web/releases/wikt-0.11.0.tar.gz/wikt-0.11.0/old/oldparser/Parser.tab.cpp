/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton implementation for Bison LALR(1) parsers in C++

   Copyright (C) 2002, 2003, 2004, 2005, 2006 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */


#include "Parser.tab.hpp"

/* User implementation prologue.  */
#line 34 "Parser.ypp"

yy::Parser::token_type yylex(yy::Parser::semantic_type* yylval,
        yy::Parser::location_type* yylloc, Driver& driver);


/* Line 317 of lalr1.cc.  */
#line 47 "Parser.tab.cpp"

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* FIXME: INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#define YYUSE(e) ((void) (e))

/* A pseudo ostream that takes yydebug_ into account.  */
# define YYCDEBUG							\
  for (bool yydebugcond_ = yydebug_; yydebugcond_; yydebugcond_ = false)	\
    (*yycdebug_)

/* Enable debugging if requested.  */
#if YYDEBUG

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)	\
do {							\
  if (yydebug_)						\
    {							\
      *yycdebug_ << Title << ' ';			\
      yy_symbol_print_ ((Type), (Value), (Location));	\
      *yycdebug_ << std::endl;				\
    }							\
} while (false)

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug_)				\
    yy_reduce_print_ (Rule);		\
} while (false)

# define YY_STACK_PRINT()		\
do {					\
  if (yydebug_)				\
    yystack_print_ ();			\
} while (false)

#else /* !YYDEBUG */

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_REDUCE_PRINT(Rule)
# define YY_STACK_PRINT()

#endif /* !YYDEBUG */

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab

namespace yy
{
#if YYERROR_VERBOSE

  /* Return YYSTR after stripping away unnecessary quotes and
     backslashes, so that it's suitable for yyerror.  The heuristic is
     that double-quoting is unnecessary unless the string contains an
     apostrophe, a comma, or backslash (other than backslash-backslash).
     YYSTR is taken from yytname.  */
  std::string
  Parser::yytnamerr_ (const char *yystr)
  {
    if (*yystr == '"')
      {
        std::string yyr = "";
        char const *yyp = yystr;

        for (;;)
          switch (*++yyp)
            {
            case '\'':
            case ',':
              goto do_not_strip_quotes;

            case '\\':
              if (*++yyp != '\\')
                goto do_not_strip_quotes;
              /* Fall through.  */
            default:
              yyr += *yyp;
              break;

            case '"':
              return yyr;
            }
      do_not_strip_quotes: ;
      }

    return yystr;
  }

#endif

  /// Build a parser object.
  Parser::Parser (Driver& driver_yyarg)
    : yydebug_ (false),
      yycdebug_ (&std::cerr),
      driver (driver_yyarg)
  {
  }

  Parser::~Parser ()
  {
  }

#if YYDEBUG
  /*--------------------------------.
  | Print this symbol on YYOUTPUT.  |
  `--------------------------------*/

  inline void
  Parser::yy_symbol_value_print_ (int yytype,
			   const semantic_type* yyvaluep, const location_type* yylocationp)
  {
    YYUSE (yylocationp);
    YYUSE (yyvaluep);
    switch (yytype)
      {
         default:
	  break;
      }
  }


  void
  Parser::yy_symbol_print_ (int yytype,
			   const semantic_type* yyvaluep, const location_type* yylocationp)
  {
    *yycdebug_ << (yytype < yyntokens_ ? "token" : "nterm")
	       << ' ' << yytname_[yytype] << " ("
	       << *yylocationp << ": ";
    yy_symbol_value_print_ (yytype, yyvaluep, yylocationp);
    *yycdebug_ << ')';
  }
#endif /* ! YYDEBUG */

  void
  Parser::yydestruct_ (const char* yymsg,
			   int yytype, semantic_type* yyvaluep, location_type* yylocationp)
  {
    YYUSE (yylocationp);
    YYUSE (yymsg);
    YYUSE (yyvaluep);

    YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

    switch (yytype)
      {
  
	default:
	  break;
      }
  }

  void
  Parser::yypop_ (unsigned int n)
  {
    yystate_stack_.pop (n);
    yysemantic_stack_.pop (n);
    yylocation_stack_.pop (n);
  }

  std::ostream&
  Parser::debug_stream () const
  {
    return *yycdebug_;
  }

  void
  Parser::set_debug_stream (std::ostream& o)
  {
    yycdebug_ = &o;
  }


  Parser::debug_level_type
  Parser::debug_level () const
  {
    return yydebug_;
  }

  void
  Parser::set_debug_level (debug_level_type l)
  {
    yydebug_ = l;
  }


  int
  Parser::parse ()
  {
    /// Look-ahead and look-ahead in internal form.
    int yychar = yyempty_;
    int yytoken = 0;

    /* State.  */
    int yyn;
    int yylen = 0;
    int yystate = 0;

    /* Error handling.  */
    int yynerrs_ = 0;
    int yyerrstatus_ = 0;

    /// Semantic value of the look-ahead.
    semantic_type yylval;
    /// Location of the look-ahead.
    location_type yylloc;
    /// The locations where the error started and ended.
    location yyerror_range[2];

    /// $$.
    semantic_type yyval;
    /// @$.
    location_type yyloc;

    int yyresult;

    YYCDEBUG << "Starting parse" << std::endl;


    /* Initialize the stacks.  The initial state will be pushed in
       yynewstate, since the latter expects the semantical and the
       location values to have been already stored, initialize these
       stacks with a primary value.  */
    yystate_stack_ = state_stack_type (0);
    yysemantic_stack_ = semantic_stack_type (0);
    yylocation_stack_ = location_stack_type (0);
    yysemantic_stack_.push (yylval);
    yylocation_stack_.push (yylloc);

    /* New state.  */
  yynewstate:
    yystate_stack_.push (yystate);
    YYCDEBUG << "Entering state " << yystate << std::endl;
    goto yybackup;

    /* Backup.  */
  yybackup:

    /* Try to take a decision without look-ahead.  */
    yyn = yypact_[yystate];
    if (yyn == yypact_ninf_)
      goto yydefault;

    /* Read a look-ahead token.  */
    if (yychar == yyempty_)
      {
	YYCDEBUG << "Reading a token: ";
	yychar = yylex (&yylval, &yylloc, driver);
      }


    /* Convert token to internal form.  */
    if (yychar <= yyeof_)
      {
	yychar = yytoken = yyeof_;
	YYCDEBUG << "Now at end of input." << std::endl;
      }
    else
      {
	yytoken = yytranslate_ (yychar);
	YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
      }

    /* If the proper action on seeing token YYTOKEN is to reduce or to
       detect an error, take that action.  */
    yyn += yytoken;
    if (yyn < 0 || yylast_ < yyn || yycheck_[yyn] != yytoken)
      goto yydefault;

    /* Reduce or error.  */
    yyn = yytable_[yyn];
    if (yyn <= 0)
      {
	if (yyn == 0 || yyn == yytable_ninf_)
	goto yyerrlab;
	yyn = -yyn;
	goto yyreduce;
      }

    /* Accept?  */
    if (yyn == yyfinal_)
      goto yyacceptlab;

    /* Shift the look-ahead token.  */
    YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

    /* Discard the token being shifted unless it is eof.  */
    if (yychar != yyeof_)
      yychar = yyempty_;

    yysemantic_stack_.push (yylval);
    yylocation_stack_.push (yylloc);

    /* Count tokens shifted since error; after three, turn off error
       status.  */
    if (yyerrstatus_)
      --yyerrstatus_;

    yystate = yyn;
    goto yynewstate;

  /*-----------------------------------------------------------.
  | yydefault -- do the default action for the current state.  |
  `-----------------------------------------------------------*/
  yydefault:
    yyn = yydefact_[yystate];
    if (yyn == 0)
      goto yyerrlab;
    goto yyreduce;

  /*-----------------------------.
  | yyreduce -- Do a reduction.  |
  `-----------------------------*/
  yyreduce:
    yylen = yyr2_[yyn];
    /* If YYLEN is nonzero, implement the default value of the action:
       `$$ = $1'.  Otherwise, use the top of the stack.

       Otherwise, the following line sets YYVAL to garbage.
       This behavior is undocumented and Bison
       users should not rely upon it.  */
    if (yylen)
      yyval = yysemantic_stack_[yylen - 1];
    else
      yyval = yysemantic_stack_[0];

    {
      slice<location_type, location_stack_type> slice (yylocation_stack_, yylen);
      YYLLOC_DEFAULT (yyloc, slice, yylen);
    }
    YY_REDUCE_PRINT (yyn);
    switch (yyn)
      {
	  case 2:
#line 76 "Parser.ypp"
    { (yyval.node) = driver._result = newNode(Article); ;}
    break;

  case 3:
#line 77 "Parser.ypp"
    { (yyval.node) = driver._result = newNode(Article); ;}
    break;

  case 4:
#line 78 "Parser.ypp"
    { (yyval.node) = driver._result = nodeAddChild2(newNode(Article), (yysemantic_stack_[(2) - (1)].node), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 5:
#line 79 "Parser.ypp"
    { (yyval.node) = driver._result = nodeAddChild(newNode(Article), (yysemantic_stack_[(1) - (1)].node)); ;}
    break;

  case 6:
#line 81 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 7:
#line 82 "Parser.ypp"
    { (yyval.node) = nodeAddSibling((yysemantic_stack_[(2) - (1)].node), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 8:
#line 84 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 9:
#line 85 "Parser.ypp"
    { (yyval.node) = nodeAddSibling((yysemantic_stack_[(2) - (1)].node), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 10:
#line 87 "Parser.ypp"
    { (yyval.node) = processPreBlock((yysemantic_stack_[(1) - (1)].node)); ;}
    break;

  case 11:
#line 88 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 12:
#line 89 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 13:
#line 90 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 14:
#line 91 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 15:
#line 92 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 16:
#line 94 "Parser.ypp"
    { (yyval.node) = processPreBlock((yysemantic_stack_[(1) - (1)].node)); ;}
    break;

  case 17:
#line 95 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 18:
#line 96 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 19:
#line 97 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 20:
#line 98 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 21:
#line 99 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 22:
#line 101 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNodeI(Heading, (yysemantic_stack_[(3) - (1)].num)), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 23:
#line 102 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(Paragraph), makeTextBlock(convertHeadingToText((yysemantic_stack_[(2) - (1)].num)), (yysemantic_stack_[(2) - (2)].node))); ;}
    break;

  case 24:
#line 103 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(Paragraph), convertHeadingToText((yysemantic_stack_[(1) - (1)].num))); ;}
    break;

  case 25:
#line 105 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(PreBlock), (yysemantic_stack_[(1) - (1)].node)); ;}
    break;

  case 26:
#line 106 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(2) - (1)].node), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 27:
#line 108 "Parser.ypp"
    { (yyval.node) = nodeAddChild2(newNode(PreLine), (yysemantic_stack_[(3) - (2)].node), (yysemantic_stack_[(3) - (3)].node)); ;}
    break;

  case 28:
#line 110 "Parser.ypp"
    { (yyval.node) = processListBlock((yysemantic_stack_[(1) - (1)].node)); ;}
    break;

  case 29:
#line 111 "Parser.ypp"
    { (yyval.node) = processListBlock((yysemantic_stack_[(1) - (1)].node)); ;}
    break;

  case 30:
#line 112 "Parser.ypp"
    { (yyval.node) = processListBlock((yysemantic_stack_[(1) - (1)].node)); ;}
    break;

  case 31:
#line 114 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(ListBlock), (yysemantic_stack_[(1) - (1)].node)); ;}
    break;

  case 32:
#line 115 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(2) - (1)].node), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 33:
#line 116 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(ListBlock), (yysemantic_stack_[(1) - (1)].node)); ;}
    break;

  case 34:
#line 117 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(2) - (1)].node), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 35:
#line 118 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(ListBlock), (yysemantic_stack_[(1) - (1)].node)); ;}
    break;

  case 36:
#line 119 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(2) - (1)].node), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 37:
#line 121 "Parser.ypp"
    { (yyval.node) = nodeAddChild(nodePrependChild((yysemantic_stack_[(4) - (2)].node), newNode(ListBullet)), (yysemantic_stack_[(4) - (3)].node)); ;}
    break;

  case 38:
#line 122 "Parser.ypp"
    { (yyval.node) = nodeAddChild(nodePrependChild((yysemantic_stack_[(3) - (2)].node), newNode(ListBullet)), (yysemantic_stack_[(3) - (3)].node)); ;}
    break;

  case 39:
#line 123 "Parser.ypp"
    { (yyval.node) = nodeAddChild(nodePrependChild((yysemantic_stack_[(4) - (2)].node), newNode(ListNumbered)), (yysemantic_stack_[(4) - (3)].node)); ;}
    break;

  case 40:
#line 124 "Parser.ypp"
    { (yyval.node) = nodeAddChild(nodePrependChild((yysemantic_stack_[(3) - (2)].node), newNode(ListNumbered)), (yysemantic_stack_[(3) - (3)].node)); ;}
    break;

  case 41:
#line 125 "Parser.ypp"
    { (yyval.node) = nodeAddChild(nodePrependChild((yysemantic_stack_[(4) - (2)].node), newNodeI(ListDefinition, 0)), (yysemantic_stack_[(4) - (3)].node)); ;}
    break;

  case 42:
#line 126 "Parser.ypp"
    { (yyval.node) = nodeAddChild(nodePrependChild((yysemantic_stack_[(4) - (2)].node), newNodeI(ListDefinition, 1)), (yysemantic_stack_[(4) - (3)].node)); ;}
    break;

  case 43:
#line 127 "Parser.ypp"
    { (yyval.node) = nodeAddChild(nodePrependChild((yysemantic_stack_[(3) - (2)].node), newNodeI(ListDefinition, 0)), (yysemantic_stack_[(3) - (3)].node)); ;}
    break;

  case 44:
#line 128 "Parser.ypp"
    { (yyval.node) = nodeAddChild(nodePrependChild((yysemantic_stack_[(3) - (2)].node), newNodeI(ListDefinition, 1)), (yysemantic_stack_[(3) - (3)].node)); ;}
    break;

  case 45:
#line 130 "Parser.ypp"
    { (yyval.node) = newNodeI(ListLine, 0); ;}
    break;

  case 46:
#line 131 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNodeI(ListLine, 0), newNode(ListBullet)); ;}
    break;

  case 47:
#line 132 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNodeI(ListLine, 0), newNode(ListNumbered)); ;}
    break;

  case 48:
#line 133 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNodeI(ListLine, 0), newNodeI(ListDefinition, 0)); ;}
    break;

  case 49:
#line 134 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNodeI(ListLine, 1), newNodeI(ListDefinition, 1)); ;}
    break;

  case 50:
#line 135 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(2) - (1)].node), newNode(ListBullet)); ;}
    break;

  case 51:
#line 136 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(2) - (1)].node), newNode(ListNumbered)); ;}
    break;

  case 52:
#line 137 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(2) - (1)].node), newNode(ListDefinition)); ;}
    break;

  case 53:
#line 138 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(2) - (1)].node), newNode(ListDefinition)); ;}
    break;

  case 54:
#line 140 "Parser.ypp"
    {;}
    break;

  case 55:
#line 142 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNodeI(LinkEtc, 0), nodeAddChild(newNode(LinkTarget), (yysemantic_stack_[(3) - (2)].node))); ;}
    break;

  case 56:
#line 143 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNodeI(LinkEtc, 1), nodeAddChild(newNode(LinkTarget), (yysemantic_stack_[(4) - (2)].node))); ;}
    break;

  case 57:
#line 144 "Parser.ypp"
    { (yyval.node) = nodeAddChild2(newNodeI(LinkEtc, 0), nodeAddChild(newNode(LinkTarget), (yysemantic_stack_[(4) - (2)].node)), (yysemantic_stack_[(4) - (3)].node)); ;}
    break;

  case 58:
#line 145 "Parser.ypp"
    { (yyval.node) = nodeAddChild2(newNodeI(LinkEtc, 1), nodeAddChild(newNode(LinkTarget), (yysemantic_stack_[(5) - (2)].node)), (yysemantic_stack_[(5) - (3)].node)); ;}
    break;

  case 59:
#line 146 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNodeI(LinkEtc, 2), nodeAddChild(newNode(LinkTarget), (yysemantic_stack_[(3) - (2)].node))); ;}
    break;

  case 60:
#line 147 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNodeI(LinkEtc, 3), nodeAddChild(newNode(LinkTarget), (yysemantic_stack_[(4) - (2)].node))); ;}
    break;

  case 61:
#line 148 "Parser.ypp"
    { (yyval.node) = nodeAddChild2(newNodeI(LinkEtc, 2), nodeAddChild(newNode(LinkTarget), (yysemantic_stack_[(4) - (2)].node)), (yysemantic_stack_[(4) - (3)].node)); ;}
    break;

  case 62:
#line 149 "Parser.ypp"
    { (yyval.node) = nodeAddChild2(newNodeI(LinkEtc, 3), nodeAddChild(newNode(LinkTarget), (yysemantic_stack_[(5) - (2)].node)), (yysemantic_stack_[(5) - (3)].node)); ;}
    break;

  case 63:
#line 151 "Parser.ypp"
    { (yyval.node) = makeTextBlock(newNodeS(TextToken, "[["), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 64:
#line 152 "Parser.ypp"
    { (yyval.node) = makeTextBlock2(newNodeS(TextToken, "[["), (yysemantic_stack_[(3) - (2)].node), newNodeS(TextToken, "|")); ;}
    break;

  case 65:
#line 153 "Parser.ypp"
    { (yyval.node) = makeTextBlock2(newNodeS(TextToken, "[["), (yysemantic_stack_[(3) - (2)].node), convertPipeSeriesToText((yysemantic_stack_[(3) - (3)].node))); ;}
    break;

  case 66:
#line 154 "Parser.ypp"
    { (yyval.node) = makeTextBlock3(newNodeS(TextToken, "[["), (yysemantic_stack_[(4) - (2)].node), convertPipeSeriesToText((yysemantic_stack_[(4) - (3)].node)), newNodeS(TextToken, "|")); ;}
    break;

  case 67:
#line 155 "Parser.ypp"
    { (yyval.node) = makeTextBlock(newNodeS(TextToken, "[[:"), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 68:
#line 156 "Parser.ypp"
    { (yyval.node) = makeTextBlock2(newNodeS(TextToken, "[[:"), (yysemantic_stack_[(3) - (2)].node), newNodeS(TextToken, "|")); ;}
    break;

  case 69:
#line 157 "Parser.ypp"
    { (yyval.node) = makeTextBlock2(newNodeS(TextToken, "[[:"), (yysemantic_stack_[(3) - (2)].node), convertPipeSeriesToText((yysemantic_stack_[(3) - (3)].node))); ;}
    break;

  case 70:
#line 158 "Parser.ypp"
    { (yyval.node) = makeTextBlock3(newNodeS(TextToken, "[[:"), (yysemantic_stack_[(4) - (2)].node), convertPipeSeriesToText((yysemantic_stack_[(4) - (3)].node)), newNodeS(TextToken, "|")); ;}
    break;

  case 71:
#line 160 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(3) - (1)].node), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 72:
#line 161 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(3) - (1)].node), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 73:
#line 162 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 74:
#line 164 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(3) - (1)].node), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 75:
#line 165 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(3) - (1)].node), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 76:
#line 166 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 77:
#line 168 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(3) - (1)].node), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 78:
#line 169 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(3) - (1)].node), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 79:
#line 170 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 80:
#line 172 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(3) - (1)].node), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 81:
#line 173 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(3) - (1)].node), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 82:
#line 174 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 83:
#line 176 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(3) - (1)].node), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 84:
#line 177 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(3) - (1)].node), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 85:
#line 178 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 86:
#line 180 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(3) - (1)].node), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 87:
#line 181 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(3) - (1)].node), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 88:
#line 182 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 89:
#line 184 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(3) - (1)].node), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 90:
#line 185 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(3) - (1)].node), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 91:
#line 186 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 92:
#line 188 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(3) - (1)].node), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 93:
#line 189 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(3) - (1)].node), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 94:
#line 190 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 95:
#line 192 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(3) - (1)].node), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 96:
#line 193 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(3) - (1)].node), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 97:
#line 194 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 98:
#line 196 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(3) - (1)].node), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 99:
#line 197 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(3) - (1)].node), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 100:
#line 198 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 101:
#line 200 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(3) - (1)].node), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 102:
#line 201 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 103:
#line 203 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(2) - (1)].node), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 104:
#line 205 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 105:
#line 206 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (2)].node); ;}
    break;

  case 106:
#line 207 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 107:
#line 208 "Parser.ypp"
    { (yyval.node) = nodeAddSibling((yysemantic_stack_[(2) - (1)].node), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 108:
#line 209 "Parser.ypp"
    { (yyval.node) = processPreBlock((yysemantic_stack_[(1) - (1)].node)); ;}
    break;

  case 109:
#line 210 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 110:
#line 211 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 111:
#line 212 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 112:
#line 213 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 113:
#line 214 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 114:
#line 216 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(LinkOption), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 115:
#line 217 "Parser.ypp"
    { (yyval.node) = nodeAddSibling((yysemantic_stack_[(3) - (1)].node), nodeAddChild(newNode(LinkOption), (yysemantic_stack_[(3) - (3)].node))); ;}
    break;

  case 116:
#line 219 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, ""); ;}
    break;

  case 117:
#line 220 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 118:
#line 222 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(Italics), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 119:
#line 223 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(Italics), makeTextBlock ((yysemantic_stack_[(5) - (2)].node), nodeAddChild(newNode(Bold), (yysemantic_stack_[(5) - (4)].node)))); ;}
    break;

  case 120:
#line 224 "Parser.ypp"
    { (yyval.node) = makeTextBlock2(nodeAddChild(newNode(Italics), (yysemantic_stack_[(4) - (2)].node)), newNodeS(TextToken, "'"), (yysemantic_stack_[(4) - (4)].node)); ;}
    break;

  case 121:
#line 225 "Parser.ypp"
    { (yyval.node) = makeTextBlock(newNodeS(TextToken, "''"), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 122:
#line 226 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(Bold), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 123:
#line 227 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(Bold), makeTextBlock((yysemantic_stack_[(5) - (2)].node), nodeAddChild (newNode (Italics), (yysemantic_stack_[(5) - (4)].node)))); ;}
    break;

  case 124:
#line 231 "Parser.ypp"
    { (yyval.node) = processNestedItalics(makeTextBlock2(newNodeS(TextToken, "'"), nodeAddChild(newNode(Italics), (yysemantic_stack_[(4) - (2)].node)), (yysemantic_stack_[(4) - (4)].node))); ;}
    break;

  case 125:
#line 232 "Parser.ypp"
    { (yyval.node) = processNestedItalics(makeTextBlock(newNodeS(TextToken, "'"), nodeAddChild(newNode(Italics), (yysemantic_stack_[(3) - (2)].node)))); ;}
    break;

  case 126:
#line 233 "Parser.ypp"
    { (yyval.node) = makeTextBlock(newNodeS(TextToken, "'''"), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 127:
#line 234 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(Italics), nodeAddChild(newNode(Bold), (yysemantic_stack_[(3) - (2)].node))); ;}
    break;

  case 128:
#line 235 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(Italics), makeTextBlock(nodeAddChild(newNode(Bold), (yysemantic_stack_[(5) - (2)].node)), (yysemantic_stack_[(5) - (4)].node))); ;}
    break;

  case 129:
#line 236 "Parser.ypp"
    { (yyval.node) = makeTextBlock2(newNodeS(TextToken, "''"), nodeAddChild(newNode(Bold), (yysemantic_stack_[(4) - (2)].node)), (yysemantic_stack_[(4) - (4)].node)); ;}
    break;

  case 130:
#line 237 "Parser.ypp"
    { (yyval.node) = makeTextBlock(newNodeS(TextToken, "''"), nodeAddChild(newNode(Bold), (yysemantic_stack_[(3) - (2)].node))); ;}
    break;

  case 131:
#line 238 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(Bold), makeTextBlock(nodeAddChild(newNode(Italics), (yysemantic_stack_[(5) - (2)].node)), (yysemantic_stack_[(5) - (4)].node))); ;}
    break;

  case 132:
#line 239 "Parser.ypp"
    { (yyval.node) = makeTextBlock2(newNodeS(TextToken, "'''"), nodeAddChild(newNode(Italics), (yysemantic_stack_[(4) - (2)].node)), (yysemantic_stack_[(4) - (4)].node)); ;}
    break;

  case 133:
#line 240 "Parser.ypp"
    { (yyval.node) = makeTextBlock(newNodeS(TextToken, "'''"), nodeAddChild(newNode(Italics), (yysemantic_stack_[(3) - (2)].node))); ;}
    break;

  case 134:
#line 241 "Parser.ypp"
    { (yyval.node) = makeTextBlock(newNodeS(TextToken, "'''''"), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 135:
#line 243 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(Italics), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 136:
#line 244 "Parser.ypp"
    { (yyval.node) = makeTextBlock(newNodeS(TextToken, "''"), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 137:
#line 246 "Parser.ypp"
    { (yyval.node) = nodeAddChild (newNode (Bold), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 138:
#line 247 "Parser.ypp"
    { (yyval.node) = makeTextBlock (newNodeS (TextToken, "'''"), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 139:
#line 249 "Parser.ypp"
    { (yyval.node) = nodeAddChild2(newNode(Table), (yysemantic_stack_[(4) - (2)].node), (yysemantic_stack_[(4) - (3)].node)); ;}
    break;

  case 140:
#line 250 "Parser.ypp"
    { (yyval.node) = nodeAddChild2(newNode(Table), (yysemantic_stack_[(3) - (2)].node), (yysemantic_stack_[(3) - (3)].node)); ;}
    break;

  case 141:
#line 251 "Parser.ypp"
    { (yyval.node) = nodeAddChild2(newNode(Table), (yysemantic_stack_[(5) - (2)].node), (yysemantic_stack_[(5) - (4)].node)); ;}
    break;

  case 142:
#line 252 "Parser.ypp"
    { (yyval.node) = nodeAddChild2(newNode(Table), (yysemantic_stack_[(4) - (2)].node), (yysemantic_stack_[(4) - (4)].node)); ;}
    break;

  case 143:
#line 253 "Parser.ypp"
    { (yyval.node) = nodeAddChild2(newNode(Table), (yysemantic_stack_[(5) - (2)].node), (yysemantic_stack_[(5) - (4)].node)); ;}
    break;

  case 144:
#line 254 "Parser.ypp"
    { (yyval.node) = nodeAddChild2(newNode(Table), (yysemantic_stack_[(6) - (2)].node), (yysemantic_stack_[(6) - (5)].node)); ;}
    break;

  case 145:
#line 255 "Parser.ypp"
    { (yyval.node) = nodeAddChild2(newNode(Table), (yysemantic_stack_[(7) - (2)].node), (yysemantic_stack_[(7) - (6)].node)); ;}
    break;

  case 146:
#line 256 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(Table), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 147:
#line 257 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(Table), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 148:
#line 258 "Parser.ypp"
    { (yyval.node) = nodeAddChild (newNode(Table), (yysemantic_stack_[(4) - (3)].node)); ;}
    break;

  case 149:
#line 259 "Parser.ypp"
    { (yyval.node) = nodeAddChild (newNode(Table), (yysemantic_stack_[(3) - (3)].node)); ;}
    break;

  case 150:
#line 261 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(Paragraph), makeTextBlock(newNodeS(TextToken, addSpaces("{|", (yysemantic_stack_[(3) - (1)].num))), convertAttributesToText((yysemantic_stack_[(3) - (2)].node)))); ;}
    break;

  case 151:
#line 262 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(Paragraph), makeTextBlock2(newNodeS(TextToken, addSpaces("{|", (yysemantic_stack_[(4) - (1)].num))), convertAttributesToText((yysemantic_stack_[(4) - (2)].node)), (yysemantic_stack_[(4) - (3)].node))); ;}
    break;

  case 152:
#line 263 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(Paragraph), makeTextBlock(newNodeS(TextToken, addSpaces("{|", (yysemantic_stack_[(3) - (1)].num))), (yysemantic_stack_[(3) - (3)].node))); ;}
    break;

  case 153:
#line 264 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(Paragraph), newNodeS(TextToken, addSpaces("{|", (yysemantic_stack_[(2) - (1)].num)))); ;}
    break;

  case 154:
#line 266 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 155:
#line 267 "Parser.ypp"
    { (yyval.node) = nodeAddSibling ((yysemantic_stack_[(2) - (1)].node), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 156:
#line 269 "Parser.ypp"
    { (yyval.node) = nodeAddChild2(newNode(TableRow), (yysemantic_stack_[(3) - (2)].node), (yysemantic_stack_[(3) - (3)].node)); ;}
    break;

  case 157:
#line 270 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(TableRow), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 158:
#line 271 "Parser.ypp"
    { (yyval.node) = nodeAddChild2(newNode(TableRow), (yysemantic_stack_[(4) - (2)].node), (yysemantic_stack_[(4) - (4)].node)); ;}
    break;

  case 159:
#line 272 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(TableRow), (yysemantic_stack_[(3) - (3)].node)); ;}
    break;

  case 160:
#line 274 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(TableRow), (yysemantic_stack_[(1) - (1)].node)); ;}
    break;

  case 161:
#line 276 "Parser.ypp"
    { freeRecursivelyWithSiblings ((yysemantic_stack_[(3) - (2)].node)); (yyval.node) = 0; ;}
    break;

  case 162:
#line 277 "Parser.ypp"
    { freeRecursivelyWithSiblings ((yysemantic_stack_[(2) - (2)].node)); (yyval.node) = 0; ;}
    break;

  case 163:
#line 278 "Parser.ypp"
    { (yyval.node) = 0; ;}
    break;

  case 164:
#line 279 "Parser.ypp"
    { (yyval.node) = 0; ;}
    break;

  case 165:
#line 280 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 166:
#line 282 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 167:
#line 283 "Parser.ypp"
    { (yyval.node) = nodeAddSibling((yysemantic_stack_[(2) - (1)].node), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 168:
#line 285 "Parser.ypp"
    { (yyval.node) = nodeAddChild2(newNode(TableCell), (yysemantic_stack_[(4) - (2)].node), processTableCellContents((yysemantic_stack_[(4) - (4)].node))); ;}
    break;

  case 169:
#line 286 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(TableCell), processTableCellContents((yysemantic_stack_[(2) - (2)].node))); ;}
    break;

  case 170:
#line 287 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(TableCell), (yysemantic_stack_[(4) - (2)].node)); ;}
    break;

  case 171:
#line 288 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(TableCell), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 172:
#line 289 "Parser.ypp"
    { (yyval.node) = newNode(TableCell); ;}
    break;

  case 173:
#line 290 "Parser.ypp"
    { (yyval.node) = newNode(TableCell); ;}
    break;

  case 174:
#line 291 "Parser.ypp"
    { (yyval.node) = nodeAddChild2(newNode(TableHead), (yysemantic_stack_[(4) - (2)].node), processTableCellContents((yysemantic_stack_[(4) - (4)].node))); ;}
    break;

  case 175:
#line 292 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(TableHead), processTableCellContents((yysemantic_stack_[(2) - (2)].node))); ;}
    break;

  case 176:
#line 293 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(TableHead), (yysemantic_stack_[(4) - (2)].node)); ;}
    break;

  case 177:
#line 294 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(TableHead), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 178:
#line 295 "Parser.ypp"
    { (yyval.node) = newNode(TableHead); ;}
    break;

  case 179:
#line 296 "Parser.ypp"
    { (yyval.node) = newNode(TableHead); ;}
    break;

  case 180:
#line 298 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 181:
#line 299 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(2) - (2)].node); ;}
    break;

  case 182:
#line 301 "Parser.ypp"
    { (yyval.node) = nodeAddChild2(newNode(TableCaption), (yysemantic_stack_[(4) - (2)].node), (yysemantic_stack_[(4) - (4)].node)); ;}
    break;

  case 183:
#line 302 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(TableCaption), makeTextBlock(convertAttributesToText((yysemantic_stack_[(3) - (2)].node)), (yysemantic_stack_[(3) - (3)].node))); ;}
    break;

  case 184:
#line 303 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(TableCaption), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 185:
#line 304 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(TableCaption), makeTextBlock(convertAttributesToText((yysemantic_stack_[(3) - (2)].node)), newNodeS(TextToken, "|"))); ;}
    break;

  case 186:
#line 305 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(TableCaption), convertAttributesToText((yysemantic_stack_[(2) - (2)].node))); ;}
    break;

  case 187:
#line 306 "Parser.ypp"
    { (yyval.node) = 0; ;}
    break;

  case 188:
#line 310 "Parser.ypp"
    { (yyval.node) = newNodeA(0, *(yysemantic_stack_[(1) - (1)].ad), 0, 0); ;}
    break;

  case 189:
#line 311 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNodeA(1, *(yysemantic_stack_[(3) - (1)].ad), (yysemantic_stack_[(3) - (2)].num), strtrimNC((yysemantic_stack_[(3) - (3)].node))), (yysemantic_stack_[(3) - (3)].node)); ;}
    break;

  case 190:
#line 312 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNodeA(2, *(yysemantic_stack_[(5) - (1)].ad), (yysemantic_stack_[(5) - (2)].num), (yysemantic_stack_[(5) - (5)].num)), (yysemantic_stack_[(5) - (4)].node)); ;}
    break;

  case 191:
#line 313 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNodeA(3, *(yysemantic_stack_[(5) - (1)].ad), (yysemantic_stack_[(5) - (2)].num), (yysemantic_stack_[(5) - (5)].num)), (yysemantic_stack_[(5) - (4)].node)); ;}
    break;

  case 192:
#line 314 "Parser.ypp"
    { (yyval.node) = newNodeA(3, *(yysemantic_stack_[(4) - (1)].ad), (yysemantic_stack_[(4) - (2)].num), (yysemantic_stack_[(4) - (4)].num)); ;}
    break;

  case 193:
#line 315 "Parser.ypp"
    { (yyval.node) = newNodeA(1, *(yysemantic_stack_[(2) - (1)].ad), (yysemantic_stack_[(2) - (2)].num), 0); ;}
    break;

  case 194:
#line 317 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(AttributeGroup), (yysemantic_stack_[(1) - (1)].node)); ;}
    break;

  case 195:
#line 318 "Parser.ypp"
    { (yyval.node) = nodeAddChild((yysemantic_stack_[(2) - (1)].node), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 196:
#line 321 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 197:
#line 322 "Parser.ypp"
    { (yyval.node) = makeTextBlock((yysemantic_stack_[(2) - (1)].node), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 198:
#line 323 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 199:
#line 324 "Parser.ypp"
    { (yyval.node) = makeTextBlock((yysemantic_stack_[(2) - (1)].node), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 200:
#line 325 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 201:
#line 326 "Parser.ypp"
    { (yyval.node) = makeTextBlock((yysemantic_stack_[(2) - (1)].node), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 202:
#line 327 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 203:
#line 328 "Parser.ypp"
    { (yyval.node) = makeTextBlock((yysemantic_stack_[(2) - (1)].node), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 204:
#line 329 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 205:
#line 330 "Parser.ypp"
    { (yyval.node) = makeTextBlock((yysemantic_stack_[(2) - (1)].node), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 206:
#line 331 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 207:
#line 332 "Parser.ypp"
    { (yyval.node) = makeTextBlock((yysemantic_stack_[(2) - (1)].node), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 208:
#line 334 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 209:
#line 335 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 210:
#line 336 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 211:
#line 337 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 212:
#line 338 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 213:
#line 339 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 214:
#line 340 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 215:
#line 341 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 216:
#line 342 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 217:
#line 343 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 218:
#line 344 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 219:
#line 345 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 220:
#line 347 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 221:
#line 348 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 222:
#line 349 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 223:
#line 350 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, "|"); ;}
    break;

  case 224:
#line 351 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, "]]"); ;}
    break;

  case 225:
#line 352 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, "''"); ;}
    break;

  case 226:
#line 353 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, "'''"); ;}
    break;

  case 227:
#line 354 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, "'''''"); ;}
    break;

  case 228:
#line 355 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, addSpaces ("=", (yysemantic_stack_[(1) - (1)].num))); ;}
    break;

  case 229:
#line 356 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, addSpaces ("    {|", (yysemantic_stack_[(1) - (1)].num))); ;}
    break;

  case 230:
#line 357 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, "|}"); ;}
    break;

  case 231:
#line 358 "Parser.ypp"
    { (yyval.node) = convertTableRowToText((yysemantic_stack_[(1) - (1)].num)); ;}
    break;

  case 232:
#line 359 "Parser.ypp"
    { (yyval.node) = convertTableCellToText((yysemantic_stack_[(1) - (1)].num)); ;}
    break;

  case 233:
#line 360 "Parser.ypp"
    { (yyval.node) = convertTableHeadToText((yysemantic_stack_[(1) - (1)].num)); ;}
    break;

  case 234:
#line 361 "Parser.ypp"
    { (yyval.node) = convertTableCaptionToText((yysemantic_stack_[(1) - (1)].num)); ;}
    break;

  case 235:
#line 362 "Parser.ypp"
    { (yyval.node) = convertAttributeDataToText(*(yysemantic_stack_[(1) - (1)].ad)); ;}
    break;

  case 236:
#line 363 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 237:
#line 364 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 238:
#line 367 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 239:
#line 368 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 240:
#line 369 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 241:
#line 370 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, "|"); ;}
    break;

  case 242:
#line 371 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, "]]"); ;}
    break;

  case 243:
#line 372 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, addSpaces ("    {|", (yysemantic_stack_[(1) - (1)].num))); ;}
    break;

  case 244:
#line 373 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, "|}"); ;}
    break;

  case 245:
#line 374 "Parser.ypp"
    { (yyval.node) = convertTableRowToText((yysemantic_stack_[(1) - (1)].num)); ;}
    break;

  case 246:
#line 375 "Parser.ypp"
    { (yyval.node) = convertTableCellToText((yysemantic_stack_[(1) - (1)].num)); ;}
    break;

  case 247:
#line 376 "Parser.ypp"
    { (yyval.node) = convertTableHeadToText((yysemantic_stack_[(1) - (1)].num)); ;}
    break;

  case 248:
#line 377 "Parser.ypp"
    { (yyval.node) = convertTableCaptionToText((yysemantic_stack_[(1) - (1)].num)); ;}
    break;

  case 249:
#line 378 "Parser.ypp"
    { (yyval.node) = convertAttributeDataToText(*(yysemantic_stack_[(1) - (1)].ad)); ;}
    break;

  case 250:
#line 379 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 251:
#line 380 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 252:
#line 382 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 253:
#line 383 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 254:
#line 384 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 255:
#line 385 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, "|"); ;}
    break;

  case 256:
#line 386 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, "]]"); ;}
    break;

  case 257:
#line 387 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, addSpaces("    {|", (yysemantic_stack_[(1) - (1)].num))); ;}
    break;

  case 258:
#line 388 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, "|}"); ;}
    break;

  case 259:
#line 389 "Parser.ypp"
    { (yyval.node) = convertTableRowToText((yysemantic_stack_[(1) - (1)].num)); ;}
    break;

  case 260:
#line 390 "Parser.ypp"
    { (yyval.node) = convertTableCellToText((yysemantic_stack_[(1) - (1)].num)); ;}
    break;

  case 261:
#line 391 "Parser.ypp"
    { (yyval.node) = convertTableHeadToText((yysemantic_stack_[(1) - (1)].num)); ;}
    break;

  case 262:
#line 392 "Parser.ypp"
    { (yyval.node) = convertTableCaptionToText((yysemantic_stack_[(1) - (1)].num)); ;}
    break;

  case 263:
#line 393 "Parser.ypp"
    { (yyval.node) = convertAttributeDataToText(*(yysemantic_stack_[(1) - (1)].ad)); ;}
    break;

  case 264:
#line 394 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 265:
#line 395 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 266:
#line 397 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 267:
#line 398 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 268:
#line 399 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 269:
#line 400 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, "|"); ;}
    break;

  case 270:
#line 401 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, "]]"); ;}
    break;

  case 271:
#line 402 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, addSpaces ("    {|", (yysemantic_stack_[(1) - (1)].num))); ;}
    break;

  case 272:
#line 403 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, "|}"); ;}
    break;

  case 273:
#line 404 "Parser.ypp"
    { (yyval.node) = convertTableRowToText((yysemantic_stack_[(1) - (1)].num)); ;}
    break;

  case 274:
#line 405 "Parser.ypp"
    { (yyval.node) = convertTableCellToText((yysemantic_stack_[(1) - (1)].num)); ;}
    break;

  case 275:
#line 406 "Parser.ypp"
    { (yyval.node) = convertTableHeadToText((yysemantic_stack_[(1) - (1)].num)); ;}
    break;

  case 276:
#line 407 "Parser.ypp"
    { (yyval.node) = convertTableCaptionToText((yysemantic_stack_[(1) - (1)].num)); ;}
    break;

  case 277:
#line 408 "Parser.ypp"
    { (yyval.node) = convertAttributeDataToText(*(yysemantic_stack_[(1) - (1)].ad)); ;}
    break;

  case 278:
#line 409 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 279:
#line 411 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 280:
#line 412 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 281:
#line 413 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 282:
#line 414 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, "|"); ;}
    break;

  case 283:
#line 415 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, "]]"); ;}
    break;

  case 284:
#line 416 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, "''"); ;}
    break;

  case 285:
#line 417 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, "'''"); ;}
    break;

  case 286:
#line 418 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, "'''''"); ;}
    break;

  case 287:
#line 419 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, addSpaces("=", (yysemantic_stack_[(1) - (1)].num))); ;}
    break;

  case 288:
#line 420 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 289:
#line 421 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 290:
#line 423 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 291:
#line 424 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 292:
#line 425 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 293:
#line 426 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, "''"); ;}
    break;

  case 294:
#line 427 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, "'''"); ;}
    break;

  case 295:
#line 428 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, "'''''"); ;}
    break;

  case 296:
#line 429 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, addSpaces("=", (yysemantic_stack_[(1) - (1)].num))); ;}
    break;

  case 297:
#line 430 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, addSpaces("    {|", (yysemantic_stack_[(1) - (1)].num))); ;}
    break;

  case 298:
#line 431 "Parser.ypp"
    { (yyval.node) = newNodeS(TextToken, "|}"); ;}
    break;

  case 299:
#line 432 "Parser.ypp"
    { (yyval.node) = convertTableRowToText((yysemantic_stack_[(1) - (1)].num)); ;}
    break;

  case 300:
#line 433 "Parser.ypp"
    { (yyval.node) = convertTableCellToText((yysemantic_stack_[(1) - (1)].num)); ;}
    break;

  case 301:
#line 434 "Parser.ypp"
    { (yyval.node) = convertTableHeadToText((yysemantic_stack_[(1) - (1)].num)); ;}
    break;

  case 302:
#line 435 "Parser.ypp"
    { (yyval.node) = convertTableCaptionToText((yysemantic_stack_[(1) - (1)].num)); ;}
    break;

  case 303:
#line 436 "Parser.ypp"
    { (yyval.node) = convertAttributeDataToText(*(yysemantic_stack_[(1) - (1)].ad)); ;}
    break;

  case 304:
#line 437 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 305:
#line 438 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 306:
#line 440 "Parser.ypp"
    { (yyval.node) = 0; ;}
    break;

  case 307:
#line 441 "Parser.ypp"
    { (yyval.node) = 0; ;}
    break;

  case 308:
#line 442 "Parser.ypp"
    { (yyval.node) = 0; ;}
    break;

  case 309:
#line 443 "Parser.ypp"
    { (yyval.node) = 0; ;}
    break;

  case 310:
#line 445 "Parser.ypp"
    { (yyval.node) = 0; ;}
    break;

  case 311:
#line 446 "Parser.ypp"
    { (yyval.node) = (yysemantic_stack_[(1) - (1)].node); ;}
    break;

  case 312:
#line 447 "Parser.ypp"
    { (yyval.node) = newNodeI(Newlines, 0); ;}
    break;

  case 313:
#line 448 "Parser.ypp"
    { (yysemantic_stack_[(2) - (1)].node)->data.num++; (yyval.node) = (yysemantic_stack_[(2) - (1)].node); ;}
    break;

  case 314:
#line 450 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(Paragraph), (yysemantic_stack_[(2) - (1)].node)); ;}
    break;

  case 315:
#line 451 "Parser.ypp"
    { (yyval.node) = nodeAddChild2((yysemantic_stack_[(3) - (1)].node), newNodeS(TextToken, " "), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 316:
#line 453 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(Paragraph), (yysemantic_stack_[(1) - (1)].node)); ;}
    break;

  case 317:
#line 454 "Parser.ypp"
    { (yyval.node) = nodeAddChild2((yysemantic_stack_[(2) - (1)].node), newNodeS(TextToken, " "), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 318:
#line 460 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(Paragraph), (yysemantic_stack_[(2) - (1)].node)); ;}
    break;

  case 319:
#line 461 "Parser.ypp"
    { (yyval.node) = nodeAddChild2(newNode(Paragraph), convertAttributesToText((yysemantic_stack_[(3) - (1)].node)), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 320:
#line 462 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(Paragraph), convertAttributesToText((yysemantic_stack_[(2) - (1)].node))); ;}
    break;

  case 321:
#line 463 "Parser.ypp"
    { (yyval.node) = nodeAddChild2((yysemantic_stack_[(3) - (1)].node), newNodeS(TextToken, " "), (yysemantic_stack_[(3) - (2)].node)); ;}
    break;

  case 322:
#line 464 "Parser.ypp"
    { (yyval.node) = nodeAddChild3((yysemantic_stack_[(4) - (1)].node), newNodeS(TextToken, " "), convertAttributesToText((yysemantic_stack_[(4) - (2)].node)), (yysemantic_stack_[(4) - (3)].node)); ;}
    break;

  case 323:
#line 465 "Parser.ypp"
    { (yyval.node) = nodeAddChild2((yysemantic_stack_[(3) - (1)].node), newNodeS(TextToken, " "), convertAttributesToText((yysemantic_stack_[(3) - (2)].node))); ;}
    break;

  case 324:
#line 467 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(Paragraph), (yysemantic_stack_[(1) - (1)].node)); ;}
    break;

  case 325:
#line 468 "Parser.ypp"
    { (yyval.node) = nodeAddChild2(newNode(Paragraph), convertAttributesToText((yysemantic_stack_[(2) - (1)].node)), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 326:
#line 469 "Parser.ypp"
    { (yyval.node) = nodeAddChild(newNode(Paragraph), convertAttributesToText((yysemantic_stack_[(1) - (1)].node))); ;}
    break;

  case 327:
#line 470 "Parser.ypp"
    { (yyval.node) = nodeAddChild2((yysemantic_stack_[(2) - (1)].node), newNodeS(TextToken, " "), (yysemantic_stack_[(2) - (2)].node)); ;}
    break;

  case 328:
#line 471 "Parser.ypp"
    { (yyval.node) = nodeAddChild3((yysemantic_stack_[(3) - (1)].node), newNodeS(TextToken, " "), convertAttributesToText((yysemantic_stack_[(3) - (2)].node)), (yysemantic_stack_[(3) - (3)].node)); ;}
    break;

  case 329:
#line 472 "Parser.ypp"
    { (yyval.node) = nodeAddChild2((yysemantic_stack_[(2) - (1)].node), newNodeS(TextToken, " "), convertAttributesToText((yysemantic_stack_[(2) - (2)].node))); ;}
    break;


    /* Line 675 of lalr1.cc.  */
#line 2033 "Parser.tab.cpp"
	default: break;
      }
    YY_SYMBOL_PRINT ("-> $$ =", yyr1_[yyn], &yyval, &yyloc);

    yypop_ (yylen);
    yylen = 0;
    YY_STACK_PRINT ();

    yysemantic_stack_.push (yyval);
    yylocation_stack_.push (yyloc);

    /* Shift the result of the reduction.  */
    yyn = yyr1_[yyn];
    yystate = yypgoto_[yyn - yyntokens_] + yystate_stack_[0];
    if (0 <= yystate && yystate <= yylast_
	&& yycheck_[yystate] == yystate_stack_[0])
      yystate = yytable_[yystate];
    else
      yystate = yydefgoto_[yyn - yyntokens_];
    goto yynewstate;

  /*------------------------------------.
  | yyerrlab -- here on detecting error |
  `------------------------------------*/
  yyerrlab:
    /* If not already recovering from an error, report this error.  */
    if (!yyerrstatus_)
      {
	++yynerrs_;
	error (yylloc, yysyntax_error_ (yystate, yytoken));
      }

    yyerror_range[0] = yylloc;
    if (yyerrstatus_ == 3)
      {
	/* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

	if (yychar <= yyeof_)
	  {
	  /* Return failure if at end of input.  */
	  if (yychar == yyeof_)
	    YYABORT;
	  }
	else
	  {
	    yydestruct_ ("Error: discarding", yytoken, &yylval, &yylloc);
	    yychar = yyempty_;
	  }
      }

    /* Else will try to reuse look-ahead token after shifting the error
       token.  */
    goto yyerrlab1;


  /*---------------------------------------------------.
  | yyerrorlab -- error raised explicitly by YYERROR.  |
  `---------------------------------------------------*/
  yyerrorlab:

    /* Pacify compilers like GCC when the user code never invokes
       YYERROR and the label yyerrorlab therefore never appears in user
       code.  */
    if (false)
      goto yyerrorlab;

    yyerror_range[0] = yylocation_stack_[yylen - 1];
    /* Do not reclaim the symbols of the rule which action triggered
       this YYERROR.  */
    yypop_ (yylen);
    yylen = 0;
    yystate = yystate_stack_[0];
    goto yyerrlab1;

  /*-------------------------------------------------------------.
  | yyerrlab1 -- common code for both syntax error and YYERROR.  |
  `-------------------------------------------------------------*/
  yyerrlab1:
    yyerrstatus_ = 3;	/* Each real token shifted decrements this.  */

    for (;;)
      {
	yyn = yypact_[yystate];
	if (yyn != yypact_ninf_)
	{
	  yyn += yyterror_;
	  if (0 <= yyn && yyn <= yylast_ && yycheck_[yyn] == yyterror_)
	    {
	      yyn = yytable_[yyn];
	      if (0 < yyn)
		break;
	    }
	}

	/* Pop the current state because it cannot handle the error token.  */
	if (yystate_stack_.height () == 1)
	YYABORT;

	yyerror_range[0] = yylocation_stack_[0];
	yydestruct_ ("Error: popping",
		     yystos_[yystate],
		     &yysemantic_stack_[0], &yylocation_stack_[0]);
	yypop_ ();
	yystate = yystate_stack_[0];
	YY_STACK_PRINT ();
      }

    if (yyn == yyfinal_)
      goto yyacceptlab;

    yyerror_range[1] = yylloc;
    // Using YYLLOC is tempting, but would change the location of
    // the look-ahead.  YYLOC is available though.
    YYLLOC_DEFAULT (yyloc, (yyerror_range - 1), 2);
    yysemantic_stack_.push (yylval);
    yylocation_stack_.push (yyloc);

    /* Shift the error token.  */
    YY_SYMBOL_PRINT ("Shifting", yystos_[yyn],
		   &yysemantic_stack_[0], &yylocation_stack_[0]);

    yystate = yyn;
    goto yynewstate;

    /* Accept.  */
  yyacceptlab:
    yyresult = 0;
    goto yyreturn;

    /* Abort.  */
  yyabortlab:
    yyresult = 1;
    goto yyreturn;

  yyreturn:
    if (yychar != yyeof_ && yychar != yyempty_)
      yydestruct_ ("Cleanup: discarding lookahead", yytoken, &yylval, &yylloc);

    /* Do not reclaim the symbols of the rule which action triggered
       this YYABORT or YYACCEPT.  */
    yypop_ (yylen);
    while (yystate_stack_.height () != 1)
      {
	yydestruct_ ("Cleanup: popping",
		   yystos_[yystate_stack_[0]],
		   &yysemantic_stack_[0],
		   &yylocation_stack_[0]);
	yypop_ ();
      }

    return yyresult;
  }

  // Generate an error message.
  std::string
  Parser::yysyntax_error_ (int yystate, int tok)
  {
    std::string res;
    YYUSE (yystate);
#if YYERROR_VERBOSE
    int yyn = yypact_[yystate];
    if (yypact_ninf_ < yyn && yyn <= yylast_)
      {
	/* Start YYX at -YYN if negative to avoid negative indexes in
	   YYCHECK.  */
	int yyxbegin = yyn < 0 ? -yyn : 0;

	/* Stay within bounds of both yycheck and yytname.  */
	int yychecklim = yylast_ - yyn + 1;
	int yyxend = yychecklim < yyntokens_ ? yychecklim : yyntokens_;
	int count = 0;
	for (int x = yyxbegin; x < yyxend; ++x)
	  if (yycheck_[x + yyn] == x && x != yyterror_)
	    ++count;

	// FIXME: This method of building the message is not compatible
	// with internationalization.  It should work like yacc.c does it.
	// That is, first build a string that looks like this:
	// "syntax error, unexpected %s or %s or %s"
	// Then, invoke YY_ on this string.
	// Finally, use the string as a format to output
	// yytname_[tok], etc.
	// Until this gets fixed, this message appears in English only.
	res = "syntax error, unexpected ";
	res += yytnamerr_ (yytname_[tok]);
	if (count < 5)
	  {
	    count = 0;
	    for (int x = yyxbegin; x < yyxend; ++x)
	      if (yycheck_[x + yyn] == x && x != yyterror_)
		{
		  res += (!count++) ? ", expecting " : " or ";
		  res += yytnamerr_ (yytname_[x]);
		}
	  }
      }
    else
#endif
      res = YY_("syntax error");
    return res;
  }


  /* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
     STATE-NUM.  */
  const short int Parser::yypact_ninf_ = -189;
  const short int
  Parser::yypact_[] =
  {
      1707,  -189,  -189,  3471,  3471,  -189,  -189,    55,  3226,   129,
     129,   129,   129,  3226,  4010,  3814,  3863,  2246,  -189,  -189,
    -189,  -189,  -189,  -189,  -189,  1217,  1266,  1315,  1364,  -189,
    1413,  1462,  1511,  1560,  1609,  1658,  1087,    14,  1854,  -189,
      28,    19,  -189,    28,    50,    67,    26,  -189,  -189,  -189,
    -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,
    -189,    28,  -189,    28,  2295,  -189,  -189,    58,  1756,  2344,
    -189,  -189,  4010,  3814,  3863,  -189,  -189,  -189,  -189,  -189,
    -189,  -189,  -189,  -189,  -189,  -189,  3275,  -189,  -189,  3324,
    -189,    66,  3226,  -189,  -189,  -189,  -189,  1903,  1903,  1903,
    1903,  2393,  -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,
    -189,  -189,  -189,  -189,  3373,  -189,  -189,  -189,  -189,  -189,
    -189,  4010,  -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,
    -189,  3520,  -189,  -189,  -189,  -189,  -189,  -189,  4010,  -189,
    -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,  3569,  -189,
    -189,  -189,  2099,  2099,    32,  2099,    57,   237,  -189,    22,
    -189,  -189,  -189,  2246,  2344,    60,    93,   108,   115,   279,
    2050,  1952,  2001,   468,  -189,  2442,  -189,    28,    19,    28,
     501,    28,   517,    28,    59,  4059,  2491,  4304,   524,  -189,
    2148,  4108,  -189,    78,  2540,  -189,    77,  2589,  -189,    28,
      19,    28,    28,    95,  1854,  -189,    28,  2344,  1805,  -189,
      74,  2638,  -189,    73,  2687,  -189,    56,  2736,  -189,    87,
    2785,  -189,    89,  2834,  -189,    88,  2883,  -189,    94,  1158,
    -189,  -189,  -189,    58,  -189,  -189,  -189,  -189,  -189,  -189,
    -189,  -189,  -189,  -189,  -189,  1854,  2932,  -189,  -189,  3422,
    -189,    43,  -189,  3422,  -189,    65,  -189,  -189,   136,  -189,
    -189,  -189,  -189,   138,   140,   145,   147,  -189,  -189,  3863,
    3814,  -189,  3912,  -189,  4010,  -189,  3961,  4010,  -189,  -189,
    -189,  -189,  -189,  -189,  4010,  3814,  3863,  2246,    57,  -189,
    -189,  -189,  -189,  4157,  -189,  2148,  -189,  4206,  2148,  2099,
    2099,    22,    32,    38,  -189,  2197,    20,    32,  -189,  2099,
    -189,  -189,   328,  -189,  2981,  -189,  3030,  -189,   398,  -189,
    -189,  -189,  -189,  -189,  -189,  -189,  4353,  -189,  -189,  -189,
    2442,  4255,  4402,  -189,  -189,  -189,  -189,  -189,  -189,  -189,
    -189,  -189,  -189,  -189,  -189,  1854,  -189,  -189,  -189,  -189,
    -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,
    -189,  -189,  3471,  3422,  -189,  -189,  3422,  -189,  -189,  -189,
    -189,  -189,  3618,  3667,  -189,  3716,  -189,  3765,  2099,  2099,
      22,    38,    22,  2099,   977,  -189,  -189,  4451,  -189,  3226,
    3079,  -189,   408,  -189,   444,  2981,  -189,  -189,  -189,  4500,
    -189,  -189,  3471,  -189,  -189,  -189,  -189,  -189,  -189,  2148,
    -189,  2148,    22,  -189,  -189,  3128,  -189,  3177,  -189,  -189,
     481,    60,  -189,  -189,  -189,  -189,   525,  -189
  };

  /* YYDEFACT[S] -- default rule to reduce with in state S when YYTABLE
     doesn't specify something else to do.  Zero means the default is an
     error.  */
  const unsigned short int
  Parser::yydefact_[] =
  {
         2,   222,   220,     0,     0,   224,   223,   312,   116,    45,
      45,    45,    45,    24,   227,   226,   225,   229,   232,   233,
     231,   230,   234,   235,   228,     0,     0,     0,     0,   219,
       0,     0,     0,     0,     0,     0,     0,     0,     5,     6,
     306,    10,    25,   306,    28,    29,    30,    31,    33,    35,
     236,   208,   209,   210,   211,   212,   213,   214,   217,   215,
     216,   218,   237,   306,   316,   221,   196,     3,     0,   306,
     292,   290,   295,   294,   293,   297,   300,   301,   299,   298,
     302,   303,   296,   304,   218,   305,    67,   291,   206,    63,
     229,   310,   117,    46,    47,    48,    49,   116,   116,   116,
     116,    23,   268,   266,   270,   269,   271,   274,   275,   273,
     272,   276,   277,   278,   134,   267,   202,   254,   252,   256,
     255,     0,   257,   260,   261,   259,   258,   262,   263,   264,
     265,   126,   253,   200,   240,   238,   242,   241,     0,   243,
     246,   247,   245,   244,   248,   249,   250,   251,   121,   239,
     198,   308,   173,   179,   164,   187,   188,   147,   154,   160,
     166,   165,   194,   306,   306,   153,   222,   220,   224,   223,
     227,   226,   225,   228,    73,   180,     8,   306,    16,   306,
     236,   218,   237,   306,     0,   326,     0,   324,   221,   204,
       0,   306,    76,     0,     0,    79,     0,     0,   102,   306,
     108,   306,   218,   103,   104,   106,   306,   306,     0,    82,
       0,     0,    85,     0,     0,    88,     0,     0,    91,     0,
       0,    94,     0,     0,    97,     0,     0,   100,     0,     0,
       1,     7,    11,   307,    26,    12,    32,    34,    36,    13,
      15,   314,   197,   309,   313,     4,   317,    14,    54,    68,
      59,    69,   207,    64,    55,    65,   312,    27,   311,    50,
      51,    52,    53,    38,    40,    43,    44,    22,   127,   130,
     133,   203,   136,   122,   125,   201,   138,     0,   118,   199,
     281,   279,   283,   282,   286,   285,   284,     0,   188,   287,
     288,   289,   169,   326,   280,   172,   175,   326,   178,   173,
     179,   157,   162,   163,   184,   186,   193,   164,   146,   187,
     155,   167,   140,   195,   306,   150,   307,   152,   149,     9,
      17,    18,    19,    21,    72,   320,   325,    71,   318,   205,
     181,   329,   327,    20,    75,    74,    78,    77,   109,   110,
     111,   101,   107,   113,   112,   105,    81,    80,    84,    83,
      87,    86,    90,    89,    93,    92,    96,    95,    99,    98,
     315,    60,   114,    70,    61,    56,    66,    57,    37,    39,
      41,    42,   129,   132,   135,   124,   137,   120,   171,   177,
     156,   161,   159,   185,   308,   183,   194,   324,   189,     0,
       0,   139,     0,   151,   142,     0,   148,   319,   323,   328,
     321,    62,   115,    58,   128,   131,   123,   119,   168,   170,
     174,   176,   158,   182,   318,     0,   192,     0,   143,   141,
       0,     0,   322,   190,   191,   144,     0,   145
  };

  /* YYPGOTO[NTERM-NUM].  */
  const short int
  Parser::yypgoto_[] =
  {
      -189,  -189,    91,  -182,   -27,  -152,    18,    42,   -28,    63,
    -189,  -189,  -189,   116,   117,   122,    10,   -82,    62,  -189,
    -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,     0,
    -189,   -34,  -188,    90,   204,   540,  -189,  -189,    71,  -153,
    -154,  -137,  -157,   293,  -189,  -111,   189,   829,   -89,   -86,
     -76,   121,     2,   370,   500,  -133,  -122,   -95,  -130,   -85,
     789,   777,  -189,    96,  -189,  -189
  };

  /* YYDEFGOTO[NTERM-NUM].  */
  const short int
  Parser::yydefgoto_[] =
  {
        -1,    37,    38,   175,    39,   176,   177,   178,    42,   179,
      44,    45,    46,    47,    48,    49,    97,   250,    50,    51,
      52,    53,    54,    55,    56,    57,    58,    59,    60,    84,
     203,   204,   205,   251,    91,    62,   130,   147,   183,   157,
     158,   159,   160,   292,   161,   162,   185,    92,   148,   131,
     114,   187,   362,    65,    66,   150,   133,   116,   189,    88,
     232,   233,   257,    68,    69,   191
  };

  /* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
     positive, shift that token.  If negative, reduce the rule which
     number is the opposite.  If zero, do what YYDEFACT says.  */
  const short int Parser::yytable_ninf_ = -321;
  const short int
  Parser::yytable_[] =
  {
        61,   252,   311,   310,   252,    86,    89,   254,   330,   275,
     312,   231,   318,   234,   230,   279,   342,   301,    40,   271,
      98,    99,   100,   319,   388,   181,   181,   181,   202,     8,
     181,   181,   181,   181,   181,   181,   181,   151,    61,    11,
      12,   151,    41,   299,   300,   272,   199,   243,   389,   390,
     248,   363,   313,   299,   300,  -308,    40,   329,   288,   299,
     300,     9,   276,    43,  -308,    83,    83,   243,    61,   243,
     200,    63,   248,   366,   313,   256,   113,   129,   146,    10,
      41,   299,   300,   307,   306,   309,    40,   180,   180,   180,
     324,   201,   180,   180,   180,   180,   180,   180,   180,   206,
     350,    43,  -281,  -281,  -281,  -281,  -281,  -281,  -281,    63,
      41,   334,   336,   330,   346,   348,   330,  -279,  -279,  -279,
    -279,  -279,  -279,  -279,  -283,  -283,  -283,  -283,  -283,  -283,
    -283,    43,   341,   352,   113,   129,   146,   354,   356,    63,
      93,    94,    95,    96,   311,   244,   358,   368,    83,   369,
     234,    83,   181,   181,   370,   181,   371,   342,   310,   245,
     236,   392,   237,   394,   310,   380,   382,   361,   238,   364,
     301,   365,   234,   367,   345,   181,   113,   271,   319,   255,
     372,   271,   313,   113,   373,     0,   313,   258,     0,     0,
     181,   313,     0,   129,   386,     0,   329,     0,   375,     0,
     113,   377,   329,     0,   202,     0,   163,     0,   202,     0,
     146,     0,     0,     0,   290,   290,     0,   290,   231,     0,
     313,     0,   199,   311,     0,   311,   199,   330,     0,   330,
       0,     0,   113,   129,   146,     0,     0,   290,   310,   279,
     310,     0,   420,     0,   412,    61,   200,   290,     0,   290,
     200,   275,   290,   290,     0,   311,     0,   329,   299,   300,
     307,   308,   309,    40,     0,     0,   310,   201,   426,   329,
       0,   201,   310,     0,     0,   206,     0,   252,     0,   206,
     271,   401,   271,     0,   403,     0,     0,    41,  -282,  -282,
    -282,  -282,  -282,  -282,  -282,   181,     0,     0,   181,   181,
     181,   263,   264,   265,   266,   181,   326,     0,    43,   181,
       0,    83,   332,     0,     0,    83,    63,   252,   184,   193,
     196,     0,     0,   210,   213,   216,   219,   222,   225,   228,
     181,   146,   129,     0,   113,     0,   113,     0,   113,   113,
       0,   293,   297,   302,   305,   202,   113,   129,   146,   299,
     300,   307,   391,   309,     0,   290,     0,   290,     0,   290,
     290,   290,   290,   199,     0,   402,     0,   290,   402,     0,
       0,   290,     0,    87,    87,     0,     0,     0,   181,   181,
     331,     0,     0,   181,   115,   132,   149,   200,   290,     0,
       0,     0,   290,   290,   290,   188,   188,   188,     0,     0,
     188,   188,   188,   188,   188,   188,   188,     0,   201,   181,
       0,   181,     0,     0,   326,     0,   206,     0,   326,   299,
     300,   307,   396,   309,    83,    83,   387,     0,    83,   299,
     300,   307,   418,   309,   146,   129,     0,   113,     0,   113,
     290,   290,   115,   132,   149,   290,   296,     0,   304,   290,
       0,     0,   399,     0,     0,     0,    87,     0,     0,    87,
       0,   290,     0,     0,    83,   299,   300,   307,   419,   309,
       0,   290,     0,   290,     0,     0,   163,  -287,  -287,  -287,
    -287,  -287,  -287,  -287,   115,     0,     0,     0,   293,   297,
       0,   115,     0,     0,     0,     0,   302,     0,   305,     0,
       0,   132,   299,   300,   307,   425,   309,     0,   115,     0,
    -288,  -288,  -288,  -288,  -288,  -288,  -288,     0,   149,     0,
       0,     0,   294,   294,     0,   294,  -289,  -289,  -289,  -289,
    -289,  -289,  -289,  -280,  -280,  -280,  -280,  -280,  -280,  -280,
     115,   132,   149,    85,    85,   294,   299,   300,   307,   427,
     309,     0,     0,     0,     0,   294,     0,   294,     0,     0,
     294,   294,     0,     0,   242,   182,   182,   182,     0,     0,
     182,   182,   182,   182,   182,   182,   182,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,   242,   296,     0,     0,     0,     0,   385,     0,
       0,   242,   304,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    87,
       0,     0,     0,    87,     0,     0,    85,     0,     0,    85,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   149,
     132,     0,   115,     0,   115,     0,   115,   115,     0,     0,
       0,     0,     0,     0,   115,   132,   149,     0,     0,     0,
       0,     0,     0,   294,   242,   294,     0,   294,   294,   294,
     294,   408,   410,     0,     0,   294,   413,     0,     0,   294,
       0,     0,     0,     0,     0,     0,   242,     0,     0,     0,
       0,     0,   291,   291,   242,   291,   294,   242,     0,     0,
     294,   294,   294,     0,     0,     0,     0,   242,     0,     0,
       0,   242,     0,     0,   242,   291,     0,   242,     0,     0,
     242,     0,     0,   242,     0,   291,   242,   291,     0,   242,
     291,   291,    87,    87,     0,     0,    87,     0,     0,     0,
       0,     0,   149,   132,     0,   115,   242,   115,   294,   294,
       0,     0,     0,   294,     0,     0,     0,   294,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   294,
       0,     0,    87,     0,     0,     0,     0,    67,     0,   294,
       0,   294,     0,     0,     0,     0,     0,     0,     0,    85,
       0,     0,     0,    85,   165,     0,     0,     0,     0,     0,
       0,     0,   190,   190,   190,   208,     0,   190,   190,   190,
     190,   190,   190,   190,   242,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    64,
       0,     0,   235,   291,     0,   291,     0,   291,   291,   291,
     291,     0,   101,     0,     0,   291,   164,     0,     0,   291,
     239,     0,   240,     0,   186,   194,   197,   207,   247,   211,
     214,   217,   220,   223,   226,   229,   291,    64,     0,     0,
     291,   291,   291,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   242,     0,    64,   246,     0,
       0,     0,    85,    85,     0,     0,    85,     0,     0,     0,
       0,     0,     0,     0,     0,   242,     0,   242,   291,   291,
       0,     0,     0,   291,     0,     0,     0,   291,     0,   295,
     298,   303,   190,     0,     0,     0,     0,     0,     0,   291,
     316,     0,    85,     0,     0,     0,     0,     0,     0,   291,
       0,   291,   315,   317,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   320,     0,   321,     0,
     322,     0,   323,     0,     0,     0,     0,  -320,     0,     0,
     333,     0,     0,     0,     0,     0,     0,     0,   338,     0,
     339,   340,   314,  -320,     0,   343,   344,     0,  -320,  -320,
    -320,  -320,  -320,     0,     0,  -320,  -320,     0,  -320,     0,
    -320,     0,  -320,     0,  -320,     0,     0,  -320,     0,  -320,
       0,  -320,     0,  -320,     0,  -320,     0,  -320,     0,  -320,
       0,     0,     0,   207,     0,     0,     0,   207,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,   165,     0,     0,     0,     0,     0,
       0,     0,     0,     0,    64,     0,   295,   298,     0,   381,
       0,     0,   190,     0,   303,     0,   190,     0,     0,     0,
     166,   167,     3,     4,   168,   169,   151,     8,     9,    10,
      11,    12,    13,   393,   170,   171,   172,    17,    18,    19,
      20,    21,    22,   156,   173,     0,   164,    25,     0,    26,
       0,    27,     0,    28,     0,    29,    30,     0,    31,     0,
      32,     0,    33,     0,    34,     0,    35,     0,    36,   227,
       0,     0,     0,     0,     0,   395,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   409,   411,     0,     0,     0,
     190,     1,     2,     3,     4,     5,     6,     0,     0,     0,
       0,     0,   421,     0,   207,    14,    15,    16,    90,    18,
      19,    20,    21,    22,    23,    24,     0,     0,    25,     0,
      26,     0,    27,     0,    28,     0,    29,    30,     0,    31,
       0,    32,     0,    33,     0,    34,     0,    35,     0,    36,
     359,     0,     0,     0,     0,     0,     0,     0,   415,   417,
     166,   167,     3,     4,   168,   169,   151,     8,     9,    10,
      11,    12,    13,     0,   170,   171,   172,    17,    18,    19,
      20,    21,    22,   156,   173,     0,     0,    25,   174,    26,
       0,    27,     0,    28,     0,    29,    30,     0,    31,     0,
      32,     0,    33,     0,    34,     0,    35,     0,    36,   166,
     167,     3,     4,   168,   169,   151,     8,     9,    10,    11,
      12,    13,     0,   170,   171,   172,    17,    18,    19,    20,
      21,    22,   156,   173,     0,     0,    25,     0,    26,   192,
      27,     0,    28,     0,    29,    30,     0,    31,     0,    32,
       0,    33,     0,    34,     0,    35,     0,    36,   166,   167,
       3,     4,   168,   169,   151,     8,     9,    10,    11,    12,
      13,     0,   170,   171,   172,    17,    18,    19,    20,    21,
      22,   156,   173,     0,     0,    25,     0,    26,     0,    27,
     195,    28,     0,    29,    30,     0,    31,     0,    32,     0,
      33,     0,    34,     0,    35,     0,    36,     1,     2,     3,
       4,     5,     6,   151,     8,     9,    10,    11,    12,    13,
       0,    14,    15,    16,    17,    18,    19,    20,    21,    22,
      23,    24,     0,     0,    25,     0,    26,     0,    27,     0,
      28,   198,    29,    30,     0,    31,     0,    32,     0,    33,
       0,    34,     0,    35,     0,    36,   166,   167,     3,     4,
     168,   169,   151,     8,     9,    10,    11,    12,    13,     0,
     170,   171,   172,    17,    18,    19,    20,    21,    22,   156,
     173,     0,     0,    25,     0,    26,     0,    27,     0,    28,
       0,    29,    30,   209,    31,     0,    32,     0,    33,     0,
      34,     0,    35,     0,    36,   166,   167,     3,     4,   168,
     169,   151,     8,     9,    10,    11,    12,    13,     0,   170,
     171,   172,    17,    18,    19,    20,    21,    22,   156,   173,
       0,     0,    25,     0,    26,     0,    27,     0,    28,     0,
      29,    30,     0,    31,   212,    32,     0,    33,     0,    34,
       0,    35,     0,    36,   166,   167,     3,     4,   168,   169,
     151,     8,     9,    10,    11,    12,    13,     0,   170,   171,
     172,    17,    18,    19,    20,    21,    22,   156,   173,     0,
       0,    25,     0,    26,     0,    27,     0,    28,     0,    29,
      30,     0,    31,     0,    32,   215,    33,     0,    34,     0,
      35,     0,    36,   166,   167,     3,     4,   168,   169,   151,
       8,     9,    10,    11,    12,    13,     0,   170,   171,   172,
      17,    18,    19,    20,    21,    22,   156,   173,     0,     0,
      25,     0,    26,     0,    27,     0,    28,     0,    29,    30,
       0,    31,     0,    32,     0,    33,   218,    34,     0,    35,
       0,    36,   166,   167,     3,     4,   168,   169,   151,     8,
       9,    10,    11,    12,    13,     0,   170,   171,   172,    17,
      18,    19,    20,    21,    22,   156,   173,     0,     0,    25,
       0,    26,     0,    27,     0,    28,     0,    29,    30,     0,
      31,     0,    32,     0,    33,     0,    34,   221,    35,     0,
      36,   166,   167,     3,     4,   168,   169,   151,     8,     9,
      10,    11,    12,    13,     0,   170,   171,   172,    17,    18,
      19,    20,    21,    22,   156,   173,     0,     0,    25,     0,
      26,     0,    27,     0,    28,     0,    29,    30,     0,    31,
       0,    32,     0,    33,     0,    34,     0,    35,   224,    36,
       1,     2,     3,     4,     5,     6,     7,     8,     9,    10,
      11,    12,    13,     0,    14,    15,    16,    17,    18,    19,
      20,    21,    22,    23,    24,     0,     0,    25,     0,    26,
       0,    27,     0,    28,     0,    29,    30,     0,    31,     0,
      32,     0,    33,     0,    34,     0,    35,     0,    36,     1,
       2,     3,     4,     5,     6,   244,     8,     9,    10,    11,
      12,    13,     0,    14,    15,    16,    17,    18,    19,    20,
      21,    22,    23,    24,     0,     0,    25,     0,    26,     0,
      27,     0,    28,     0,    29,    30,     0,    31,     0,    32,
       0,    33,     0,    34,     0,    35,     0,    36,     1,     2,
       3,     4,     5,     6,   243,     8,     9,    10,    11,    12,
      13,     0,    14,    15,    16,    17,    18,    19,    20,    21,
      22,    23,    24,     0,     0,    25,     0,    26,     0,    27,
       0,    28,     0,    29,    30,     0,    31,     0,    32,     0,
      33,     0,    34,     0,    35,     0,    36,     1,     2,     3,
       4,     5,     6,     0,     8,     9,    10,    11,    12,    13,
       0,    14,    15,    16,    17,    18,    19,    20,    21,    22,
      23,    24,     0,     0,    25,     0,    26,     0,    27,     0,
      28,     0,    29,    30,     0,    31,     0,    32,     0,    33,
       0,    34,     0,    35,     0,    36,     1,     2,     3,     4,
       5,     6,     0,     0,   259,   260,   261,   262,     0,     0,
      14,    15,    16,    90,    18,    19,    20,    21,    22,    23,
      24,     0,     0,    25,     0,    26,     0,    27,     0,    28,
       0,    29,    30,     0,    31,     0,    32,     0,    33,     0,
      34,     0,    35,     0,    36,   117,   118,     3,     4,   119,
     120,  -285,  -285,  -285,  -285,  -285,  -285,  -285,     0,     0,
       0,   121,   122,   123,   124,   125,   126,   127,   128,     0,
       0,     0,    25,     0,    26,     0,    27,     0,    28,     0,
      29,    30,     0,    31,     0,    32,     0,    33,     0,    34,
       0,    35,     0,    36,   134,   135,     3,     4,   136,   137,
    -284,  -284,  -284,  -284,  -284,  -284,  -284,     0,     0,   138,
       0,   139,   140,   141,   142,   143,   144,   145,     0,     0,
       0,    25,     0,    26,     0,    27,     0,    28,     0,    29,
      30,     0,    31,     0,    32,     0,    33,     0,    34,     0,
      35,     0,    36,   102,   103,     3,     4,   104,   105,  -286,
    -286,  -286,  -286,  -286,  -286,  -286,     0,     0,     0,     0,
     106,   107,   108,   109,   110,   111,   112,     0,     0,     0,
      25,     0,    26,     0,    27,     0,    28,     0,    29,    30,
       0,    31,     0,    32,     0,    33,     0,    34,     0,    35,
       0,    36,   280,   281,     3,     4,   282,   283,   151,     8,
       9,    10,    11,    12,    13,     0,   284,   285,   286,   287,
       0,     0,     0,     0,     0,   288,   289,     0,     0,    25,
       0,    26,     0,    27,     0,    28,     0,    29,    30,     0,
      31,     0,    32,     0,    33,     0,    34,     0,    35,     0,
      36,   280,   281,     3,     4,   282,   283,   243,     8,     9,
      10,    11,    12,    13,     0,   284,   285,   286,   287,     0,
       0,     0,     0,     0,   288,   289,     0,     0,    25,     0,
      26,     0,    27,     0,    28,     0,    29,    30,     0,    31,
       0,    32,     0,    33,     0,    34,     0,    35,     0,    36,
     280,   281,     3,     4,   282,   383,   384,     8,     9,    10,
      11,    12,    13,     0,   284,   285,   286,   287,     0,     0,
       0,     0,     0,   288,   289,     0,     0,    25,     0,    26,
       0,    27,     0,    28,     0,    29,    30,     0,    31,     0,
      32,     0,    33,     0,    34,     0,    35,     0,    36,     1,
       2,     3,     4,     5,     6,   151,     0,     0,     0,     0,
       0,     0,     0,    14,    15,    16,    90,   152,   153,   154,
      21,   155,   156,    24,     0,     0,    25,     0,    26,     0,
      27,     0,    28,     0,    29,    30,     0,    31,     0,    32,
       0,    33,     0,    34,     0,    35,     0,    36,     1,     2,
       3,     4,     5,     6,   241,     0,     0,     0,     0,     0,
       0,     0,    14,    15,    16,    90,    18,    19,    20,    21,
      22,    23,    24,     0,     0,    25,     0,    26,     0,    27,
       0,    28,     0,    29,    30,     0,    31,     0,    32,     0,
      33,     0,    34,     0,    35,     0,    36,     1,     2,     3,
       4,     5,     6,   151,     0,     0,     0,     0,     0,     0,
       0,    14,    15,    16,    90,    18,    19,    20,    21,    22,
      23,    24,     0,     0,    25,     0,    26,     0,    27,     0,
      28,     0,    29,    30,     0,    31,     0,    32,     0,    33,
       0,    34,     0,    35,     0,    36,     1,     2,     3,     4,
       5,     6,     0,     0,     0,     0,     0,     0,     0,   267,
      14,    15,    16,    90,    18,    19,    20,    21,    22,    23,
      24,     0,     0,    25,     0,    26,     0,    27,     0,    28,
       0,    29,    30,     0,    31,     0,    32,     0,    33,     0,
      34,     0,    35,     0,    36,   280,   281,     3,     4,   282,
     283,     0,     8,     9,    10,    11,    12,    13,     0,   284,
     285,   286,   287,     0,     0,     0,     0,     0,   288,   289,
       0,     0,    25,     0,    26,     0,    27,     0,    28,     0,
      29,    30,     0,    31,     0,    32,     0,    33,     0,    34,
       0,    35,     0,    36,     1,     2,     3,     4,     5,     6,
       0,     0,     0,     0,     0,     0,     0,     0,    14,    15,
      16,    90,    18,    19,    20,    21,    22,    23,    24,     0,
       0,    25,   327,    26,     0,    27,     0,    28,     0,    29,
      30,     0,    31,     0,    32,     0,    33,     0,    34,     0,
      35,     0,    36,     1,     2,     3,     4,     5,     6,     0,
       0,     0,     0,     0,     0,     0,     0,    14,    15,    16,
      90,    18,    19,    20,    21,    22,    23,    24,     0,     0,
      25,     0,    26,   335,    27,     0,    28,     0,    29,    30,
       0,    31,     0,    32,     0,    33,     0,    34,     0,    35,
       0,    36,     1,     2,     3,     4,     5,     6,     0,     0,
       0,     0,     0,     0,     0,     0,    14,    15,    16,    90,
      18,    19,    20,    21,    22,    23,    24,     0,     0,    25,
       0,    26,     0,    27,   337,    28,     0,    29,    30,     0,
      31,     0,    32,     0,    33,     0,    34,     0,    35,     0,
      36,     1,     2,     3,     4,     5,     6,     0,     0,     0,
       0,     0,     0,     0,     0,    14,    15,    16,    90,    18,
      19,    20,    21,    22,    23,    24,     0,     0,    25,     0,
      26,     0,    27,     0,    28,     0,    29,    30,   347,    31,
       0,    32,     0,    33,     0,    34,     0,    35,     0,    36,
       1,     2,     3,     4,     5,     6,     0,     0,     0,     0,
       0,     0,     0,     0,    14,    15,    16,    90,    18,    19,
      20,    21,    22,    23,    24,     0,     0,    25,     0,    26,
       0,    27,     0,    28,     0,    29,    30,     0,    31,   349,
      32,     0,    33,     0,    34,     0,    35,     0,    36,     1,
       2,     3,     4,     5,     6,     0,     0,     0,     0,     0,
       0,     0,     0,    14,    15,    16,    90,    18,    19,    20,
      21,    22,    23,    24,     0,     0,    25,     0,    26,     0,
      27,     0,    28,     0,    29,    30,     0,    31,     0,    32,
     351,    33,     0,    34,     0,    35,     0,    36,     1,     2,
       3,     4,     5,     6,     0,     0,     0,     0,     0,     0,
       0,     0,    14,    15,    16,    90,    18,    19,    20,    21,
      22,    23,    24,     0,     0,    25,     0,    26,     0,    27,
       0,    28,     0,    29,    30,     0,    31,     0,    32,     0,
      33,   353,    34,     0,    35,     0,    36,     1,     2,     3,
       4,     5,     6,     0,     0,     0,     0,     0,     0,     0,
       0,    14,    15,    16,    90,    18,    19,    20,    21,    22,
      23,    24,     0,     0,    25,     0,    26,     0,    27,     0,
      28,     0,    29,    30,     0,    31,     0,    32,     0,    33,
       0,    34,   355,    35,     0,    36,     1,     2,     3,     4,
       5,     6,     0,     0,     0,     0,     0,     0,     0,     0,
      14,    15,    16,    90,    18,    19,    20,    21,    22,    23,
      24,     0,     0,    25,     0,    26,     0,    27,     0,    28,
       0,    29,    30,     0,    31,     0,    32,     0,    33,     0,
      34,     0,    35,   357,    36,     1,     2,     3,     4,     5,
       6,   360,     0,     0,     0,     0,     0,     0,     0,    14,
      15,    16,    90,    18,    19,    20,    21,    22,    23,    24,
       0,     0,    25,     0,    26,     0,    27,     0,    28,     0,
      29,    30,     0,    31,     0,    32,     0,    33,     0,    34,
       0,    35,     0,    36,     1,     2,     3,     4,     5,     6,
     151,     0,     0,     0,     0,     0,     0,     0,    14,    15,
      16,    90,   152,   153,   154,    21,   155,    23,    24,     0,
       0,    25,     0,    26,     0,    27,     0,    28,     0,    29,
      30,     0,    31,     0,    32,     0,    33,     0,    34,     0,
      35,     0,    36,     1,     2,     3,     4,     5,     6,   243,
       0,     0,     0,     0,     0,     0,     0,    14,    15,    16,
      90,   152,   153,   154,    21,   155,    23,    24,     0,     0,
      25,     0,    26,     0,    27,     0,    28,     0,    29,    30,
       0,    31,     0,    32,     0,    33,     0,    34,     0,    35,
       0,    36,     1,     2,     3,     4,     5,     6,     0,     0,
       0,     0,     0,     0,     0,     0,    14,    15,    16,    90,
      18,    19,    20,    21,    22,    23,    24,     0,   416,    25,
       0,    26,     0,    27,     0,    28,     0,    29,    30,     0,
      31,     0,    32,     0,    33,     0,    34,     0,    35,     0,
      36,     1,     2,     3,     4,     5,     6,     0,     0,     0,
       0,     0,     0,     0,     0,    14,    15,    16,    90,    18,
      19,    20,    21,    22,    23,    24,   423,     0,    25,     0,
      26,     0,    27,     0,    28,     0,    29,    30,     0,    31,
       0,    32,     0,    33,     0,    34,     0,    35,     0,    36,
       1,     2,     3,     4,     5,     6,     0,     0,     0,     0,
       0,     0,     0,     0,    14,    15,    16,    90,    18,    19,
      20,    21,    22,    23,    24,     0,   424,    25,     0,    26,
       0,    27,     0,    28,     0,    29,    30,     0,    31,     0,
      32,     0,    33,     0,    34,     0,    35,     0,    36,     1,
       2,     3,     4,     5,     6,     0,     0,     0,     0,     0,
       0,     0,     0,    14,    15,    16,    90,    18,    19,    20,
      21,    22,    23,    24,     0,     0,    25,     0,    26,     0,
      27,     0,    28,     0,    29,    30,     0,    31,     0,    32,
       0,    33,     0,    34,     0,    35,     0,    36,    70,    71,
       3,     4,   248,   249,     0,     0,     0,     0,     0,     0,
       0,     0,    72,    73,    74,    75,    76,    77,    78,    79,
      80,    81,    82,     0,     0,    25,     0,    26,     0,    27,
       0,    28,     0,    29,    30,     0,    31,     0,    32,     0,
      33,     0,    34,     0,    35,     0,    36,    70,    71,     3,
       4,   248,   253,     0,     0,     0,     0,     0,     0,     0,
       0,    72,    73,    74,    75,    76,    77,    78,    79,    80,
      81,    82,     0,     0,    25,     0,    26,     0,    27,     0,
      28,     0,    29,    30,     0,    31,     0,    32,     0,    33,
       0,    34,     0,    35,     0,    36,   102,   103,     3,     4,
     104,   105,     0,     0,     0,     0,     0,     0,     0,     0,
     268,   269,   270,   106,   107,   108,   109,   110,   111,   112,
       0,     0,     0,    25,     0,    26,     0,    27,     0,    28,
       0,    29,    30,     0,    31,     0,    32,     0,    33,     0,
      34,     0,    35,     0,    36,    70,    71,     3,     4,   248,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    72,
      73,    74,    75,    76,    77,    78,    79,    80,    81,    82,
       0,     0,    25,     0,    26,     0,    27,     0,    28,     0,
      29,    30,     0,    31,     0,    32,     0,    33,     0,    34,
       0,    35,     0,    36,    70,    71,     3,     4,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,     0,
       0,    25,     0,    26,     0,    27,     0,    28,     0,    29,
      30,     0,    31,     0,    32,     0,    33,     0,    34,     0,
      35,     0,    36,   117,   118,     3,     4,   119,   120,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   273,   274,
     122,   123,   124,   125,   126,   127,   128,     0,     0,     0,
      25,     0,    26,     0,    27,     0,    28,     0,    29,    30,
       0,    31,     0,    32,     0,    33,     0,    34,     0,    35,
       0,    36,   134,   135,     3,     4,   136,   137,     0,     0,
       0,     0,     0,     0,     0,     0,     0,   277,   278,   139,
     140,   141,   142,   143,   144,   145,     0,     0,     0,    25,
       0,    26,     0,    27,     0,    28,     0,    29,    30,     0,
      31,     0,    32,     0,    33,     0,    34,     0,    35,     0,
      36,   134,   135,     3,     4,   136,   137,     0,     0,     0,
       0,     0,     0,     0,     0,     0,   138,   404,   139,   140,
     141,   142,   143,   144,   145,     0,     0,     0,    25,     0,
      26,     0,    27,     0,    28,     0,    29,    30,     0,    31,
       0,    32,     0,    33,     0,    34,     0,    35,     0,    36,
     117,   118,     3,     4,   119,   120,     0,     0,     0,     0,
       0,     0,     0,     0,     0,   405,   121,   122,   123,   124,
     125,   126,   127,   128,     0,     0,     0,    25,     0,    26,
       0,    27,     0,    28,     0,    29,    30,     0,    31,     0,
      32,     0,    33,     0,    34,     0,    35,     0,    36,   102,
     103,     3,     4,   104,   105,     0,     0,     0,     0,     0,
       0,     0,     0,   406,     0,   374,   106,   107,   108,   109,
     110,   111,   112,     0,     0,     0,    25,     0,    26,     0,
      27,     0,    28,     0,    29,    30,     0,    31,     0,    32,
       0,    33,     0,    34,     0,    35,     0,    36,   102,   103,
       3,     4,   104,   105,     0,     0,     0,     0,     0,     0,
       0,     0,   407,   376,     0,   106,   107,   108,   109,   110,
     111,   112,     0,     0,     0,    25,     0,    26,     0,    27,
       0,    28,     0,    29,    30,     0,    31,     0,    32,     0,
      33,     0,    34,     0,    35,     0,    36,   117,   118,     3,
       4,   119,   120,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,   121,   122,   123,   124,   125,   126,   127,
     128,     0,     0,     0,    25,     0,    26,     0,    27,     0,
      28,     0,    29,    30,     0,    31,     0,    32,     0,    33,
       0,    34,     0,    35,     0,    36,   134,   135,     3,     4,
     136,   137,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   138,     0,   139,   140,   141,   142,   143,   144,   145,
       0,     0,     0,    25,     0,    26,     0,    27,     0,    28,
       0,    29,    30,     0,    31,     0,    32,     0,    33,     0,
      34,     0,    35,     0,    36,   102,   103,     3,     4,   104,
     105,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   374,   106,   107,   108,   109,   110,   111,   112,     0,
       0,     0,    25,     0,    26,     0,    27,     0,    28,     0,
      29,    30,     0,    31,     0,    32,     0,    33,     0,    34,
       0,    35,     0,    36,   102,   103,     3,     4,   104,   105,
       0,     0,     0,     0,     0,     0,     0,     0,     0,   376,
       0,   106,   107,   108,   109,   110,   111,   112,     0,     0,
       0,    25,     0,    26,     0,    27,     0,    28,     0,    29,
      30,     0,    31,     0,    32,     0,    33,     0,    34,     0,
      35,     0,    36,   102,   103,     3,     4,   104,   105,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     106,   107,   108,   109,   110,   111,   112,     0,     0,     0,
      25,     0,    26,     0,    27,     0,    28,     0,    29,    30,
       0,    31,     0,    32,     0,    33,     0,    34,     0,    35,
       0,    36,   280,   281,     3,     4,   282,   283,   325,     0,
       0,     0,     0,     0,     0,     0,   284,   285,   286,     0,
       0,     0,     0,     0,     0,   288,   289,     0,     0,    25,
       0,    26,     0,    27,     0,    28,     0,    29,    30,     0,
      31,     0,    32,     0,    33,     0,    34,     0,    35,     0,
      36,   280,   281,     3,     4,   282,   283,   151,     0,     0,
       0,     0,     0,     0,     0,   284,   285,   286,     0,     0,
       0,     0,     0,     0,   288,   289,     0,     0,    25,     0,
      26,     0,    27,     0,    28,     0,    29,    30,     0,    31,
       0,    32,     0,    33,     0,    34,     0,    35,     0,    36,
     280,   281,     3,     4,   282,   378,   325,     0,     0,     0,
       0,     0,     0,     0,   284,   285,   286,     0,     0,     0,
       0,     0,     0,   288,   289,     0,     0,    25,     0,    26,
       0,    27,     0,    28,     0,    29,    30,     0,    31,     0,
      32,     0,    33,     0,    34,     0,    35,     0,    36,   280,
     281,     3,     4,   282,   379,   325,     0,     0,     0,     0,
       0,     0,     0,   284,   285,   286,     0,     0,     0,     0,
       0,     0,   288,   289,     0,     0,    25,     0,    26,     0,
      27,     0,    28,     0,    29,    30,     0,    31,     0,    32,
       0,    33,     0,    34,     0,    35,     0,    36,   280,   281,
       3,     4,   282,   283,   398,     0,     0,     0,     0,     0,
       0,     0,   284,   285,   286,     0,     0,     0,     0,     0,
       0,   288,   289,     0,     0,    25,     0,    26,     0,    27,
       0,    28,     0,    29,    30,     0,    31,     0,    32,     0,
      33,     0,    34,     0,    35,     0,    36,   280,   281,     3,
       4,   282,   283,   328,     0,     0,     0,     0,     0,     0,
       0,   284,   285,   286,     0,     0,     0,     0,     0,     0,
       0,   289,     0,     0,    25,     0,    26,     0,    27,     0,
      28,     0,    29,    30,     0,    31,     0,    32,     0,    33,
       0,    34,     0,    35,     0,    36,   280,   281,     3,     4,
     282,   283,   397,     0,     0,     0,     0,     0,     0,     0,
     284,   285,   286,     0,     0,     0,     0,     0,     0,     0,
     289,     0,     0,    25,     0,    26,     0,    27,     0,    28,
       0,    29,    30,     0,    31,     0,    32,     0,    33,     0,
      34,     0,    35,     0,    36,   280,   281,     3,     4,   282,
     283,   400,     0,     0,     0,     0,     0,     0,     0,   284,
     285,   286,     0,     0,     0,     0,     0,     0,     0,   289,
       0,     0,    25,     0,    26,     0,    27,     0,    28,     0,
      29,    30,     0,    31,     0,    32,     0,    33,     0,    34,
       0,    35,     0,    36,   280,   281,     3,     4,   282,   283,
     414,     0,     0,     0,     0,     0,     0,     0,   284,   285,
     286,     0,     0,     0,     0,     0,     0,     0,   289,     0,
       0,    25,     0,    26,     0,    27,     0,    28,     0,    29,
      30,     0,    31,     0,    32,     0,    33,     0,    34,     0,
      35,     0,    36,   280,   281,     3,     4,   282,   283,   422,
       0,     0,     0,     0,     0,     0,     0,   284,   285,   286,
       0,     0,     0,     0,     0,     0,     0,   289,     0,     0,
      25,     0,    26,     0,    27,     0,    28,     0,    29,    30,
       0,    31,     0,    32,     0,    33,     0,    34,     0,    35,
       0,    36
  };

  /* YYCHECK.  */
  const short int
  Parser::yycheck_[] =
  {
         0,    86,   159,   157,    89,     3,     4,    89,   190,   131,
     163,    38,   165,    41,     0,   148,   204,   154,     0,   114,
      10,    11,    12,   175,     4,    25,    26,    27,    28,    10,
      30,    31,    32,    33,    34,    35,    36,     9,    38,    13,
      14,     9,     0,    21,    22,   121,    28,     9,    28,    29,
       7,     8,   163,    21,    22,     0,    38,   187,    26,    21,
      22,    11,   138,     0,     9,     3,     4,     9,    68,     9,
      28,     0,     7,     8,   185,     9,    14,    15,    16,    12,
      38,    21,    22,    23,    27,    25,    68,    25,    26,    27,
      31,    28,    30,    31,    32,    33,    34,    35,    36,    28,
      44,    38,     9,    10,    11,    12,    13,    14,    15,    38,
      68,    33,    35,   295,    40,    42,   298,     9,    10,    11,
      12,    13,    14,    15,     9,    10,    11,    12,    13,    14,
      15,    68,    37,    46,    72,    73,    74,    48,    50,    68,
      11,    12,    13,    14,   301,     9,    52,     9,    86,     9,
     178,    89,   152,   153,     9,   155,     9,   345,   312,    68,
      44,   314,    45,   316,   318,   302,   303,   249,    46,   251,
     307,   253,   200,   255,   208,   175,   114,   272,   330,    89,
     269,   276,   293,   121,   270,    -1,   297,    91,    -1,    -1,
     190,   302,    -1,   131,   305,    -1,   326,    -1,   274,    -1,
     138,   277,   332,    -1,   204,    -1,    17,    -1,   208,    -1,
     148,    -1,    -1,    -1,   152,   153,    -1,   155,   245,    -1,
     331,    -1,   204,   380,    -1,   382,   208,   409,    -1,   411,
      -1,    -1,   170,   171,   172,    -1,    -1,   175,   392,   372,
     394,    -1,   395,    -1,   381,   245,   204,   185,    -1,   187,
     208,   373,   190,   191,    -1,   412,    -1,   387,    21,    22,
      23,    24,    25,   245,    -1,    -1,   420,   204,   421,   399,
      -1,   208,   426,    -1,    -1,   204,    -1,   362,    -1,   208,
     375,   363,   377,    -1,   366,    -1,    -1,   245,     9,    10,
      11,    12,    13,    14,    15,   295,    -1,    -1,   298,   299,
     300,    97,    98,    99,   100,   305,   185,    -1,   245,   309,
      -1,   249,   191,    -1,    -1,   253,   245,   402,    25,    26,
      27,    -1,    -1,    30,    31,    32,    33,    34,    35,    36,
     330,   269,   270,    -1,   272,    -1,   274,    -1,   276,   277,
      -1,   152,   153,   154,   155,   345,   284,   285,   286,    21,
      22,    23,    24,    25,    -1,   293,    -1,   295,    -1,   297,
     298,   299,   300,   345,    -1,   363,    -1,   305,   366,    -1,
      -1,   309,    -1,     3,     4,    -1,    -1,    -1,   378,   379,
     191,    -1,    -1,   383,    14,    15,    16,   345,   326,    -1,
      -1,    -1,   330,   331,   332,    25,    26,    27,    -1,    -1,
      30,    31,    32,    33,    34,    35,    36,    -1,   345,   409,
      -1,   411,    -1,    -1,   293,    -1,   345,    -1,   297,    21,
      22,    23,    24,    25,   362,   363,   305,    -1,   366,    21,
      22,    23,    24,    25,   372,   373,    -1,   375,    -1,   377,
     378,   379,    72,    73,    74,   383,   153,    -1,   155,   387,
      -1,    -1,   331,    -1,    -1,    -1,    86,    -1,    -1,    89,
      -1,   399,    -1,    -1,   402,    21,    22,    23,    24,    25,
      -1,   409,    -1,   411,    -1,    -1,   287,     9,    10,    11,
      12,    13,    14,    15,   114,    -1,    -1,    -1,   299,   300,
      -1,   121,    -1,    -1,    -1,    -1,   307,    -1,   309,    -1,
      -1,   131,    21,    22,    23,    24,    25,    -1,   138,    -1,
       9,    10,    11,    12,    13,    14,    15,    -1,   148,    -1,
      -1,    -1,   152,   153,    -1,   155,     9,    10,    11,    12,
      13,    14,    15,     9,    10,    11,    12,    13,    14,    15,
     170,   171,   172,     3,     4,   175,    21,    22,    23,    24,
      25,    -1,    -1,    -1,    -1,   185,    -1,   187,    -1,    -1,
     190,   191,    -1,    -1,    64,    25,    26,    27,    -1,    -1,
      30,    31,    32,    33,    34,    35,    36,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    92,   300,    -1,    -1,    -1,    -1,   305,    -1,
      -1,   101,   309,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   249,
      -1,    -1,    -1,   253,    -1,    -1,    86,    -1,    -1,    89,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   269,
     270,    -1,   272,    -1,   274,    -1,   276,   277,    -1,    -1,
      -1,    -1,    -1,    -1,   284,   285,   286,    -1,    -1,    -1,
      -1,    -1,    -1,   293,   164,   295,    -1,   297,   298,   299,
     300,   378,   379,    -1,    -1,   305,   383,    -1,    -1,   309,
      -1,    -1,    -1,    -1,    -1,    -1,   186,    -1,    -1,    -1,
      -1,    -1,   152,   153,   194,   155,   326,   197,    -1,    -1,
     330,   331,   332,    -1,    -1,    -1,    -1,   207,    -1,    -1,
      -1,   211,    -1,    -1,   214,   175,    -1,   217,    -1,    -1,
     220,    -1,    -1,   223,    -1,   185,   226,   187,    -1,   229,
     190,   191,   362,   363,    -1,    -1,   366,    -1,    -1,    -1,
      -1,    -1,   372,   373,    -1,   375,   246,   377,   378,   379,
      -1,    -1,    -1,   383,    -1,    -1,    -1,   387,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   399,
      -1,    -1,   402,    -1,    -1,    -1,    -1,     0,    -1,   409,
      -1,   411,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   249,
      -1,    -1,    -1,   253,    17,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    25,    26,    27,    28,    -1,    30,    31,    32,
      33,    34,    35,    36,   314,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,     0,
      -1,    -1,    43,   293,    -1,   295,    -1,   297,   298,   299,
     300,    -1,    13,    -1,    -1,   305,    17,    -1,    -1,   309,
      61,    -1,    63,    -1,    25,    26,    27,    28,    69,    30,
      31,    32,    33,    34,    35,    36,   326,    38,    -1,    -1,
     330,   331,   332,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   395,    -1,    68,    69,    -1,
      -1,    -1,   362,   363,    -1,    -1,   366,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   415,    -1,   417,   378,   379,
      -1,    -1,    -1,   383,    -1,    -1,    -1,   387,    -1,   152,
     153,   154,   155,    -1,    -1,    -1,    -1,    -1,    -1,   399,
     163,    -1,   402,    -1,    -1,    -1,    -1,    -1,    -1,   409,
      -1,   411,   163,   164,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,   177,    -1,   179,    -1,
     181,    -1,   183,    -1,    -1,    -1,    -1,     0,    -1,    -1,
     191,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   199,    -1,
     201,   202,   163,    16,    -1,   206,   207,    -1,    21,    22,
      23,    24,    25,    -1,    -1,    28,    29,    -1,    31,    -1,
      33,    -1,    35,    -1,    37,    -1,    -1,    40,    -1,    42,
      -1,    44,    -1,    46,    -1,    48,    -1,    50,    -1,    52,
      -1,    -1,    -1,   204,    -1,    -1,    -1,   208,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   287,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,   245,    -1,   299,   300,    -1,   302,
      -1,    -1,   305,    -1,   307,    -1,   309,    -1,    -1,    -1,
       3,     4,     5,     6,     7,     8,     9,    10,    11,    12,
      13,    14,    15,   314,    17,    18,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    -1,   287,    30,    -1,    32,
      -1,    34,    -1,    36,    -1,    38,    39,    -1,    41,    -1,
      43,    -1,    45,    -1,    47,    -1,    49,    -1,    51,    52,
      -1,    -1,    -1,    -1,    -1,   316,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,   378,   379,    -1,    -1,    -1,
     383,     3,     4,     5,     6,     7,     8,    -1,    -1,    -1,
      -1,    -1,   395,    -1,   345,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    -1,    -1,    30,    -1,
      32,    -1,    34,    -1,    36,    -1,    38,    39,    -1,    41,
      -1,    43,    -1,    45,    -1,    47,    -1,    49,    -1,    51,
      52,    -1,    -1,    -1,    -1,    -1,    -1,    -1,   389,   390,
       3,     4,     5,     6,     7,     8,     9,    10,    11,    12,
      13,    14,    15,    -1,    17,    18,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    -1,    -1,    30,    31,    32,
      -1,    34,    -1,    36,    -1,    38,    39,    -1,    41,    -1,
      43,    -1,    45,    -1,    47,    -1,    49,    -1,    51,     3,
       4,     5,     6,     7,     8,     9,    10,    11,    12,    13,
      14,    15,    -1,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    -1,    -1,    30,    -1,    32,    33,
      34,    -1,    36,    -1,    38,    39,    -1,    41,    -1,    43,
      -1,    45,    -1,    47,    -1,    49,    -1,    51,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    -1,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    -1,    -1,    30,    -1,    32,    -1,    34,
      35,    36,    -1,    38,    39,    -1,    41,    -1,    43,    -1,
      45,    -1,    47,    -1,    49,    -1,    51,     3,     4,     5,
       6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
      -1,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    -1,    -1,    30,    -1,    32,    -1,    34,    -1,
      36,    37,    38,    39,    -1,    41,    -1,    43,    -1,    45,
      -1,    47,    -1,    49,    -1,    51,     3,     4,     5,     6,
       7,     8,     9,    10,    11,    12,    13,    14,    15,    -1,
      17,    18,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    -1,    -1,    30,    -1,    32,    -1,    34,    -1,    36,
      -1,    38,    39,    40,    41,    -1,    43,    -1,    45,    -1,
      47,    -1,    49,    -1,    51,     3,     4,     5,     6,     7,
       8,     9,    10,    11,    12,    13,    14,    15,    -1,    17,
      18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      -1,    -1,    30,    -1,    32,    -1,    34,    -1,    36,    -1,
      38,    39,    -1,    41,    42,    43,    -1,    45,    -1,    47,
      -1,    49,    -1,    51,     3,     4,     5,     6,     7,     8,
       9,    10,    11,    12,    13,    14,    15,    -1,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    -1,
      -1,    30,    -1,    32,    -1,    34,    -1,    36,    -1,    38,
      39,    -1,    41,    -1,    43,    44,    45,    -1,    47,    -1,
      49,    -1,    51,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,    13,    14,    15,    -1,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    -1,    -1,
      30,    -1,    32,    -1,    34,    -1,    36,    -1,    38,    39,
      -1,    41,    -1,    43,    -1,    45,    46,    47,    -1,    49,
      -1,    51,     3,     4,     5,     6,     7,     8,     9,    10,
      11,    12,    13,    14,    15,    -1,    17,    18,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    -1,    -1,    30,
      -1,    32,    -1,    34,    -1,    36,    -1,    38,    39,    -1,
      41,    -1,    43,    -1,    45,    -1,    47,    48,    49,    -1,
      51,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    -1,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    -1,    -1,    30,    -1,
      32,    -1,    34,    -1,    36,    -1,    38,    39,    -1,    41,
      -1,    43,    -1,    45,    -1,    47,    -1,    49,    50,    51,
       3,     4,     5,     6,     7,     8,     9,    10,    11,    12,
      13,    14,    15,    -1,    17,    18,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    -1,    -1,    30,    -1,    32,
      -1,    34,    -1,    36,    -1,    38,    39,    -1,    41,    -1,
      43,    -1,    45,    -1,    47,    -1,    49,    -1,    51,     3,
       4,     5,     6,     7,     8,     9,    10,    11,    12,    13,
      14,    15,    -1,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    -1,    -1,    30,    -1,    32,    -1,
      34,    -1,    36,    -1,    38,    39,    -1,    41,    -1,    43,
      -1,    45,    -1,    47,    -1,    49,    -1,    51,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    -1,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    -1,    -1,    30,    -1,    32,    -1,    34,
      -1,    36,    -1,    38,    39,    -1,    41,    -1,    43,    -1,
      45,    -1,    47,    -1,    49,    -1,    51,     3,     4,     5,
       6,     7,     8,    -1,    10,    11,    12,    13,    14,    15,
      -1,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    -1,    -1,    30,    -1,    32,    -1,    34,    -1,
      36,    -1,    38,    39,    -1,    41,    -1,    43,    -1,    45,
      -1,    47,    -1,    49,    -1,    51,     3,     4,     5,     6,
       7,     8,    -1,    -1,    11,    12,    13,    14,    -1,    -1,
      17,    18,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    -1,    -1,    30,    -1,    32,    -1,    34,    -1,    36,
      -1,    38,    39,    -1,    41,    -1,    43,    -1,    45,    -1,
      47,    -1,    49,    -1,    51,     3,     4,     5,     6,     7,
       8,     9,    10,    11,    12,    13,    14,    15,    -1,    -1,
      -1,    19,    20,    21,    22,    23,    24,    25,    26,    -1,
      -1,    -1,    30,    -1,    32,    -1,    34,    -1,    36,    -1,
      38,    39,    -1,    41,    -1,    43,    -1,    45,    -1,    47,
      -1,    49,    -1,    51,     3,     4,     5,     6,     7,     8,
       9,    10,    11,    12,    13,    14,    15,    -1,    -1,    18,
      -1,    20,    21,    22,    23,    24,    25,    26,    -1,    -1,
      -1,    30,    -1,    32,    -1,    34,    -1,    36,    -1,    38,
      39,    -1,    41,    -1,    43,    -1,    45,    -1,    47,    -1,
      49,    -1,    51,     3,     4,     5,     6,     7,     8,     9,
      10,    11,    12,    13,    14,    15,    -1,    -1,    -1,    -1,
      20,    21,    22,    23,    24,    25,    26,    -1,    -1,    -1,
      30,    -1,    32,    -1,    34,    -1,    36,    -1,    38,    39,
      -1,    41,    -1,    43,    -1,    45,    -1,    47,    -1,    49,
      -1,    51,     3,     4,     5,     6,     7,     8,     9,    10,
      11,    12,    13,    14,    15,    -1,    17,    18,    19,    20,
      -1,    -1,    -1,    -1,    -1,    26,    27,    -1,    -1,    30,
      -1,    32,    -1,    34,    -1,    36,    -1,    38,    39,    -1,
      41,    -1,    43,    -1,    45,    -1,    47,    -1,    49,    -1,
      51,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    -1,    17,    18,    19,    20,    -1,
      -1,    -1,    -1,    -1,    26,    27,    -1,    -1,    30,    -1,
      32,    -1,    34,    -1,    36,    -1,    38,    39,    -1,    41,
      -1,    43,    -1,    45,    -1,    47,    -1,    49,    -1,    51,
       3,     4,     5,     6,     7,     8,     9,    10,    11,    12,
      13,    14,    15,    -1,    17,    18,    19,    20,    -1,    -1,
      -1,    -1,    -1,    26,    27,    -1,    -1,    30,    -1,    32,
      -1,    34,    -1,    36,    -1,    38,    39,    -1,    41,    -1,
      43,    -1,    45,    -1,    47,    -1,    49,    -1,    51,     3,
       4,     5,     6,     7,     8,     9,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    -1,    -1,    30,    -1,    32,    -1,
      34,    -1,    36,    -1,    38,    39,    -1,    41,    -1,    43,
      -1,    45,    -1,    47,    -1,    49,    -1,    51,     3,     4,
       5,     6,     7,     8,     9,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    -1,    -1,    30,    -1,    32,    -1,    34,
      -1,    36,    -1,    38,    39,    -1,    41,    -1,    43,    -1,
      45,    -1,    47,    -1,    49,    -1,    51,     3,     4,     5,
       6,     7,     8,     9,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    -1,    -1,    30,    -1,    32,    -1,    34,    -1,
      36,    -1,    38,    39,    -1,    41,    -1,    43,    -1,    45,
      -1,    47,    -1,    49,    -1,    51,     3,     4,     5,     6,
       7,     8,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    16,
      17,    18,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    -1,    -1,    30,    -1,    32,    -1,    34,    -1,    36,
      -1,    38,    39,    -1,    41,    -1,    43,    -1,    45,    -1,
      47,    -1,    49,    -1,    51,     3,     4,     5,     6,     7,
       8,    -1,    10,    11,    12,    13,    14,    15,    -1,    17,
      18,    19,    20,    -1,    -1,    -1,    -1,    -1,    26,    27,
      -1,    -1,    30,    -1,    32,    -1,    34,    -1,    36,    -1,
      38,    39,    -1,    41,    -1,    43,    -1,    45,    -1,    47,
      -1,    49,    -1,    51,     3,     4,     5,     6,     7,     8,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    -1,
      -1,    30,    31,    32,    -1,    34,    -1,    36,    -1,    38,
      39,    -1,    41,    -1,    43,    -1,    45,    -1,    47,    -1,
      49,    -1,    51,     3,     4,     5,     6,     7,     8,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    -1,    -1,
      30,    -1,    32,    33,    34,    -1,    36,    -1,    38,    39,
      -1,    41,    -1,    43,    -1,    45,    -1,    47,    -1,    49,
      -1,    51,     3,     4,     5,     6,     7,     8,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    17,    18,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    -1,    -1,    30,
      -1,    32,    -1,    34,    35,    36,    -1,    38,    39,    -1,
      41,    -1,    43,    -1,    45,    -1,    47,    -1,    49,    -1,
      51,     3,     4,     5,     6,     7,     8,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    -1,    -1,    30,    -1,
      32,    -1,    34,    -1,    36,    -1,    38,    39,    40,    41,
      -1,    43,    -1,    45,    -1,    47,    -1,    49,    -1,    51,
       3,     4,     5,     6,     7,     8,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    17,    18,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    -1,    -1,    30,    -1,    32,
      -1,    34,    -1,    36,    -1,    38,    39,    -1,    41,    42,
      43,    -1,    45,    -1,    47,    -1,    49,    -1,    51,     3,
       4,     5,     6,     7,     8,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    -1,    -1,    30,    -1,    32,    -1,
      34,    -1,    36,    -1,    38,    39,    -1,    41,    -1,    43,
      44,    45,    -1,    47,    -1,    49,    -1,    51,     3,     4,
       5,     6,     7,     8,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    -1,    -1,    30,    -1,    32,    -1,    34,
      -1,    36,    -1,    38,    39,    -1,    41,    -1,    43,    -1,
      45,    46,    47,    -1,    49,    -1,    51,     3,     4,     5,
       6,     7,     8,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    -1,    -1,    30,    -1,    32,    -1,    34,    -1,
      36,    -1,    38,    39,    -1,    41,    -1,    43,    -1,    45,
      -1,    47,    48,    49,    -1,    51,     3,     4,     5,     6,
       7,     8,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      17,    18,    19,    20,    21,    22,    23,    24,    25,    26,
      27,    -1,    -1,    30,    -1,    32,    -1,    34,    -1,    36,
      -1,    38,    39,    -1,    41,    -1,    43,    -1,    45,    -1,
      47,    -1,    49,    50,    51,     3,     4,     5,     6,     7,
       8,     9,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    17,
      18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      -1,    -1,    30,    -1,    32,    -1,    34,    -1,    36,    -1,
      38,    39,    -1,    41,    -1,    43,    -1,    45,    -1,    47,
      -1,    49,    -1,    51,     3,     4,     5,     6,     7,     8,
       9,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    -1,
      -1,    30,    -1,    32,    -1,    34,    -1,    36,    -1,    38,
      39,    -1,    41,    -1,    43,    -1,    45,    -1,    47,    -1,
      49,    -1,    51,     3,     4,     5,     6,     7,     8,     9,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    17,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    27,    -1,    -1,
      30,    -1,    32,    -1,    34,    -1,    36,    -1,    38,    39,
      -1,    41,    -1,    43,    -1,    45,    -1,    47,    -1,    49,
      -1,    51,     3,     4,     5,     6,     7,     8,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    17,    18,    19,    20,
      21,    22,    23,    24,    25,    26,    27,    -1,    29,    30,
      -1,    32,    -1,    34,    -1,    36,    -1,    38,    39,    -1,
      41,    -1,    43,    -1,    45,    -1,    47,    -1,    49,    -1,
      51,     3,     4,     5,     6,     7,     8,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    17,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    27,    28,    -1,    30,    -1,
      32,    -1,    34,    -1,    36,    -1,    38,    39,    -1,    41,
      -1,    43,    -1,    45,    -1,    47,    -1,    49,    -1,    51,
       3,     4,     5,     6,     7,     8,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    17,    18,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    -1,    29,    30,    -1,    32,
      -1,    34,    -1,    36,    -1,    38,    39,    -1,    41,    -1,
      43,    -1,    45,    -1,    47,    -1,    49,    -1,    51,     3,
       4,     5,     6,     7,     8,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    -1,    -1,    30,    -1,    32,    -1,
      34,    -1,    36,    -1,    38,    39,    -1,    41,    -1,    43,
      -1,    45,    -1,    47,    -1,    49,    -1,    51,     3,     4,
       5,     6,     7,     8,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    -1,    -1,    30,    -1,    32,    -1,    34,
      -1,    36,    -1,    38,    39,    -1,    41,    -1,    43,    -1,
      45,    -1,    47,    -1,    49,    -1,    51,     3,     4,     5,
       6,     7,     8,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    17,    18,    19,    20,    21,    22,    23,    24,    25,
      26,    27,    -1,    -1,    30,    -1,    32,    -1,    34,    -1,
      36,    -1,    38,    39,    -1,    41,    -1,    43,    -1,    45,
      -1,    47,    -1,    49,    -1,    51,     3,     4,     5,     6,
       7,     8,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      17,    18,    19,    20,    21,    22,    23,    24,    25,    26,
      -1,    -1,    -1,    30,    -1,    32,    -1,    34,    -1,    36,
      -1,    38,    39,    -1,    41,    -1,    43,    -1,    45,    -1,
      47,    -1,    49,    -1,    51,     3,     4,     5,     6,     7,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    17,
      18,    19,    20,    21,    22,    23,    24,    25,    26,    27,
      -1,    -1,    30,    -1,    32,    -1,    34,    -1,    36,    -1,
      38,    39,    -1,    41,    -1,    43,    -1,    45,    -1,    47,
      -1,    49,    -1,    51,     3,     4,     5,     6,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    -1,
      -1,    30,    -1,    32,    -1,    34,    -1,    36,    -1,    38,
      39,    -1,    41,    -1,    43,    -1,    45,    -1,    47,    -1,
      49,    -1,    51,     3,     4,     5,     6,     7,     8,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    18,    19,
      20,    21,    22,    23,    24,    25,    26,    -1,    -1,    -1,
      30,    -1,    32,    -1,    34,    -1,    36,    -1,    38,    39,
      -1,    41,    -1,    43,    -1,    45,    -1,    47,    -1,    49,
      -1,    51,     3,     4,     5,     6,     7,     8,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    18,    19,    20,
      21,    22,    23,    24,    25,    26,    -1,    -1,    -1,    30,
      -1,    32,    -1,    34,    -1,    36,    -1,    38,    39,    -1,
      41,    -1,    43,    -1,    45,    -1,    47,    -1,    49,    -1,
      51,     3,     4,     5,     6,     7,     8,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    18,    19,    20,    21,
      22,    23,    24,    25,    26,    -1,    -1,    -1,    30,    -1,
      32,    -1,    34,    -1,    36,    -1,    38,    39,    -1,    41,
      -1,    43,    -1,    45,    -1,    47,    -1,    49,    -1,    51,
       3,     4,     5,     6,     7,     8,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    18,    19,    20,    21,    22,
      23,    24,    25,    26,    -1,    -1,    -1,    30,    -1,    32,
      -1,    34,    -1,    36,    -1,    38,    39,    -1,    41,    -1,
      43,    -1,    45,    -1,    47,    -1,    49,    -1,    51,     3,
       4,     5,     6,     7,     8,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    17,    -1,    19,    20,    21,    22,    23,
      24,    25,    26,    -1,    -1,    -1,    30,    -1,    32,    -1,
      34,    -1,    36,    -1,    38,    39,    -1,    41,    -1,    43,
      -1,    45,    -1,    47,    -1,    49,    -1,    51,     3,     4,
       5,     6,     7,     8,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    17,    18,    -1,    20,    21,    22,    23,    24,
      25,    26,    -1,    -1,    -1,    30,    -1,    32,    -1,    34,
      -1,    36,    -1,    38,    39,    -1,    41,    -1,    43,    -1,
      45,    -1,    47,    -1,    49,    -1,    51,     3,     4,     5,
       6,     7,     8,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    19,    20,    21,    22,    23,    24,    25,
      26,    -1,    -1,    -1,    30,    -1,    32,    -1,    34,    -1,
      36,    -1,    38,    39,    -1,    41,    -1,    43,    -1,    45,
      -1,    47,    -1,    49,    -1,    51,     3,     4,     5,     6,
       7,     8,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    18,    -1,    20,    21,    22,    23,    24,    25,    26,
      -1,    -1,    -1,    30,    -1,    32,    -1,    34,    -1,    36,
      -1,    38,    39,    -1,    41,    -1,    43,    -1,    45,    -1,
      47,    -1,    49,    -1,    51,     3,     4,     5,     6,     7,
       8,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    19,    20,    21,    22,    23,    24,    25,    26,    -1,
      -1,    -1,    30,    -1,    32,    -1,    34,    -1,    36,    -1,
      38,    39,    -1,    41,    -1,    43,    -1,    45,    -1,    47,
      -1,    49,    -1,    51,     3,     4,     5,     6,     7,     8,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    18,
      -1,    20,    21,    22,    23,    24,    25,    26,    -1,    -1,
      -1,    30,    -1,    32,    -1,    34,    -1,    36,    -1,    38,
      39,    -1,    41,    -1,    43,    -1,    45,    -1,    47,    -1,
      49,    -1,    51,     3,     4,     5,     6,     7,     8,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      20,    21,    22,    23,    24,    25,    26,    -1,    -1,    -1,
      30,    -1,    32,    -1,    34,    -1,    36,    -1,    38,    39,
      -1,    41,    -1,    43,    -1,    45,    -1,    47,    -1,    49,
      -1,    51,     3,     4,     5,     6,     7,     8,     9,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    17,    18,    19,    -1,
      -1,    -1,    -1,    -1,    -1,    26,    27,    -1,    -1,    30,
      -1,    32,    -1,    34,    -1,    36,    -1,    38,    39,    -1,
      41,    -1,    43,    -1,    45,    -1,    47,    -1,    49,    -1,
      51,     3,     4,     5,     6,     7,     8,     9,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    17,    18,    19,    -1,    -1,
      -1,    -1,    -1,    -1,    26,    27,    -1,    -1,    30,    -1,
      32,    -1,    34,    -1,    36,    -1,    38,    39,    -1,    41,
      -1,    43,    -1,    45,    -1,    47,    -1,    49,    -1,    51,
       3,     4,     5,     6,     7,     8,     9,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    17,    18,    19,    -1,    -1,    -1,
      -1,    -1,    -1,    26,    27,    -1,    -1,    30,    -1,    32,
      -1,    34,    -1,    36,    -1,    38,    39,    -1,    41,    -1,
      43,    -1,    45,    -1,    47,    -1,    49,    -1,    51,     3,
       4,     5,     6,     7,     8,     9,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    17,    18,    19,    -1,    -1,    -1,    -1,
      -1,    -1,    26,    27,    -1,    -1,    30,    -1,    32,    -1,
      34,    -1,    36,    -1,    38,    39,    -1,    41,    -1,    43,
      -1,    45,    -1,    47,    -1,    49,    -1,    51,     3,     4,
       5,     6,     7,     8,     9,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    17,    18,    19,    -1,    -1,    -1,    -1,    -1,
      -1,    26,    27,    -1,    -1,    30,    -1,    32,    -1,    34,
      -1,    36,    -1,    38,    39,    -1,    41,    -1,    43,    -1,
      45,    -1,    47,    -1,    49,    -1,    51,     3,     4,     5,
       6,     7,     8,     9,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    17,    18,    19,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    27,    -1,    -1,    30,    -1,    32,    -1,    34,    -1,
      36,    -1,    38,    39,    -1,    41,    -1,    43,    -1,    45,
      -1,    47,    -1,    49,    -1,    51,     3,     4,     5,     6,
       7,     8,     9,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      17,    18,    19,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      27,    -1,    -1,    30,    -1,    32,    -1,    34,    -1,    36,
      -1,    38,    39,    -1,    41,    -1,    43,    -1,    45,    -1,
      47,    -1,    49,    -1,    51,     3,     4,     5,     6,     7,
       8,     9,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    17,
      18,    19,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    27,
      -1,    -1,    30,    -1,    32,    -1,    34,    -1,    36,    -1,
      38,    39,    -1,    41,    -1,    43,    -1,    45,    -1,    47,
      -1,    49,    -1,    51,     3,     4,     5,     6,     7,     8,
       9,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    17,    18,
      19,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    27,    -1,
      -1,    30,    -1,    32,    -1,    34,    -1,    36,    -1,    38,
      39,    -1,    41,    -1,    43,    -1,    45,    -1,    47,    -1,
      49,    -1,    51,     3,     4,     5,     6,     7,     8,     9,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    17,    18,    19,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    27,    -1,    -1,
      30,    -1,    32,    -1,    34,    -1,    36,    -1,    38,    39,
      -1,    41,    -1,    43,    -1,    45,    -1,    47,    -1,    49,
      -1,    51
  };

  /* STOS_[STATE-NUM] -- The (internal number of the) accessing
     symbol of state STATE-NUM.  */
  const unsigned char
  Parser::yystos_[] =
  {
         0,     3,     4,     5,     6,     7,     8,     9,    10,    11,
      12,    13,    14,    15,    17,    18,    19,    20,    21,    22,
      23,    24,    25,    26,    27,    30,    32,    34,    36,    38,
      39,    41,    43,    45,    47,    49,    51,    54,    55,    57,
      59,    60,    61,    62,    63,    64,    65,    66,    67,    68,
      71,    72,    73,    74,    75,    76,    77,    78,    79,    80,
      81,    82,    88,    91,   100,   106,   107,   114,   116,   117,
       3,     4,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    71,    82,    88,   105,   106,   112,   105,
      20,    87,   100,    11,    12,    13,    14,    69,    69,    69,
      69,   100,     3,     4,     7,     8,    20,    21,    22,    23,
      24,    25,    26,    71,   103,   106,   110,     3,     4,     7,
       8,    19,    20,    21,    22,    23,    24,    25,    26,    71,
      89,   102,   106,   109,     3,     4,     7,     8,    18,    20,
      21,    22,    23,    24,    25,    26,    71,    90,   101,   106,
     108,     9,    21,    22,    23,    25,    26,    92,    93,    94,
      95,    97,    98,    99,   100,   114,     3,     4,     7,     8,
      17,    18,    19,    27,    31,    56,    58,    59,    60,    62,
      71,    82,    88,    91,    96,    99,   100,   104,   106,   111,
     114,   118,    33,    96,   100,    35,    96,   100,    37,    59,
      60,    62,    82,    83,    84,    85,    91,   100,   114,    40,
      96,   100,    42,    96,   100,    44,    96,   100,    46,    96,
     100,    48,    96,   100,    50,    96,   100,    52,    96,   100,
       0,    57,   113,   114,    61,   113,    66,    67,    68,   113,
     113,     9,   107,     9,     9,    55,   100,   113,     7,     8,
      70,    86,   112,     8,    70,    86,     9,   115,   116,    11,
      12,    13,    14,    87,    87,    87,    87,    16,    17,    18,
      19,   110,   103,    18,    19,   109,   103,    18,    19,   108,
       3,     4,     7,     8,    17,    18,    19,    20,    26,    27,
      71,    88,    96,    99,   106,   114,    96,    99,   114,    21,
      22,    94,    99,   114,    96,    99,    27,    23,    24,    25,
      93,    95,    92,    98,   100,   113,   114,   113,    92,    58,
     113,   113,   113,   113,    31,     9,   104,    31,     9,   111,
      56,    99,   104,   113,    33,    33,    35,    35,   113,   113,
     113,    37,    85,   113,   113,    84,    40,    40,    42,    42,
      44,    44,    46,    46,    48,    48,    50,    50,    52,    52,
       9,    70,   105,     8,    70,    70,     8,    70,     9,     9,
       9,     9,   101,   102,    19,   103,    18,   103,     8,     8,
      94,   114,    94,     8,     9,    96,    98,   104,     4,    28,
      29,    24,    92,   113,    92,   100,    24,     9,     9,   104,
       9,    70,   105,    70,    19,    18,    17,    17,    96,   114,
      96,   114,    94,    96,     9,   100,    29,   100,    24,    24,
      92,   114,     9,    28,    29,    24,    92,    24
  };

#if YYDEBUG
  /* TOKEN_NUMBER_[YYLEX-NUM] -- Internal symbol number corresponding
     to YYLEX-NUM.  */
  const unsigned short int
  Parser::yytoken_number_[] =
  {
         0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307
  };
#endif

  /* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
  const unsigned char
  Parser::yyr1_[] =
  {
         0,    53,    54,    54,    54,    54,    55,    55,    56,    56,
      57,    57,    57,    57,    57,    57,    58,    58,    58,    58,
      58,    58,    59,    59,    59,    60,    60,    61,    62,    62,
      62,    63,    63,    64,    64,    65,    65,    66,    66,    67,
      67,    68,    68,    68,    68,    69,    69,    69,    69,    69,
      69,    69,    69,    69,    70,    71,    71,    71,    71,    71,
      71,    71,    71,    71,    71,    71,    71,    71,    71,    71,
      71,    72,    72,    72,    73,    73,    73,    74,    74,    74,
      75,    75,    75,    76,    76,    76,    77,    77,    77,    78,
      78,    78,    79,    79,    79,    80,    80,    80,    81,    81,
      81,    82,    82,    82,    83,    83,    84,    84,    85,    85,
      85,    85,    85,    85,    86,    86,    87,    87,    88,    88,
      88,    88,    88,    88,    88,    88,    88,    88,    88,    88,
      88,    88,    88,    88,    88,    89,    89,    90,    90,    91,
      91,    91,    91,    91,    91,    91,    91,    91,    91,    91,
      91,    91,    91,    91,    92,    92,    93,    93,    93,    93,
      93,    93,    93,    93,    93,    93,    94,    94,    95,    95,
      95,    95,    95,    95,    95,    95,    95,    95,    95,    95,
      96,    96,    97,    97,    97,    97,    97,    97,    98,    98,
      98,    98,    98,    98,    99,    99,   100,   100,   101,   101,
     102,   102,   103,   103,   104,   104,   105,   105,   106,   106,
     106,   106,   106,   106,   106,   106,   106,   106,   106,   106,
     107,   107,   107,   107,   107,   107,   107,   107,   107,   107,
     107,   107,   107,   107,   107,   107,   107,   107,   108,   108,
     108,   108,   108,   108,   108,   108,   108,   108,   108,   108,
     108,   108,   109,   109,   109,   109,   109,   109,   109,   109,
     109,   109,   109,   109,   109,   109,   110,   110,   110,   110,
     110,   110,   110,   110,   110,   110,   110,   110,   110,   111,
     111,   111,   111,   111,   111,   111,   111,   111,   111,   111,
     112,   112,   112,   112,   112,   112,   112,   112,   112,   112,
     112,   112,   112,   112,   112,   112,   113,   113,   114,   114,
     115,   115,   116,   116,   117,   117,   117,   117,   118,   118,
     118,   118,   118,   118,   118,   118,   118,   118,   118,   118
  };

  /* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
  const unsigned char
  Parser::yyr2_[] =
  {
         0,     2,     0,     1,     2,     1,     1,     2,     1,     2,
       1,     2,     2,     2,     2,     2,     1,     2,     2,     2,
       2,     2,     3,     2,     1,     1,     2,     3,     1,     1,
       1,     1,     2,     1,     2,     1,     2,     4,     3,     4,
       3,     4,     4,     3,     3,     0,     1,     1,     1,     1,
       2,     2,     2,     2,     1,     3,     4,     4,     5,     3,
       4,     4,     5,     2,     3,     3,     4,     2,     3,     3,
       4,     3,     3,     2,     3,     3,     2,     3,     3,     2,
       3,     3,     2,     3,     3,     2,     3,     3,     2,     3,
       3,     2,     3,     3,     2,     3,     3,     2,     3,     3,
       2,     3,     2,     2,     1,     2,     1,     2,     1,     2,
       2,     2,     2,     2,     2,     3,     0,     1,     3,     5,
       4,     2,     3,     5,     4,     3,     2,     3,     5,     4,
       3,     5,     4,     3,     2,     3,     2,     3,     2,     4,
       3,     5,     4,     5,     6,     7,     3,     2,     4,     3,
       3,     4,     3,     2,     1,     2,     3,     2,     4,     3,
       1,     3,     2,     2,     1,     1,     1,     2,     4,     2,
       4,     3,     2,     1,     4,     2,     4,     3,     2,     1,
       1,     2,     4,     3,     2,     3,     2,     1,     1,     3,
       5,     5,     4,     2,     1,     2,     1,     2,     1,     2,
       1,     2,     1,     2,     1,     2,     1,     2,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     0,     1,     1,     2,
       0,     1,     1,     2,     2,     3,     1,     2,     2,     3,
       2,     3,     4,     3,     1,     2,     1,     2,     3,     2
  };

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
  /* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
     First, the terminals, then, starting at \a yyntokens_, nonterminals.  */
  const char*
  const Parser::yytname_[] =
  {
    "\"end of file\"", "error", "$undefined", "EXTENSION", "TEXT",
  "OPENLINK", "OPENDBLSQBR", "CLOSEDBLSQBR", "PIPE", "NEWLINE", "PRELINE",
  "LISTBULLET", "LISTNUMBERED", "LISTIDENT", "LISTTERM", "HEADING",
  "ENDHEADING", "APO5", "APO3", "APO2", "TABLEBEGIN", "TABLECELL",
  "TABLEHEAD", "TABLEROW", "TABLEEND", "TABLECAPTION", "ATTRIBUTE",
  "EQUALS", "ATTRAPO", "ATTRQ", "SPAN", "ENDSPAN", "SUB", "ENDSUB", "SUP",
  "ENDSUP", "DIV", "ENDDIV", "BR", "BIG", "ENDBIG", "SMALL", "ENDSMALL",
  "TT", "ENDTT", "I", "ENDI", "CITE", "ENDCITE", "A", "ENDA", "P", "ENDP",
  "$accept", "article", "blocks", "blocksintbl", "block", "blockintbl",
  "heading", "preblock", "preline", "listblock", "bulletlistblock",
  "numberlistblock", "definitionlistblock", "bulletlistline",
  "numberlistline", "definitionlistline", "listseries", "linktrail",
  "linketc", "span", "sub", "sup", "big", "small", "tt", "i", "cite", "a",
  "p", "div", "divcontents", "blocksindiv", "blockindiv", "pipeseries",
  "textorempty", "italicsorbold", "italicsnobold", "boldnoitalics",
  "table", "tablerows", "tablerow", "tablecells", "tablecell",
  "tablecellcontents", "tablecaption", "attribute", "attributes", "text",
  "textnoital", "textnobold", "textnoboit", "textintbl", "textinlink",
  "textelementhtml", "textelement", "textelementnoital",
  "textelementnobold", "textelementnoboit", "textelementintbl",
  "textelementinlink", "zeroormorenewlines", "oneormorenewlines",
  "zeroormorenewlinessave", "oneormorenewlinessave", "paragraph",
  "paragraphintbl", 0
  };
#endif

#if YYDEBUG
  /* YYRHS -- A `-1'-separated list of the rules' RHS.  */
  const Parser::rhs_number_type
  Parser::yyrhs_[] =
  {
        54,     0,    -1,    -1,   114,    -1,   116,    55,    -1,    55,
      -1,    57,    -1,    55,    57,    -1,    58,    -1,    56,    58,
      -1,    60,    -1,    59,   113,    -1,    62,   113,    -1,    82,
     113,    -1,   117,   113,    -1,    91,   113,    -1,    60,    -1,
      59,   113,    -1,    62,   113,    -1,    82,   113,    -1,   118,
     113,    -1,    91,   113,    -1,    15,   100,    16,    -1,    15,
     100,    -1,    15,    -1,    61,    -1,    60,    61,    -1,    10,
      87,   115,    -1,    63,    -1,    64,    -1,    65,    -1,    66,
      -1,    63,    66,    -1,    67,    -1,    64,    67,    -1,    68,
      -1,    65,    68,    -1,    11,    69,    87,     9,    -1,    11,
      69,    87,    -1,    12,    69,    87,     9,    -1,    12,    69,
      87,    -1,    13,    69,    87,     9,    -1,    14,    69,    87,
       9,    -1,    13,    69,    87,    -1,    14,    69,    87,    -1,
      -1,    11,    -1,    12,    -1,    13,    -1,    14,    -1,    69,
      11,    -1,    69,    12,    -1,    69,    13,    -1,    69,    14,
      -1,     7,    -1,     6,   105,    70,    -1,     6,   105,     8,
      70,    -1,     6,   105,    86,    70,    -1,     6,   105,    86,
       8,    70,    -1,     5,   105,    70,    -1,     5,   105,     8,
      70,    -1,     5,   105,    86,    70,    -1,     5,   105,    86,
       8,    70,    -1,     6,   105,    -1,     6,   105,     8,    -1,
       6,   105,    86,    -1,     6,   105,    86,     8,    -1,     5,
     105,    -1,     5,   105,     8,    -1,     5,   105,    86,    -1,
       5,   105,    86,     8,    -1,    30,   100,    31,    -1,    30,
      96,    31,    -1,    30,    31,    -1,    32,   100,    33,    -1,
      32,    96,    33,    -1,    32,    33,    -1,    34,   100,    35,
      -1,    34,    96,    35,    -1,    34,    35,    -1,    39,   100,
      40,    -1,    39,    96,    40,    -1,    39,    40,    -1,    41,
     100,    42,    -1,    41,    96,    42,    -1,    41,    42,    -1,
      43,   100,    44,    -1,    43,    96,    44,    -1,    43,    44,
      -1,    45,   100,    46,    -1,    45,    96,    46,    -1,    45,
      46,    -1,    47,   100,    48,    -1,    47,    96,    48,    -1,
      47,    48,    -1,    49,   100,    50,    -1,    49,    96,    50,
      -1,    49,    50,    -1,    51,   100,    52,    -1,    51,    96,
      52,    -1,    51,    52,    -1,    36,    83,    37,    -1,    36,
      37,    -1,    36,    83,    -1,    84,    -1,   114,    84,    -1,
      85,    -1,    84,    85,    -1,    60,    -1,    59,   113,    -1,
      62,   113,    -1,    82,   113,    -1,   100,   113,    -1,    91,
     113,    -1,     8,   105,    -1,    86,     8,   105,    -1,    -1,
     100,    -1,    19,   101,    19,    -1,    19,   101,    18,   103,
      17,    -1,    19,   101,    18,   103,    -1,    19,   101,    -1,
      18,   102,    18,    -1,    18,   102,    19,   103,    17,    -1,
      18,   102,    19,   103,    -1,    18,   102,    19,    -1,    18,
     102,    -1,    17,   103,    17,    -1,    17,   103,    18,   101,
      19,    -1,    17,   103,    18,   101,    -1,    17,   103,    18,
      -1,    17,   103,    19,   102,    18,    -1,    17,   103,    19,
     102,    -1,    17,   103,    19,    -1,    17,   103,    -1,    19,
     103,    19,    -1,    19,   103,    -1,    18,   103,    18,    -1,
      18,   103,    -1,    20,    99,    92,    24,    -1,    20,    99,
      92,    -1,    20,    99,   114,    92,    24,    -1,    20,    99,
     114,    92,    -1,    20,    99,   100,    92,    24,    -1,    20,
      99,   114,   100,    92,    24,    -1,    20,    99,   114,   100,
     114,    92,    24,    -1,    20,    92,    24,    -1,    20,    92,
      -1,    20,   114,    92,    24,    -1,    20,   114,    92,    -1,
      20,    99,   113,    -1,    20,    99,   100,   113,    -1,    20,
     100,   113,    -1,    20,   114,    -1,    93,    -1,    92,    93,
      -1,    23,    99,    94,    -1,    23,    94,    -1,    23,    99,
     114,    94,    -1,    23,   114,    94,    -1,    94,    -1,    23,
      99,   114,    -1,    23,    99,    -1,    23,   114,    -1,    23,
      -1,    97,    -1,    95,    -1,    94,    95,    -1,    21,    99,
       8,    96,    -1,    21,    96,    -1,    21,    99,     8,   114,
      -1,    21,    99,     8,    -1,    21,   114,    -1,    21,    -1,
      22,    99,     8,    96,    -1,    22,    96,    -1,    22,    99,
       8,   114,    -1,    22,    99,     8,    -1,    22,   114,    -1,
      22,    -1,    56,    -1,   114,    56,    -1,    25,    99,     8,
      96,    -1,    25,    99,    96,    -1,    25,    96,    -1,    25,
      99,     8,    -1,    25,    99,    -1,    25,    -1,    26,    -1,
      26,    27,     4,    -1,    26,    27,    28,   100,    28,    -1,
      26,    27,    29,   100,    29,    -1,    26,    27,    29,    29,
      -1,    26,    27,    -1,    98,    -1,    99,    98,    -1,   107,
      -1,   100,   107,    -1,   108,    -1,   101,   108,    -1,   109,
      -1,   102,   109,    -1,   110,    -1,   103,   110,    -1,   111,
      -1,   104,   111,    -1,   112,    -1,   105,   112,    -1,    72,
      -1,    73,    -1,    74,    -1,    75,    -1,    76,    -1,    77,
      -1,    78,    -1,    80,    -1,    81,    -1,    79,    -1,    82,
      -1,    38,    -1,     4,    -1,   106,    -1,     3,    -1,     8,
      -1,     7,    -1,    19,    -1,    18,    -1,    17,    -1,    27,
      -1,    20,    -1,    24,    -1,    23,    -1,    21,    -1,    22,
      -1,    25,    -1,    26,    -1,    71,    -1,    88,    -1,     4,
      -1,   106,    -1,     3,    -1,     8,    -1,     7,    -1,    20,
      -1,    24,    -1,    23,    -1,    21,    -1,    22,    -1,    25,
      -1,    26,    -1,    71,    -1,    90,    -1,     4,    -1,   106,
      -1,     3,    -1,     8,    -1,     7,    -1,    20,    -1,    24,
      -1,    23,    -1,    21,    -1,    22,    -1,    25,    -1,    26,
      -1,    71,    -1,    89,    -1,     4,    -1,   106,    -1,     3,
      -1,     8,    -1,     7,    -1,    20,    -1,    24,    -1,    23,
      -1,    21,    -1,    22,    -1,    25,    -1,    26,    -1,    71,
      -1,     4,    -1,   106,    -1,     3,    -1,     8,    -1,     7,
      -1,    19,    -1,    18,    -1,    17,    -1,    27,    -1,    71,
      -1,    88,    -1,     4,    -1,   106,    -1,     3,    -1,    19,
      -1,    18,    -1,    17,    -1,    27,    -1,    20,    -1,    24,
      -1,    23,    -1,    21,    -1,    22,    -1,    25,    -1,    26,
      -1,    71,    -1,    88,    -1,    -1,   114,    -1,     9,    -1,
     114,     9,    -1,    -1,   116,    -1,     9,    -1,   116,     9,
      -1,   100,     9,    -1,   117,   100,     9,    -1,   100,    -1,
     117,   100,    -1,   104,     9,    -1,    99,   104,     9,    -1,
      99,     9,    -1,   118,   104,     9,    -1,   118,    99,   104,
       9,    -1,   118,    99,     9,    -1,   104,    -1,    99,   104,
      -1,    99,    -1,   118,   104,    -1,   118,    99,   104,    -1,
     118,    99,    -1
  };

  /* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
     YYRHS.  */
  const unsigned short int
  Parser::yyprhs_[] =
  {
         0,     0,     3,     4,     6,     9,    11,    13,    16,    18,
      21,    23,    26,    29,    32,    35,    38,    40,    43,    46,
      49,    52,    55,    59,    62,    64,    66,    69,    73,    75,
      77,    79,    81,    84,    86,    89,    91,    94,    99,   103,
     108,   112,   117,   122,   126,   130,   131,   133,   135,   137,
     139,   142,   145,   148,   151,   153,   157,   162,   167,   173,
     177,   182,   187,   193,   196,   200,   204,   209,   212,   216,
     220,   225,   229,   233,   236,   240,   244,   247,   251,   255,
     258,   262,   266,   269,   273,   277,   280,   284,   288,   291,
     295,   299,   302,   306,   310,   313,   317,   321,   324,   328,
     332,   335,   339,   342,   345,   347,   350,   352,   355,   357,
     360,   363,   366,   369,   372,   375,   379,   380,   382,   386,
     392,   397,   400,   404,   410,   415,   419,   422,   426,   432,
     437,   441,   447,   452,   456,   459,   463,   466,   470,   473,
     478,   482,   488,   493,   499,   506,   514,   518,   521,   526,
     530,   534,   539,   543,   546,   548,   551,   555,   558,   563,
     567,   569,   573,   576,   579,   581,   583,   585,   588,   593,
     596,   601,   605,   608,   610,   615,   618,   623,   627,   630,
     632,   634,   637,   642,   646,   649,   653,   656,   658,   660,
     664,   670,   676,   681,   684,   686,   689,   691,   694,   696,
     699,   701,   704,   706,   709,   711,   714,   716,   719,   721,
     723,   725,   727,   729,   731,   733,   735,   737,   739,   741,
     743,   745,   747,   749,   751,   753,   755,   757,   759,   761,
     763,   765,   767,   769,   771,   773,   775,   777,   779,   781,
     783,   785,   787,   789,   791,   793,   795,   797,   799,   801,
     803,   805,   807,   809,   811,   813,   815,   817,   819,   821,
     823,   825,   827,   829,   831,   833,   835,   837,   839,   841,
     843,   845,   847,   849,   851,   853,   855,   857,   859,   861,
     863,   865,   867,   869,   871,   873,   875,   877,   879,   881,
     883,   885,   887,   889,   891,   893,   895,   897,   899,   901,
     903,   905,   907,   909,   911,   913,   915,   916,   918,   920,
     923,   924,   926,   928,   931,   934,   938,   940,   943,   946,
     950,   953,   957,   962,   966,   968,   971,   973,   976,   980
  };

  /* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
  const unsigned short int
  Parser::yyrline_[] =
  {
         0,    76,    76,    77,    78,    79,    81,    82,    84,    85,
      87,    88,    89,    90,    91,    92,    94,    95,    96,    97,
      98,    99,   101,   102,   103,   105,   106,   108,   110,   111,
     112,   114,   115,   116,   117,   118,   119,   121,   122,   123,
     124,   125,   126,   127,   128,   130,   131,   132,   133,   134,
     135,   136,   137,   138,   140,   142,   143,   144,   145,   146,
     147,   148,   149,   151,   152,   153,   154,   155,   156,   157,
     158,   160,   161,   162,   164,   165,   166,   168,   169,   170,
     172,   173,   174,   176,   177,   178,   180,   181,   182,   184,
     185,   186,   188,   189,   190,   192,   193,   194,   196,   197,
     198,   200,   201,   203,   205,   206,   207,   208,   209,   210,
     211,   212,   213,   214,   216,   217,   219,   220,   222,   223,
     224,   225,   226,   227,   231,   232,   233,   234,   235,   236,
     237,   238,   239,   240,   241,   243,   244,   246,   247,   249,
     250,   251,   252,   253,   254,   255,   256,   257,   258,   259,
     261,   262,   263,   264,   266,   267,   269,   270,   271,   272,
     274,   276,   277,   278,   279,   280,   282,   283,   285,   286,
     287,   288,   289,   290,   291,   292,   293,   294,   295,   296,
     298,   299,   301,   302,   303,   304,   305,   306,   310,   311,
     312,   313,   314,   315,   317,   318,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   334,   335,
     336,   337,   338,   339,   340,   341,   342,   343,   344,   345,
     347,   348,   349,   350,   351,   352,   353,   354,   355,   356,
     357,   358,   359,   360,   361,   362,   363,   364,   367,   368,
     369,   370,   371,   372,   373,   374,   375,   376,   377,   378,
     379,   380,   382,   383,   384,   385,   386,   387,   388,   389,
     390,   391,   392,   393,   394,   395,   397,   398,   399,   400,
     401,   402,   403,   404,   405,   406,   407,   408,   409,   411,
     412,   413,   414,   415,   416,   417,   418,   419,   420,   421,
     423,   424,   425,   426,   427,   428,   429,   430,   431,   432,
     433,   434,   435,   436,   437,   438,   440,   441,   442,   443,
     445,   446,   447,   448,   450,   451,   453,   454,   460,   461,
     462,   463,   464,   465,   467,   468,   469,   470,   471,   472
  };

  // Print the state stack on the debug stream.
  void
  Parser::yystack_print_ ()
  {
    *yycdebug_ << "Stack now";
    for (state_stack_type::const_iterator i = yystate_stack_.begin ();
	 i != yystate_stack_.end (); ++i)
      *yycdebug_ << ' ' << *i;
    *yycdebug_ << std::endl;
  }

  // Report on the debug stream that the rule \a yyrule is going to be reduced.
  void
  Parser::yy_reduce_print_ (int yyrule)
  {
    unsigned int yylno = yyrline_[yyrule];
    int yynrhs = yyr2_[yyrule];
    /* Print the symbols being reduced, and their result.  */
    *yycdebug_ << "Reducing stack by rule " << yyrule - 1
	       << " (line " << yylno << "), ";
    /* The symbols being reduced.  */
    for (int yyi = 0; yyi < yynrhs; yyi++)
      YY_SYMBOL_PRINT ("   $" << yyi + 1 << " =",
		       yyrhs_[yyprhs_[yyrule] + yyi],
		       &(yysemantic_stack_[(yynrhs) - (yyi + 1)]),
		       &(yylocation_stack_[(yynrhs) - (yyi + 1)]));
  }
#endif // YYDEBUG

  /* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
  Parser::token_number_type
  Parser::yytranslate_ (int t)
  {
    static
    const token_number_type
    translate_table[] =
    {
           0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52
    };
    if ((unsigned int) t <= yyuser_token_number_max_)
      return translate_table[t];
    else
      return yyundef_token_;
  }

  const int Parser::yyeof_ = 0;
  const int Parser::yylast_ = 4551;
  const int Parser::yynnts_ = 66;
  const int Parser::yyempty_ = -2;
  const int Parser::yyfinal_ = 230;
  const int Parser::yyterror_ = 1;
  const int Parser::yyerrcode_ = 256;
  const int Parser::yyntokens_ = 53;

  const unsigned int Parser::yyuser_token_number_max_ = 307;
  const Parser::token_number_type Parser::yyundef_token_ = 2;

} // namespace yy

#line 474 "Parser.ypp"

void yy::Parser::error(const yy::Parser::location_type& l, const std::string& m)
{
  driver.error(l, m);
}


