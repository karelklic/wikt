/* This file is part of Wikt.
 * Originally written 2004 by Timwi.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#ifndef LIBWIKT_PARSER_DRIVER_H
#define LIBWIKT_PARSER_DRIVER_H

#include "location.hh"
#include <string>
#include <map>
#include <QString>

typedef enum BisonNodeType
{
    Article, Paragraph, Heading, TextBlock, TextToken, ExtensionToken,
    Newlines, PreBlock, PreLine, Bold, Italics,
    LinkEtc, LinkTarget, LinkOption, Template, TemplateVar,
    Table, TableRow, TableCell, TableHead /* 20 */, TableCaption,
    Attribute, AttributeGroup, Span, Sub, Sup, Div, Br, Big, Small,
    Tt, I, Cite, A, P,

    /* After first parse; temporary. */
    ListBlock, ListLine,
    ListBullet, ListNumbered, ListDefinition,

    /* After processList */
    List, ListItem
} NodeType;

struct NameValue
{
    std::string name;
    std::string value;
};

/* During the parsing of table cells, we don't know in advance whether what we are currently
 * parsing are attributes for the table cell, or the table cell's textual contents. We parse
 * them as attributes first, but we use AttributeDataStruct to store enough data to allow us
 * to turn it back into text should we later find out they weren't attributes after all. */
struct AttributeData
{
    std::string name;
    int type;   /* 0 = just an attribute name; 1 = no quotes; 2 = '; 3 = " */
    int spacesAfterName;
    int spacesAfterEquals;
    int spacesAfterValue;
};

struct DataType
{
    std::string str;
    int num;
    NameValue nameval;
    AttributeData attrdata;
};

struct BisonNode
{
    BisonNodeType type;
    DataType data;
    BisonNode *nextSibling;
    BisonNode *firstChild;
};

BisonNode *newNode(BisonNodeType newType);
BisonNode *newNodeI(BisonNodeType newType, int data);
BisonNode *newNodeS(BisonNodeType newType, const std::string &data);
/* see NameValueStruct */
BisonNode *newNodeN(BisonNodeType newType, const std::string &name, const std::string &value);

/* Used by the lexer to create a preliminary AttributeData object. */
AttributeData newAttributeDataFromStr(const std::string &str);
/* Completes an AttributeData object created by newAttributeDataFromStr */
BisonNode *newNodeA(int t, AttributeData ad, int sae, int sav);

/* Return value of all of these is the first parameter */
BisonNode *nodeAddChild(BisonNode *node, BisonNode *child);
#define nodeAddChild2(a,b,c) nodeAddChild(nodeAddChild(a, b), c)
#define nodeAddChild3(a,b,c,d) nodeAddChild(nodeAddChild(nodeAddChild(a, b), c), d)
BisonNode *nodePrependChild(BisonNode *node, BisonNode *child);
BisonNode *nodeAddSibling(BisonNode *node, BisonNode *sibling);

/* Parameter must be a ListBlock node. Returns a List node. */
BisonNode *processListBlock(BisonNode *block);

/* Parameter must be a PreBlock node. Returns same */
BisonNode *processPreBlock(BisonNode *block);

/* Returns a TextToken, or null if n < 1 */
BisonNode *processEndHeadingInText(int n);

/* If 'node' is a paragraph node with no siblings, frees it and returns its child.
 * (We do this because if a table cell contains only text, we don't want it to
 * count as a "paragraph".) Otherwise just returns node. */
BisonNode *processTableCellContents(BisonNode *node);

/* If a is a TextBlock, adds b to it; if b is a TextBlock, prepends a;
 * if both are a TextBlock, adds b's children to a and frees b;
 * otherwise creates new TextBlock with a and b in it.
 * If any parameter is 0, returns the other. */
BisonNode *makeTextBlock(BisonNode *a, BisonNode *b);
#define makeTextBlock2(a,b,c) makeTextBlock(makeTextBlock(a, b), c)
#define makeTextBlock3(a,b,c,d) makeTextBlock(makeTextBlock(makeTextBlock (a, b), c), d)

/* Parameter must be a TextBlock. Turns something like
 * <italics>X<italics>Y</italics>Z</italics> into
 * <italics>X</italics>Y<italics>Z</italics>. Returns node. */
BisonNode *processNestedItalics(BisonNode *node);

/* Parameter must be a LinkOption node, optionally with a string of
 * siblings attached. These will all be freed, and a TextBlock returned. */
BisonNode *convertPipeSeriesToText(BisonNode *node);

/* Parameter must be a AttributeGroup node. It and its children will
 * all be freed, and a TextBlock returned. */
BisonNode *convertAttributesToText(BisonNode *node);

/* Parameter will be freed, and a TextBlock returned.
 * NOTICE: This will process ONLY the attribute name and the spaces after it. */
BisonNode *convertAttributeDataToText(AttributeData data);

/* These all return a TextToken node. */
BisonNode *convertTableRowToText(int info);
BisonNode *convertTableCellToText(int info);
BisonNode *convertTableHeadToText(int info);
BisonNode *convertTableCaptionToText(int info);
BisonNode *convertHeadingToText(int info);

void freeRecursively(BisonNode *node);
void freeRecursivelyWithSiblings(BisonNode *node);

/* More string helper routines ... */
/* e.g. addSpaces ("=", 2) => "=  " */
std::string addSpaces(const std::string &src, int spaces);
/* trims only *trailing* whitespace. Returns its parameter; does not create a new string. */
std::string &strtrim(std::string &src);
/* like strtrim, but returns the number of spaces removed. */
//int strtrimC(char *src);
/* same as strtrim except takes a TextToken node */
BisonNode *strtrimN(BisonNode *src);
/* like strtrimN, but returns the number of spaces removed. */
int strtrimNC(BisonNode *src);

// From wikiparse.tab.c
// Set it to 1 to get stderr parse trace.
// Set it to 0 to ignore trace.
//extern int yydebug;
extern int yy_flex_debug;

// Conducting the whole scanning and parsing.
class Driver
{
public:
  Driver(bool traceScanning = false, bool traceParsing = false);
  virtual ~Driver();

  // Handling the scanner.
  void scan_begin();
  void scan_end();

  // Handling the parser.
  void parse(const std::string& input);

  // Error handling.
  void error(const yy::location& l, const std::string& m);
  void error(const std::string& m);

//protected:
  std::string _input;
  BisonNode *_result;
  bool _traceScanning;
  bool _traceParsing;
};

#endif
