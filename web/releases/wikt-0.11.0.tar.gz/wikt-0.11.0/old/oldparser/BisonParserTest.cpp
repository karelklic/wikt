/* This file is part of Wikt.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#include "BisonParserTest.h"
#include "BisonParser.h"
#include <QTest>

//===========================================================================
void BisonParserTest::entry_data()
{
  QTest::addColumn<QString>("text");
  QTest::newRow("div0") << QString("<div style=\"float: left;\">[[Image:Wikipedia-logo-en.png|44px|none| ]]</div>");
  QTest::newRow("div1") << QString("<div style=\"margin-left: 10px;\">'''<span class='mention-Latn'>[[w:De|De]]</span>''' </div>");
  QTest::newRow("div2") << QString("<div>a\na\n</div>\n<div>aaa</div>");
  QTest::newRow("div3") << QString("<div>a\na\n</div>\n<div>\n<div>aaa</div>\n<div>aaa</div></div>");
  QTest::newRow("div4") << QString(
    "<div class=\"sister-wikipedia sister-project noprint floatright\" style=\"border: solid #aaa 1px; font-size: 90%; background: #f9f9f9; width: 250px; padding: 4px; text-align: left;\">\n"
    "<div style=\"float: left;\">[[Image:Wikipedia-logo-en.png|44px|none| ]]</div>\n"
    "<div style=\"margin-left: 60px;\">[[Wikipedia]] has an article on:\n"
    "<div style=\"margin-left: 10px;\">'''<span class='mention-Latn'>[[w:De|De]]</span>''' </div>\n"
    "</div></div><span class=\"interProject\">[[w:De|Wikipedia ]]</span>\n"
    "<div class=\"disambig-see-also-2\">''See also'' '''[[Appendix:Variations of \"de\"]]'''</div>"
    "==Translingual==");
  QTest::newRow("span0") << QString(
      "Modification of capital letter <span class='mention-Latn'>[[A|A]]</span>, "
      "from [[w:&#x003b;&#x003b;Template:lang:la&#x003d;&#x003d; language"
      "|&#x003b;&#x003b;Template:lang:la&#x003d;&#x003d;]]"
      "[[Category:&#x003b;&#x003b;Template:lang:la&#x003d;&#x003d; derivations]] "
      "<span class='mention-Latn'>[[A#&#x003b;&#x003b;Template:lang:la&#x003d;&#x003d;|A]]</span>"
      "from [[w:&#x003b;&#x003b;Template:lang:grc&#x003d;&#x003d; language|&#x003b;&#x003b;Template:lang:grc&#x003d;&#x003d;]]"
      "[[Category:&#x003b;&#x003b;Template:lang:grc&#x003d;&#x003d; derivations]] "
      "letter <span lang=\"grc\" xml:lang=\"grc\" class=\"polytonic\">"
      "[[Α#&#x003b;&#x003b;Template:lang:grc&#x003d;&#x003d;|Α]]</span>&nbsp;"
      "<span class='ib-brac'><span class='mention-tr-paren'>(</span></span>"
      "<span class='ib-content'><span class='mention-tr'>A</span></span>"
      "<span class='ib-brac'><span class='mention-tr-paren'>)</span></span>."
      "<br clear=\"left\" />");
  QTest::newRow("span1") << QString(
      "<span class=\"Z3988\" title=\"ctx_ver=Z39.88-2004&rft_val_fmt="
      "&#x007b;&#x007b;Template:urlencode:info:ofi/fmt:kev:mtx:book&#x007d;"
      "&#x007d;&rft.genre=book&rft.btitle=&#x007b;&#x007b;urlencode:[http:"
      "//books.google.com/books?id=sfYOAAAAYAAJ A System of Aeronautics]"
      "&#x007d;&#x007d;&rft.au=&#x007b;&#x007b;urlencode:[[w:John Wise "
      "(balloonist)|John Wise]]&#x007d;&#x007d;&rft.pages=&#x007b;&#x007b;"
      "Template:urlencode:152&#x007d;&#x007d;\">&nbsp;</span>"
      );
  QTest::newRow("newline at the beginning with table") << QString(
      "\n{| test |}"
      );
}

//===========================================================================
void BisonParserTest::entry()
{
  QFETCH(QString, text);
  BisonParser parser("Test", text);
  QVERIFY(parser.parse());
}

//===========================================================================
void BisonParserTest::newlineAtTheBeginningOfEntry()
{
  BisonParser parser("Test", "\nTest");
  QVERIFY(parser.parse());
  QCOMPARE(parser.result()->count(), 2);
}

//===========================================================================
void BisonParserTest::badlyFormattedTableGaNounM1One()
{
  BisonParser parser("ga-noun-m1",
    //";First declension\n"
    "{| cellspacing=\"0\" cellpadding=\"0\" style=\"background-color: transparent; width: 95%\" class=\"inflection-table\"\n"
    "<p></p>\n" // this is terribly wrong
    "| width=\"50%\" align=\"left\" valign=\"top\" |\n"
    "Bare forms\n"
    "|}");
  QVERIFY(parser.parse());
  QCOMPARE(parser.result()->count(), 1);
  QCOMPARE(parser.result()->child(0)->type(), Node::Table);
}

//===========================================================================
void BisonParserTest::badlyFormattedTableGaNounM1Two()
{
  BisonParser parser("ga-noun-m1",
    "; First declension\n"
    "{| cellspacing=\"0\" cellpadding=\"0\" style=\"background-color: transparent; width: 95%\" class=\"inflection-table\"\n"
    "<p></p>\n" // this is terribly wrong
    "| width=\"50%\" align=\"left\" valign=\"top\" |\n"
    "Bare forms\n"
    "|}");
  QVERIFY(parser.parse());
  QCOMPARE(parser.result()->count(), 2);
  QCOMPARE(parser.result()->child(0)->type(), Node::List);
}
