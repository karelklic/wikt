/* This file is part of Wikt.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#ifndef WIKT_LEXER_PARSER_VIEW_H
#define WIKT_LEXER_PARSER_VIEW_H

#include <QDockWidget>

QT_BEGIN_NAMESPACE
class QTextEdit;
class QLineEdit;
QT_END_NAMESPACE

/// A window that shows lexer and parser debugging output.
class LexerParserView : public QDockWidget
{
  Q_OBJECT
public:
  /// Standard constructor.
  /// @param lexer
  ///   Whether it should show debug output from the lexer.
  /// @param parser
  ///   Whether it should show debug output from the parser.
  LexerParserView(bool lexer, bool parser);

  void setWord(const QString &word);

private slots:
  void onEditingFinished();

private:
  QLineEdit *_wordEdit;
  QTextEdit *_editor;
  bool _lexer, _parser;
};

#endif
