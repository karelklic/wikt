/* This file is part of Wikt.
 * Originally written 2004 by Timwi.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#include "Driver.h"
#include "Parser.tab.hpp"
#include "../../Debug.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

//===========================================================================
Driver::Driver (bool traceScanning, bool traceParsing) : _result(0),
  _traceScanning(traceScanning), _traceParsing(traceParsing)
{
}

//===========================================================================
Driver::~Driver ()
{
  if (_result)
    ::freeRecursively(_result);
}

//===========================================================================
void Driver::parse(const std::string &input)
{
  this->_input = input;
  scan_begin();
  yy::Parser parser(*this);
  parser.set_debug_level(_traceParsing);
  parser.parse();
  scan_end();
}

//===========================================================================
void Driver::error(const yy::location& l, const std::string& m)
{
  std::cerr << l << ": " << m << std::endl;
}

//===========================================================================
void Driver::error(const std::string& m)
{
  std::cerr << m << std::endl;
}

/* - use this to find out if any nodes are allocated but never freed
#define debugMemLeak_alloc(x,y) printf("alloc: %u (%u)\n", x, y);
#define freeNode(node) \
    printf("free: %u (%u)\n", node, node->type); \
    free (node);
/*/
#define debugMemLeak_alloc(x,y)
#define freeNode(node) free(node)
/**/

//===========================================================================
BisonNode *newNode(BisonNodeType newType)
{
    BisonNode *result = new BisonNode();
    result->type = newType;
    result->firstChild = 0;
    result->nextSibling = 0;
    debugMemLeak_alloc(_result, newType);
    return result;
}

//===========================================================================
BisonNode *newNodeI(BisonNodeType newType, int data)
{
    BisonNode *result = newNode(newType);
    result->data.num = data;
    return result;
}

//===========================================================================
BisonNode *newNodeS(BisonNodeType newType, const std::string &data)
{
    BisonNode *result = newNode(newType);
    result->data.str = data;
    return result;
}

//===========================================================================
BisonNode *newNodeN(BisonNodeType newType, const std::string &name, const std::string &value)
{
    BisonNode *result = newNode(newType);
    result->data.nameval.name  = name;
    result->data.nameval.value = value;
    return result;
}

//===========================================================================
AttributeData newAttributeDataFromStr(const std::string &str)
{
    AttributeData ret;
    int len = str.length();
    int i = len-1;

    while (str[i] == ' ') i--;
    i++;
    ret.name = str.substr(0, i);
    ret.spacesAfterName = len-i;
    return ret;
}

//===========================================================================
BisonNode *newNodeA(int t, AttributeData ad, int sae, int sav)
{
    BisonNode *result = newNode(Attribute);
    result->data.attrdata = ad;
    result->data.attrdata.type = t;
    result->data.attrdata.spacesAfterEquals = sae;
    result->data.attrdata.spacesAfterValue = sav;
    return result;
}

//===========================================================================
/* Return value is the first parameter */
BisonNode *nodeAddChild(BisonNode *node, BisonNode *child)
{
    BisonNode *find;
    if (child)
    {
        if (node->firstChild)
        {
            find = node->firstChild;
            while (find->nextSibling)
                find = find->nextSibling;
            find->nextSibling = child;
        }
        else node->firstChild = child;
    }
    return node;
}

//===========================================================================
/* Return value is the first parameter */
BisonNode *nodeAddSibling(BisonNode *node, BisonNode *sibling)
{
    BisonNode *examine = node;
    if (sibling)
    {
        while (examine->nextSibling)
            examine = examine->nextSibling;
        examine->nextSibling = sibling;
    }
    return node;
}

//===========================================================================
/* Return value is the first parameter */
BisonNode *nodePrependChild(BisonNode *node, BisonNode *child)
{
    BisonNode *prevChild = node->firstChild;
    node->firstChild = child;
    return nodeAddChild(node, prevChild);
}

//===========================================================================
void freeRecursively(BisonNode *node)
{
  BisonNode *next, *child = node->firstChild;
  while(child)
  {
    next = child->nextSibling;
    freeRecursively(child);
    child = next;
  }
  freeNode(node);
}

//===========================================================================
void freeRecursivelyWithSiblings(BisonNode *node)
{
  BisonNode *next, *sibling = node;
  while(sibling)
  {
    next = sibling->nextSibling;
    freeRecursively(sibling);
    sibling = next;
  }
}

//===========================================================================
void removeAndFreeFirstChild(BisonNode *node)
{
    BisonNode *child = node->firstChild;
    if (!child) return;
    node->firstChild = child->nextSibling;
    freeRecursively(child);
}

//===========================================================================
// Parameter must be a ListLine node. Returns a List node.
BisonNode *processListLineHelper(BisonNode *start)
{
    BisonNodeType type, subtype;
    BisonNode *result, *curChild, *examine, *item, *previous, *l, *toBeFreed;
    if (!start) return 0;
    if (start->type != ListLine) return 0;
    if (!start->firstChild) return 0;
    type = start->firstChild->type;
    result = newNodeI(List,
        type == ListBullet     ? 1 :
        type == ListNumbered   ? 2 :
        type == ListDefinition ? 3 :
        0);

    curChild = 0;
    examine = start;
    while (examine)
    {
        toBeFreed = examine;
        // We know that examine->firstChild is ListBullet, ListNumbered, etc. Remove it.
        removeAndFreeFirstChild(examine);
        // Empty list item?
        if (!examine->firstChild)
        {
            examine = examine->nextSibling;
            freeNode(toBeFreed);
        }
        // Does this item start a new list?
        else if (examine->firstChild->type == ListBullet ||
                 examine->firstChild->type == ListNumbered ||
                 examine->firstChild->type == ListDefinition)
        {
            // If we are starting a new list, we want it to be inside the previous list item.
            // However, if that previous list item does not exist, we need to create a new one.
            if (!curChild)
            {
                item = newNodeI(ListItem,
                    (examine->firstChild->type == ListDefinition) ? examine->firstChild->data.num : 0);
                result->firstChild = item;
                curChild = item;
            }
            subtype = examine->firstChild->type;
            // progressively remove the firstChild for that sublist
            previous = examine;
            l = examine->nextSibling;
            while (l && l->firstChild &&
                   l->firstChild->nextSibling &&
                   l->firstChild->nextSibling->type == subtype)
            {
                removeAndFreeFirstChild(l);
                previous = l;
                l = l->nextSibling;
            }
            // trick recursive call into thinking list ends here
            previous->nextSibling = 0;
            // notice that the recursive call will take care of freeing the node
            nodeAddChild(curChild, processListLineHelper(examine));
            previous->nextSibling = l;
            examine = l;
        }
        // Otherwise it's a normal plain old list item.
        else
        {
            item = newNodeI(ListItem, start->data.num);
            if (curChild) curChild->nextSibling = item;
            else result->firstChild = item;
            curChild = item;
            nodeAddChild(curChild, examine->firstChild);
            examine = examine->nextSibling;
            freeNode(toBeFreed);
        }
    }
    return result;
}

//===========================================================================
/* Parameter must be a ListBlock node. Returns a List node. */
BisonNode *processListBlock(BisonNode *block)
{
  BisonNode *child;
  if (!block) return 0;
  if (block->type != ListBlock) return 0;
  if (!block->firstChild) return 0;
  if (block->firstChild->type != ListLine) return 0;

  child = block->firstChild;
  freeNode(block);
  return processListLineHelper(child);
}

//===========================================================================
/*  The PreBlock node returned by the grammar contains one or more PreLine
 *  nodes, each of which has one or two children. The first child is something
 *  representing text. The second, if present, is a Newlines node. We want to
 *  convert those Newlines nodes to empty PreLine nodes, except for the very
 *  last one in the block, which we want to discard.
 *
 *  It is harmless to call this twice on the same block (the second time won't
 *  make any more changes), but for efficiency, don't.
 */
BisonNode *processPreBlock(BisonNode *block)
{
    BisonNode *result, *examine, *newlinesnode, *tmpnode;

    /******     EXAMPLE    ******
     *
     *      (*) node(type=PreBlock)
     *       |
     *       | firstChild
     *       |
     *       |A(type=PreLine)                      B(type=PreLine)
     *      (*)------------nextSibling------------(*)
     *       |                                     |
     *       | firstChild                          | firstChild
     *       |                                     |
     *       |W(type=TextToken)  X(type=Newlines)  |Y(type=TextToken)  Z(type=Newlines)
     *      (*)---nextSibling---(*)(num=2)        (*)---nextSibling---(*)(num=1)
     *
     *  We want to convert X to two PreLine nodes and get rid of Z.
     *  The following is the end-result:
     *
     *      (*) node(type=PreBlock)
     *       |
     *       | firstChild
     *       |
     *       |A(type=PreLine)    C(type=PreLine)     D(type=PreLine)     B(type=PreLine)
     *      (*)---nextSibling---(*)---nextSibling---(*)---nextSibling---(*)
     *       |                                                           |
     *       | firstChild                                                | firstChild
     *       |                                                           |
     *       |W(type=TextToken)                                          |Y(type=TextToken)
     *      (*)                                                         (*)
     *
     *  Notice how X has been removed and C and D created instead, while Z has been removed with
     *  no replacement. Notice also that W & Y might as well be TextBlocks, ExtensionTokens, etc.
     *
     */
    result = block;
    /* Iteratively examine all of the block's children (A and B) */
    examine = block->firstChild;
    while (examine)
    {
        /* If a Newlines node exists (i.e. X or Z)... */
        if (examine->firstChild->nextSibling)
        {
            newlinesnode = examine->firstChild->nextSibling;
            /* Detach the Newlines node from examine */
            examine->firstChild->nextSibling = 0;
            /* If this isn't the last PreLine in the block... */
            if (examine->nextSibling)
            {
                /* Remember the next sibling (B) */
                tmpnode = examine->nextSibling;
                /* Convert Newlines node to empty PreLine nodes */
                while (newlinesnode->data.num--)
                {
                    /* Insert an empty PreLine node (C and D) */
                    examine->nextSibling = newNode (PreLine);
                    /* Move on to the newly-created node */
                    examine = examine->nextSibling;
                }
                /* Re-attach the next sibling (B) */
                examine->nextSibling = tmpnode;
            }
            /* Newlines nodes don't have children, no need for freeRecursively */
            freeNode (newlinesnode);
        }
        examine = examine->nextSibling;
    }
    return result;
}

//===========================================================================
BisonNode *processEndHeadingInText(int n)
{
    char* ret;
    int equalses, spaces, i;
    equalses = n % 0x10000;
    spaces   = n >> 16;
    if (equalses + spaces < 1) return 0;
    ret = (char*)malloc((equalses + spaces + 1) * sizeof(char));
    i = 0;
    while (equalses--) ret[i++] = '=';
    while (spaces--)   ret[i++] = ' ';
    ret[i] = '\0';
    return newNodeS(TextToken, ret);
}

//===========================================================================
BisonNode *processTableCellContents(BisonNode *node)
{
    BisonNode *ret;
    if (!node) return 0;
    if (node->type == Paragraph && !node->nextSibling)
    {
        ret = node->firstChild;
        freeNode (node);
        return ret;
    }
    return node;
}

//===========================================================================
BisonNode *processNestedItalics(BisonNode *node)
{
    BisonNode *examine, *saveExamineSibling, *childExamine, *childSibling, *saveChildSibling;
    if (!node) return 0;
    if (node->type != TextBlock) return node;

    /******     EXAMPLE    ******
     *
     *      (*) node(type=TextBlock)
     *       |
     *       | firstChild
     *       |
     *       |A(type=TextToken)  B(type=Italics)     C(type=TextToken)
     *      (*)---nextSibling---(*)---nextSibling---(*)
     *                           |
     *                           | firstChild
     *                           |
     *                          (*) T(type=TextBlock)
     *                           |
     *                           | firstChild
     *                           |
     *                           |W(type=TextToken)  X(type=Italics)     Y(type=TextToken)
     *                          (*)---nextSibling---(*)---nextSibling---(*)
     *                                               |
     *                                               | firstChild
     *                                               |
     *                                              (*) Z
     *
     *  Here we have two Italics nodes nested inside each other (X is inside B).
     *  The following is the end-result:
     *
     *      (*) node(type=TextBlock)
     *       |
     *       | firstChild
     *       |                 B                                  new
     *       |A             Italics              Z              Italics              C
     *      (*)--nextSibling--(*)--nextSibling--(*)--nextSibling--(*)--nextSibling--(*)
     *                         | firstChild                        | firstChild
     *                        (*) T                               (*) Y
     *                         | firstChild
     *                        (*) W
     *
     *  T is no longer really necessary, but specifically freeing it is pointless, so we keep it.
     *
     */

    for (examine = node->firstChild; examine; examine = examine->nextSibling)
    {
        /* In the above example, examine = B, but as new nodes are created and made siblings of B,
         * examine walks along them. Either way, it is the node just before C. */
        if (examine->type == Italics && examine->firstChild &&
            examine->firstChild /* i.e. T */->type == TextBlock)
        {
            /* Remember B's original sibling (C). We are going to insert a number of new
             * siblings after B, so at the end we want to re-attach C to the last one. */
            saveExamineSibling = examine->nextSibling;

            childExamine = examine->firstChild /* i.e. T */->firstChild /* i.e. W */;
            /* childSibling will be our "iterator" for iterating over the children of T */
            childSibling = childExamine->nextSibling;
            childExamine->nextSibling = 0;      /* Detach W's siblings */

            while (childSibling)
            {
                /* Remember the sibling we want to move on to later */
                saveChildSibling = childSibling->nextSibling;

                /* If we find a nested Italics (X in the example), move its child (Z) out
                 * and make it a sibling of B. */
                if (childSibling->type == Italics)
                {
                    examine->nextSibling = childSibling->firstChild;
                    /* Move examine on to the newly created sibling */
                    examine = examine->nextSibling;
                    /* Free the now-obsolete Italics node */
                    /* We have attached its children elsewhere, so don't use freeRecursively */
                    freeNode (childSibling);
                }
                /* Any node that is not an Italics node needs to become attached to one.
                 * (In the above example, this is only Y.) */
                else
                {
                    /* Detach the two */
                    childSibling->nextSibling = 0;

                    /* If examine already points to an Italics node, don't create a new one. */
                    /* Instead, combine its child and this one. (Doesn't occur in the example.) */
                    if (examine->type == Italics)
                        examine->firstChild = makeTextBlock (examine->firstChild, childSibling);
                    else
                    {
                        /* Create a new Italics node, attach the current node (Y) to it, and make
                         * it the next-distant sibling of B */
                        examine->nextSibling = nodeAddChild (newNode (Italics), childSibling);
                        examine = examine->nextSibling;
                    }
                }
                childSibling = saveChildSibling;
            }
            /* Now re-attach the previous sibling of B (i.e. C). */
            examine->nextSibling = saveExamineSibling;
        }
    }
    return node;
}

//===========================================================================
BisonNode *makeTextBlock(BisonNode *a, BisonNode *b)
{
    if (!a) return b;
    if (!b) return a;
    if (a->type == TextBlock && b->type == TextBlock)
    {
        nodeAddChild (a, b->firstChild);
        /* We have attached b's children elsewhere, so don't use freeRecursively */
        freeNode (b);
        return a;
    }
    else if (a->type == TextBlock)
        return nodeAddChild (a, b);
    else if (b->type == TextBlock)
        return nodePrependChild (b, a);
    else
        return nodeAddChild2 (newNode (TextBlock), a, b);
}

//===========================================================================
BisonNode *convertAttributesToText(BisonNode *node)
{
    int len, at;
    BisonNode *ret = 0, *examine = node->firstChild, *prevExamine;
    AttributeData ad;

    if (node->type != AttributeGroup) return 0;

    /* We've stored the first child in examine, so we can already free the parent */
    freeNode(node);

    while (examine) /* should be an Attribute node */
    {
        ad = examine->data.attrdata;
        /* first turn attribute name, equals sign (if any) and
         * opening apostrophe or quotes (if any) into one string */
        len = ad.name.length();
        at = len;
        len += ad.spacesAfterName;
        if (ad.type > 0)
        {
            len++; /* '=' */
            len += ad.spacesAfterEquals;
            if (ad.type > 1) len++;  /* ' or " */
        }
        len++; /* trailing '\0' */

        std::string str = ad.name.substr(0, at);
        str.append(ad.spacesAfterName, ' ');
        if (ad.type > 0)
        {
          str.append(1, '=');
          str.append(ad.spacesAfterEquals, ' ');
          if (ad.type == 2) str.append(1, '\'');
          else if (ad.type == 3) str.append(1, '"');
        }

        ret = makeTextBlock2(ret, newNodeS(TextToken, str), examine->firstChild);

        if (ad.type > 1 || (ad.type == 1 && ad.spacesAfterValue > 0))
        {
            at = ad.type > 1 ? 1 : 0;
            len = at + ad.spacesAfterValue;
            str.clear();
            if (ad.type == 2) str = "\'";
            else if (ad.type == 3) str = "\"";
            str.append(ad.spacesAfterValue, ' ');
            ret = makeTextBlock(ret, newNodeS(TextToken, str));
        }
        prevExamine = examine;
        examine = examine->nextSibling;
        freeNode(prevExamine);
    }

    return ret;
}

//===========================================================================
BisonNode *convertAttributeDataToText(AttributeData data)
{
  return makeTextBlock(newNodeS(TextToken, data.name),
    newNodeS(TextToken, addSpaces("", data.spacesAfterName)));
}

//===========================================================================
BisonNode *convertPipeSeriesToText(BisonNode *node)
{
    BisonNode *result = 0;
    BisonNode *nextNode, *child;
    while (node)
    {
        nextNode = node->nextSibling;
        child = node->firstChild;

        /* Performance optimisation: Instead of freeing 'node' and creating a new
         * TextToken node, we'll reuse this one! */
        node->type = TextToken;
        node->data.str = "|";
        node->nextSibling = 0;
        node->firstChild = 0;

        result = makeTextBlock2(result, node, child);
        node = nextNode;
    }
    return result;
}

//===========================================================================
BisonNode *convertTableRowToText(int info)
{
    int minuses, spaces, i;
    char* text;

    minuses = info / 0x10000;
    spaces  = info % 0x10000;

    text = (char*)malloc((minuses + spaces + 2) * sizeof(char));
    text[0] = '|';
    i = 1;
    while (minuses--) text[i++] = '-';
    while (spaces--)  text[i++] = ' ';
    text[i] = '\0';
    return newNodeS(TextToken, text);
}

//===========================================================================
BisonNode *convertTableCellToText(int info)
{
    return newNodeS(TextToken, addSpaces(info % 2 ? "|" : "||", info / 2));
}

//===========================================================================
BisonNode *convertTableHeadToText(int info)
{
    return newNodeS(TextToken, addSpaces(info % 2 ? "!" : "!!", info / 2));
}

//===========================================================================
BisonNode *convertTableCaptionToText(int info)
{
    return newNodeS(TextToken, addSpaces("|+", info));
}

//===========================================================================
BisonNode *convertHeadingToText(int info)
{
    int i;
    char* text;

    text = (char*)malloc((info + 1) * sizeof(char));
    i = 0;
    while (info--) text[i++] = '=';
    text[i] = '\0';
    return newNodeS(TextToken, text);
}

//===========================================================================
std::string addSpaces(const std::string &src, int spaces)
{
  std::string ret(src);
  ret.append(spaces, ' ');
  return ret;
}

//===========================================================================
std::string &strtrim(std::string &src)
{
    int i = src.length() - 1;
    while ((i > 0) && (src[i] == ' ')) i--;
    src.resize(i + 1);
    return src;
}

//===========================================================================
int strtrimC(std::string &src)
{
    int i = src.length() - 1, j = i;
    while ((i > 0) && (src[i] == ' ')) i--;
    src.resize(i + 1);
    return j - i;
}

//===========================================================================
BisonNode *strtrimN(BisonNode *src)
{
    if (src->type == TextToken)
        strtrim(src->data.str);
    return src;
}

//===========================================================================
int strtrimNC(BisonNode *src)
{
    if (src->type == TextToken)
        return strtrimC(src->data.str);
    return 0;
}
