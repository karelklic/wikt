/* This file is part of Wikt.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#include "Trace.h"
#include "Driver.h"
#include "../../Unicode.h"
#include <QFile>
#include <cstdio>
#include <sstream>
#include <fstream>

namespace Parser
{
  namespace Trace
  {
    QString fromContents(const QString &contents, bool lexer, bool parser)
    {
      // Redirect C++ stderr.
      std::stringstream tempStr;
      std::streambuf* fileSbuf = tempStr.rdbuf();
      std::streambuf* stderrSbuf = std::cerr.rdbuf(fileSbuf);

      // Redirect C stdout and stderr.
      FILE *oldStdOut = stdout, *oldStdErr = stderr;
      fflush(stdout); fflush(stderr);
      stdout = fopen("temp.txt", "w");
      stderr = stdout;

      // Parse.
      std::string escaped = Unicode::escape(contents);
      Driver driver(lexer, parser);
      driver.parse(escaped);

      // Restore original C stdout and stderr.
      fflush(stdout); fflush(stderr);
      fclose(stdout);
      stdout = oldStdOut;
      stderr = oldStdErr;

      // Restore original C++ stderr.
      std::cerr.rdbuf(stderrSbuf);

      QFile file("temp.txt");
      file.open(QIODevice::ReadOnly);
      QByteArray ascii = file.readAll();
      file.close();
      file.remove();
      return QString::fromAscii(ascii.data(), ascii.length()) + QString::fromStdString(tempStr.str());
    }
  }
}

