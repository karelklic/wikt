/* This file is part of Wikt.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#include "BisonParser.h"
#include "Driver.h"
#include "../../Unicode.h"
#include "../Tree/ArticleNode.h"
#include "../Tree/AttributeGroupNode.h"
#include "../Tree/AttributeNode.h"
#include "../Tree/BoldNode.h"
#include "../Tree/ExtensionTokenNode.h"
#include "../Tree/HeadingNode.h"
#include "../Tree/HtmlElementNode.h"
#include "../Tree/ItalicsNode.h"
#include "../Tree/LinkNode.h"
#include "../Tree/LinkOptionsNode.h"
#include "../Tree/LinkTargetNode.h"
#include "../Tree/ListItemNode.h"
#include "../Tree/ListNode.h"
#include "../Tree/NewlinesNode.h"
#include "../Tree/ParagraphNode.h"
#include "../Tree/PreBlockNode.h"
#include "../Tree/PreLineNode.h"
#include "../Tree/TableCaptionNode.h"
#include "../Tree/TableCellNode.h"
#include "../Tree/TableHeadNode.h"
#include "../Tree/TableNode.h"
#include "../Tree/TableRowNode.h"
#include "../Tree/TextBlockNode.h"
#include "../Tree/TextTokenNode.h"

//===========================================================================
BisonParser::BisonParser(const QString &name, const QString &contents)
  : _name(name), _contents(contents), _result(0)
{
}

//===========================================================================
BisonParser::~BisonParser()
{
  if (_result)
    delete _result;
}

//===========================================================================
static Node *buildFromNode(::BisonNode *node)
{
  if (!node) return 0;
  Node *ret;
  switch (node->type)
  {
  case ::A: ret = new HtmlElementNode("a", Unicode::unescape(node->data.str)); break;
  case ::Article: ret = new ArticleNode(); break;
  case ::AttributeGroup: ret = new AttributeGroupNode(); break;
  case ::Attribute:
    ret = new AttributeNode(QString::fromStdString(node->data.attrdata.name),
                            node->data.attrdata.type == 0);
    break;
  case ::Big: ret = new HtmlElementNode("big", Unicode::unescape(node->data.str)); break;
  case ::Bold: ret = new BoldNode(); break;
  case ::Br: ret = new HtmlElementNode("br", Unicode::unescape(node->data.str).remove("/")); break;
  case ::Cite: ret = new HtmlElementNode("cite", Unicode::unescape(node->data.str)); break;
  case ::Div: ret = new HtmlElementNode("div", Unicode::unescape(node->data.str)); break;
  case ::ExtensionToken:
    ret = new ExtensionTokenNode(
        QString::fromStdString(node->data.nameval.name),
        QString::fromStdString(node->data.nameval.value));
    break;
  case ::Heading: ret = new HeadingNode(node->data.num); break;
  case ::I: ret = new HtmlElementNode("i", Unicode::unescape(node->data.str)); break;
  case ::Italics: ret = new ItalicsNode(); break;
  case ::LinkEtc:
    ret = new LinkNode(node->data.num & 1, node->data.num & 2);
    break;
  case ::LinkOption: ret = new LinkOptionsNode(); break;
  case ::LinkTarget: ret = new LinkTargetNode(); break;
  case ::ListItem: ret = new ListItemNode(node->data.num == 1); break;
  case ::List:
     ret = new ListNode(node->data.num == 1 ? ListNode::BulletType :
                       (node->data.num == 2 ? ListNode::NumberedType :
                       (node->data.num == 3 ? ListNode::IndentType : ListNode::NoType)));
    break;
  case ::Newlines: ret = new NewlinesNode(); break;
  case ::Paragraph: ret = new ParagraphNode(); break;
  case ::PreBlock: ret = new PreBlockNode(); break;
  case ::PreLine: ret = new PreLineNode(); break;
  case ::Small: ret = new HtmlElementNode("small", Unicode::unescape(node->data.str)); break;
  case ::Span: ret = new HtmlElementNode("span", Unicode::unescape(node->data.str)); break;
  case ::Sub: ret = new HtmlElementNode("sub", Unicode::unescape(node->data.str)); break;
  case ::Sup: ret = new HtmlElementNode("sup", Unicode::unescape(node->data.str)); break;
  case ::TableCaption: ret = new TableCaptionNode(); break;
  case ::TableCell: ret = new TableCellNode(); break;
  case ::TableHead: ret = new TableHeadNode(); break;
  case ::Table: ret = new TableNode(); break;
  case ::TableRow: ret = new TableRowNode(); break;
  case ::Tt: ret = new HtmlElementNode("tt", Unicode::unescape(node->data.str)); break;
  case ::TextBlock: ret = new TextBlockNode(); break;
  case ::TextToken: ret = new TextTokenNode(Unicode::unescape(node->data.str)); break;
  default: ret = new Node(Node::None); break;
  }

  ::BisonNode *child = node->firstChild;
  while (child)
  {
    Node *domChild = buildFromNode(child);
    ret->append(domChild);
    child = child->nextSibling;
  }

  return ret;
}

//===========================================================================
Node *BisonParser::parse()
{
  PROFILER;
  Driver driver;
  driver.parse(Unicode::escape(_contents));
  _result = buildFromNode(driver._result);
  if (_result && _result->type() == Node::Article)
    dynamic_cast<ArticleNode*>(_result)->setName(_name);
  else
  {
    _result = new ArticleNode();
    dynamic_cast<ArticleNode*>(_result)->setName(_name);
  }
  return _result;
}
