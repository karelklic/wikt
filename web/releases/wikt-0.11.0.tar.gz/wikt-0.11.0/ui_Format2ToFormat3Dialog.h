/********************************************************************************
** Form generated from reading ui file 'Format2ToFormat3Dialog.ui'
**
** Created: Wed Apr 22 14:55:52 2009
**      by: Qt User Interface Compiler version 4.4.3
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_FORMAT2TOFORMAT3DIALOG_H
#define UI_FORMAT2TOFORMAT3DIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPlainTextEdit>
#include <QtGui/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_Format2ToFormat3DialogClass
{
public:
    QLineEdit *destinationEdit;
    QPlainTextEdit *reportEdit;
    QLabel *sourceLabel;
    QLineEdit *sourceEdit;
    QPushButton *startButton;
    QPushButton *browseSourceButton;
    QPushButton *browseDestinationButton;
    QLabel *destinationLabel;

    void setupUi(QDialog *Format2ToFormat3DialogClass)
    {
    if (Format2ToFormat3DialogClass->objectName().isEmpty())
        Format2ToFormat3DialogClass->setObjectName(QString::fromUtf8("Format2ToFormat3DialogClass"));
    Format2ToFormat3DialogClass->resize(400, 300);
    Format2ToFormat3DialogClass->setMinimumSize(QSize(400, 300));
    Format2ToFormat3DialogClass->setMaximumSize(QSize(400, 300));
    destinationEdit = new QLineEdit(Format2ToFormat3DialogClass);
    destinationEdit->setObjectName(QString::fromUtf8("destinationEdit"));
    destinationEdit->setGeometry(QRect(90, 40, 221, 26));
    reportEdit = new QPlainTextEdit(Format2ToFormat3DialogClass);
    reportEdit->setObjectName(QString::fromUtf8("reportEdit"));
    reportEdit->setGeometry(QRect(10, 110, 381, 181));
    reportEdit->setUndoRedoEnabled(false);
    reportEdit->setReadOnly(true);
    reportEdit->setCenterOnScroll(false);
    sourceLabel = new QLabel(Format2ToFormat3DialogClass);
    sourceLabel->setObjectName(QString::fromUtf8("sourceLabel"));
    sourceLabel->setGeometry(QRect(10, 20, 52, 16));
    sourceEdit = new QLineEdit(Format2ToFormat3DialogClass);
    sourceEdit->setObjectName(QString::fromUtf8("sourceEdit"));
    sourceEdit->setGeometry(QRect(90, 10, 221, 26));
    startButton = new QPushButton(Format2ToFormat3DialogClass);
    startButton->setObjectName(QString::fromUtf8("startButton"));
    startButton->setGeometry(QRect(10, 80, 381, 26));
    browseSourceButton = new QPushButton(Format2ToFormat3DialogClass);
    browseSourceButton->setObjectName(QString::fromUtf8("browseSourceButton"));
    browseSourceButton->setGeometry(QRect(320, 10, 71, 26));
    browseDestinationButton = new QPushButton(Format2ToFormat3DialogClass);
    browseDestinationButton->setObjectName(QString::fromUtf8("browseDestinationButton"));
    browseDestinationButton->setGeometry(QRect(320, 40, 71, 26));
    destinationLabel = new QLabel(Format2ToFormat3DialogClass);
    destinationLabel->setObjectName(QString::fromUtf8("destinationLabel"));
    destinationLabel->setGeometry(QRect(10, 50, 71, 16));

    retranslateUi(Format2ToFormat3DialogClass);
    QObject::connect(browseSourceButton, SIGNAL(clicked()), Format2ToFormat3DialogClass, SLOT(onBrowseSourceButtonClick()));
    QObject::connect(browseDestinationButton, SIGNAL(clicked()), Format2ToFormat3DialogClass, SLOT(onBrowseDestinationButtonClick()));
    QObject::connect(startButton, SIGNAL(clicked()), Format2ToFormat3DialogClass, SLOT(onStartButtonClick()));

    QMetaObject::connectSlotsByName(Format2ToFormat3DialogClass);
    } // setupUi

    void retranslateUi(QDialog *Format2ToFormat3DialogClass)
    {
    Format2ToFormat3DialogClass->setWindowTitle(QApplication::translate("Format2ToFormat3DialogClass", "Format2 to Format3 Converter", 0, QApplication::UnicodeUTF8));
    sourceLabel->setText(QApplication::translate("Format2ToFormat3DialogClass", "Source", 0, QApplication::UnicodeUTF8));
    startButton->setText(QApplication::translate("Format2ToFormat3DialogClass", "Start", 0, QApplication::UnicodeUTF8));
    browseSourceButton->setText(QApplication::translate("Format2ToFormat3DialogClass", "Browse", 0, QApplication::UnicodeUTF8));
    browseDestinationButton->setText(QApplication::translate("Format2ToFormat3DialogClass", "Browse", 0, QApplication::UnicodeUTF8));
    destinationLabel->setText(QApplication::translate("Format2ToFormat3DialogClass", "Destination", 0, QApplication::UnicodeUTF8));
    Q_UNUSED(Format2ToFormat3DialogClass);
    } // retranslateUi

};

namespace Ui {
    class Format2ToFormat3DialogClass: public Ui_Format2ToFormat3DialogClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FORMAT2TOFORMAT3DIALOG_H
