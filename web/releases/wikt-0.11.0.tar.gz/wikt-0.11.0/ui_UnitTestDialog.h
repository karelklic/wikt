/********************************************************************************
** Form generated from reading ui file 'UnitTestDialog.ui'
**
** Created: Wed Apr 22 14:55:52 2009
**      by: Qt User Interface Compiler version 4.4.3
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_UNITTESTDIALOG_H
#define UI_UNITTESTDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QPlainTextEdit>
#include <QtGui/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_UnitTestDialogClass
{
public:
    QVBoxLayout *verticalLayout;
    QPlainTextEdit *reportEdit;

    void setupUi(QDialog *UnitTestDialogClass)
    {
    if (UnitTestDialogClass->objectName().isEmpty())
        UnitTestDialogClass->setObjectName(QString::fromUtf8("UnitTestDialogClass"));
    UnitTestDialogClass->resize(400, 300);
    verticalLayout = new QVBoxLayout(UnitTestDialogClass);
    verticalLayout->setSpacing(6);
    verticalLayout->setMargin(11);
    verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
    reportEdit = new QPlainTextEdit(UnitTestDialogClass);
    reportEdit->setObjectName(QString::fromUtf8("reportEdit"));
    reportEdit->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    reportEdit->setUndoRedoEnabled(false);
    reportEdit->setReadOnly(true);
    reportEdit->setCenterOnScroll(false);

    verticalLayout->addWidget(reportEdit);


    retranslateUi(UnitTestDialogClass);

    QMetaObject::connectSlotsByName(UnitTestDialogClass);
    } // setupUi

    void retranslateUi(QDialog *UnitTestDialogClass)
    {
    UnitTestDialogClass->setWindowTitle(QApplication::translate("UnitTestDialogClass", "Unit Tests", 0, QApplication::UnicodeUTF8));
    Q_UNUSED(UnitTestDialogClass);
    } // retranslateUi

};

namespace Ui {
    class UnitTestDialogClass: public Ui_UnitTestDialogClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_UNITTESTDIALOG_H
