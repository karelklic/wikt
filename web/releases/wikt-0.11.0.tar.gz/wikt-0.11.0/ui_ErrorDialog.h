/********************************************************************************
** Form generated from reading ui file 'ErrorDialog.ui'
**
** Created: Wed Apr 22 14:55:52 2009
**      by: Qt User Interface Compiler version 4.4.3
**
** WARNING! All changes made in this file will be lost when recompiling ui file!
********************************************************************************/

#ifndef UI_ERRORDIALOG_H
#define UI_ERRORDIALOG_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QDialog>
#include <QtGui/QHBoxLayout>
#include <QtGui/QLabel>
#include <QtGui/QPlainTextEdit>
#include <QtGui/QPushButton>
#include <QtGui/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_ErrorDialogClass
{
public:
    QVBoxLayout *verticalLayout;
    QLabel *message;
    QLabel *file;
    QLabel *function;
    QLabel *stackTraceLabel;
    QPlainTextEdit *stackTraceEdit;
    QHBoxLayout *horizontalLayout;
    QPushButton *ignore;
    QPushButton *ok;

    void setupUi(QDialog *ErrorDialogClass)
    {
    if (ErrorDialogClass->objectName().isEmpty())
        ErrorDialogClass->setObjectName(QString::fromUtf8("ErrorDialogClass"));
    ErrorDialogClass->resize(400, 300);
    verticalLayout = new QVBoxLayout(ErrorDialogClass);
    verticalLayout->setSpacing(6);
    verticalLayout->setMargin(11);
    verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
    message = new QLabel(ErrorDialogClass);
    message->setObjectName(QString::fromUtf8("message"));

    verticalLayout->addWidget(message);

    file = new QLabel(ErrorDialogClass);
    file->setObjectName(QString::fromUtf8("file"));

    verticalLayout->addWidget(file);

    function = new QLabel(ErrorDialogClass);
    function->setObjectName(QString::fromUtf8("function"));

    verticalLayout->addWidget(function);

    stackTraceLabel = new QLabel(ErrorDialogClass);
    stackTraceLabel->setObjectName(QString::fromUtf8("stackTraceLabel"));

    verticalLayout->addWidget(stackTraceLabel);

    stackTraceEdit = new QPlainTextEdit(ErrorDialogClass);
    stackTraceEdit->setObjectName(QString::fromUtf8("stackTraceEdit"));
    stackTraceEdit->setReadOnly(true);

    verticalLayout->addWidget(stackTraceEdit);

    horizontalLayout = new QHBoxLayout();
    horizontalLayout->setSpacing(6);
    horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
    ignore = new QPushButton(ErrorDialogClass);
    ignore->setObjectName(QString::fromUtf8("ignore"));

    horizontalLayout->addWidget(ignore);

    ok = new QPushButton(ErrorDialogClass);
    ok->setObjectName(QString::fromUtf8("ok"));
    ok->setDefault(true);

    horizontalLayout->addWidget(ok);


    verticalLayout->addLayout(horizontalLayout);


    retranslateUi(ErrorDialogClass);
    QObject::connect(ok, SIGNAL(clicked()), ErrorDialogClass, SLOT(accept()));
    QObject::connect(ignore, SIGNAL(clicked()), ErrorDialogClass, SLOT(ignore()));

    QMetaObject::connectSlotsByName(ErrorDialogClass);
    } // setupUi

    void retranslateUi(QDialog *ErrorDialogClass)
    {
    ErrorDialogClass->setWindowTitle(QApplication::translate("ErrorDialogClass", "ErrorDialog", 0, QApplication::UnicodeUTF8));
    message->setText(QApplication::translate("ErrorDialogClass", "Message text", 0, QApplication::UnicodeUTF8));
    file->setText(QApplication::translate("ErrorDialogClass", "File xxx, line yy.", 0, QApplication::UnicodeUTF8));
    function->setText(QApplication::translate("ErrorDialogClass", "Function xxx", 0, QApplication::UnicodeUTF8));
    stackTraceLabel->setText(QApplication::translate("ErrorDialogClass", "Stack trace", 0, QApplication::UnicodeUTF8));
    ignore->setText(QApplication::translate("ErrorDialogClass", "Ignore", 0, QApplication::UnicodeUTF8));
    ok->setText(QApplication::translate("ErrorDialogClass", "Ok", 0, QApplication::UnicodeUTF8));
    Q_UNUSED(ErrorDialogClass);
    } // retranslateUi

};

namespace Ui {
    class ErrorDialogClass: public Ui_ErrorDialogClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ERRORDIALOG_H
