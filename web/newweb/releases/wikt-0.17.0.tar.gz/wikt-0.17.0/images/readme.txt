
go-home.png
go-next.png
go-previous.png
  http://tango.freedesktop.org/Tango_Icon_Library

magnify-clip.png
  http://en.wiktionary.org//skins-1.5/common/images/magnify-clip.png

loudspeaker.png
bullet.gif
  wiktionary

