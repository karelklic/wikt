/* This file is part of Wikt.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#include "LinkTargetNode.h"
#include "../TextTokenNode.h"
#include "../../../MainWindow/WebView/UrlUtils.h"
#include <QRegExp>

//===========================================================================
LinkTargetNode::LinkTargetNode(const QString &text) : Node(Node::LinkTarget),
  _text(text)
{
  QStringList list = text.split(':');
  QStringList entryHeading = list.last().split('#');
  _entry = entryHeading.first().trimmed();
  if (entryHeading.size() > 1)
    _heading = entryHeading.last().trimmed();

  list.removeLast(); // remove entry name

  // trim all prefixes. Mediawiki does the same.
  // Handles links such as [[ Category: Czech nouns ]]
  for (int i = 0; i < list.size(); ++i)
    list[i] = list[i].trimmed();

  // The list contains only prefixes.
  _namespace = Namespace::instance().fromLinkPrefixes(list);
  _language = Language::instance().fromLinkPrefixes(list);
  _project = Project::instance().fromLinkPrefixes(list);
}

//===========================================================================
QString LinkTargetNode::toXHtmlLink() const
{
  return UrlUtils::toUrl(_text).toString();
}

//===========================================================================
QString LinkTargetNode::toXml(int indentLevel) const
{
  QString indent(indentLevel, ' ');
  return indent + QString("<link_target>%1</link_target>\n").arg(_text);
}

