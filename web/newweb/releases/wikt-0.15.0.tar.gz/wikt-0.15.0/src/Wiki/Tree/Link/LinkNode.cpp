/* This file is part of Wikt.
 *
 * Wikt is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Wikt is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Wikt. If not, see <http://www.gnu.org/licenses/>.
 */
#include "LinkNode.h"
#include "LinkTargetNode.h"
#include "LinkOptionsNode.h"

//===========================================================================
LinkNode::LinkNode(bool emptyPipeAtEnd, bool forcedLink)
  : Node(Node::Link), _emptyPipeAtEnd(emptyPipeAtEnd),
  _forcedLink(forcedLink), _target(0)
{
}

//===========================================================================
QString LinkNode::toXHtml() const
{
  if (!_xhtmlVisible) return "";
  // Images are not supported yet.
  if (!_forcedLink && target().namespace_() == Namespace::Image) return "";
  // Category links are not rendered to the XHTML output.
  if (!_forcedLink && target().namespace_() == Namespace::Category) return "";

  int opts = getOptionCount();
  if (opts == 1)
  {
    LinkOptionsNode *opt = getOption(0);
    return QString("<a href=\"%1\">%2</a>")
      .arg(target().toXHtmlLink())
      .arg(opt->toXHtml());
  }
  else
  {
    return QString("<a href=\"%1\">%2</a>")
      .arg(target().toXHtmlLink())
      .arg(target().toXHtml());
  }
}

//===========================================================================
QString LinkNode::toXml(int indentLevel) const
{
  QString indent(indentLevel, ' ');
  return indent +
    QString("<link emptyPipeAtEnd=\"%1\" forcedLink=\"%2\">\n")
      .arg(_emptyPipeAtEnd ? "true" : "false")
      .arg(_forcedLink ? "true" : "false") +
    childrenToXml(indentLevel+1) +
    indent + "</link>\n";
}

//===========================================================================
QString LinkNode::toWiki() const
{
  QString result = "[[";
  if (forcedLink())
    result.append(':');
  result.append(target().toText());
  foreach(LinkOptionsNode *node, _options)
  {
    result.append('|');
    result.append(node->toText());
  }
  result.append("]]");
  return result;
}

//===========================================================================
void LinkNode::append(Node *child)
{
  Node::append(child);
  if (child->type() == Node::LinkTarget)
    _target = dynamic_cast<LinkTargetNode*>(child);
  else if (child->type() == Node::LinkOption)
    _options.append(dynamic_cast<LinkOptionsNode*>(child));
}

//===========================================================================
QString LinkNode::xhtmlTitle() const
{
  if (target().language() != Language::English)
    return Language::instance().toLocalizedName(target().language());

  int opts = getOptionCount();
  if (opts == 1)
  {
    LinkOptionsNode *opt = getOption(0);
    return opt->toXHtml();
  }
  else
    return target().toXHtml();
}

